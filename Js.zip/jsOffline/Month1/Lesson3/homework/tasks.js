// 1) Haytarareq popoxakan ev veragreq 0: 6 angam tpeq popoxakan@ aynpes vor tpi 0, 1 ev 2 tvern hetevyal hertakanutyamb
// 0
// 2
// 1
// 1
// 2
// 0
// ogtagorceq increment decrement

// 2) Greq nuyn code@ switch case-i mijocov
// let x = 5;
// if (x > 7) {
//     console.log('big')
// } else if (x >= 5) {
//     console.log('equal')
// } else {
//     console.log("i don't know");
// }

// 3) Greq nuyn cod@ if else-i mijocov
// let y = 'some';
// switch (y) {
//     case 'some text':
//         console.log('some text');
//         break;
//     case 'some':
//         console.log('some');
//         break;
//     default:
//         console.log('no text')
// }

// 4) Inch ktpi ev inchu?
// let num = 0;
// num++ ? console.log(num) : console.log('no-num');
// if (num) {
//     console.log(num && 5)
// }

// 5) Inch ktpi ev inchu?
// let count = 0;
// if(count.toString()) {
//     count++;
//     if(count > 0) {
//         count++;
//         if(!count) {
//             console.log('no-count')
//         }else {
//             console.log(--count)
//         }
//     }
// }