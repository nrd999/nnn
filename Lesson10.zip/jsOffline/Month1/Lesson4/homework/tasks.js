// 1) WHAT WILL BE THE OUTPUT AND WHY
// let str = 'my name is ana';
// let length = str.length - 1;
// for (let i = 0; i < str.length; i++) {
//    if(i === 2 || i === 7 || i === 10) {
//        console.log(str[i] + str[length]);
//        length--
//    }
// }

// Gor 
// 1 angam console.log(" " + "a") => " a"
// 2 angam console.log(" " + "n") => " n"
// 3 angam console.log(" " + "a") => " a"


// 2) WHAT WILL BE THE OUTPUT AND WHY
// let x = 10 > 5;
// while(x) {
//     console.log('dont test it in console');
//     x = !!x
// }

// kompy talisenq vari))
// qani vor misht mer x y linum e true ev anndat tpum e
// 'dont test it in console'

// 3) Greq nuyn code@ while-i mijocov
// for(let i = 0; i < 10; i++) {
//     console.log(i)
// }

// Mariam
//  let i = 0; 
//  while(i < 10){
//      console.log(i);
//      i++;
//  }

// Gor
// let i = 0;
// while(i < 10) {
//     console.log(i) // 0-9
//     i++
// }
///////////////
// let i = 0;
// do {
//     console.log(i)
//     i++
// } while(i < 10)

// ---------- ANSWER ----------
// let  i = 0;
// while(i < 10) {
//     console.log(i);
//     i++
// }

// 4) Greq nuyn code@ for-i mijocov mijocov
// let x = 5;
// while (x !== 10) {
//     console.log(x);
//     x++
// }

// Mariam
// for(let x = 5; x!== 10; x++){
//     console.log(x)
// }

// Gor
// for(let x = 5; x !== 10; x++) {
//     console.log(x); // 5-9
// }

// ---------- ANSWER ----------
// for(let x = 5; x < 10; x++) {
//     console.log(x)
// }

// 5) while cikli mijocov tpeq 10-100 mijakayqum bolor tver@

// Mariam
//  let x = 10;
//  while (x !== 101){
//     console.log(x);
//     x++
// }

// Gor
// let x = 10;
// while(x <= 100) {
//     console.log(x);
//     x++;
// }

// ---------- ANSWER ----------
// let num = 10;
// while(num <= 100) {
//     console.log(num)
//     num++
// }

// 6) for loop-i mijocov reversedName popoxakanin veragreq name popoxakan@ aynpes vor text@ lini ajic dzax grvac ev tpeq:
// orinak ete name = 'JOHN' petq e stanaq 'NHOJ'

// Mariam
// let name='JOHN';
// for(){
//    let reversedname=name.reversedname();
//    console.log(reversedname);
// }

// Gor
// let name = "John";
// let reversedName = "";
// for(let i = name.length - 1; i >= 0; i--) {
//     reversedName += name[i]; 
// }
// console.log(reversedName);

// Nik
// let name = "Goqor";
// let reversedName = "";
// for (let i = name.length-1; i >= 0; i--) {
//     reversedName += name[i];
// }
// console.log (reversedName) 

// ---------- ANSWER ----------
// let name = 'SNOITALUTARGNOC';
// let reversedName = '';
//
// for(let i = name.length - 1; i >= 0; i--) {
//     reversedName += name[i];
// }
// console.log(reversedName)

// 7) for loop-i mijocov tpeq 1-1000 mijakayqum bolor minaish ev erknish tvery

// Mariam
// for(let x=1; x!==10; x++){ 
//   console.log(x);
// }
// for(let x=10; x<100; x++){
//   console.log(x);
// }

// Gor
// for(let i = 1; i <= 1000; i++) {
//     i <= 9 && console.log(`Single digit ${i}`)
//     i > 9 && i <= 99 && console.log(`Two digit ${i}`);
// }
// for(let y = 1; y < 1000; y++) {
//     let str = y.toString();
//     str.length === 1 && console.log(`Single digit ${y}`)
//     str.length === 2 && console.log(`Two digit ${y}`)
// }

// Nik
// for (let i=0; i<1000; i++){
//     if(i>=10 && i<100 || i>0 && i<10){
//         console.log(i)
//     }
// }

// ---------- ANSWER ----------
// for(let i = 1; i < 1000; i++) {
//     if(i < 100)  console.log(i)
// }

// 8) for loop-i mijocov tpeq 1-1000 mijakayqum(1-@ ev 1000-@ neraryal) bolor kent tveri gumar@ ---->>  patasxan@ petq e stanaq 250000

// Mariam
// for(let x=1;x<1000;x++){
//     if (x % 2 !== 0) {
//         console.log(x+=x);
//     }
// }

// Gor
// let res = 0;
// for(let i = 1; i <= 1000; i += 2) {
//     res += i;
// } 
// console.log(res);

// Nik
// let sum=0
// for (let i=1; i<=1000; i++){
//     if(i%2>0) sum+=i
// }
// console.log(sum)

// ---------- ANSWER ----------
// let res = 0;
// for (let i = 1; i <= 1000; i++) {
//     if(i % 2 !== 0) {
//         res += i;
//     }
// }
// console.log(res);

// 9) while cikli mijocov tpeq 1-ic 10 mijakayqum gtnvox 3rd handipac zuyg tiv@;

// Mariam
// let x=1;
//   while (x<10){
//      console.log(x % 2 === 0);
//         x++
//    }

// Gor
// let i = 1;
// let res = 0;
// while(i <= 20) {
//     if(i % 2 === 0) {
//         res++;
//         if(res === 3) {
//             console.log(i);
//             break;
//         }
//     }
//     i++;
// }

// Nik
// let sum=""
// for (let i=1; i<10; i++){
//   if(i%2>0) {
//     sum+=i 
//   }
// }
// console.log(sum[2])

// ---------- ANSWER ----------

// let count = 0;
// let num = 1;
// while(num < 10000) {
//     if(num % 2 === 0) {
//         count++;
//         if(count === 3) {
//             console.log(num);
//             break;
//         }
//     }
//     num++;
// }
