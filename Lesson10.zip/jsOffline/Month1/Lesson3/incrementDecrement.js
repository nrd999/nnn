// --------------INCREMENT, DECREMENT ++, --,-----------
//increment postfix
// let x = 5;
// x = x + 1;
// // //OR
// x++;
// ++x;

//decrement postfix
// let x = 5;
// x = x - 1;
// //OR
// x--;
// --x

// let postFixValue = 5;
// let newValue = postFixValue++;
// console.log(newValue, postFixValue);

// console.log(--postFixValue);
// console.log(postFixValue);
// console.log(postFixValue++);
// console.log(postFixValue);

// let preFixValue = 5;
// let newValue = ++preFixValue;
// console.log(newValue, preFixValue);

// console.log(++preFixValue);
// console.log(++preFixValue);
// console.log(++preFixValue);