// 1) GREQ FUNCTION VORY STANUMA MEK DATARK ARRAY ARGUMETN EV MEK TIV ORINAK 5 EV
// RECURSIAI MIJOCOV AMEN KANCHI ZHAMANAK ARRAYI MEJ LCREQ 1 TIV@ MINCHEV ARRAYI ERKARUTYUN@ DARNA 3

// 2) RECURSIAI MIJOCOV HASHVEQ FUNKCIAIN POXANCVAC TVI FAKTORIAL@
// 5 ---> 1 * 2 * 3 * 4 * 5

// 1) WHAT WILL BE THE OUTPUT AND WHY?
// function f(length) {
//     const numbers = [];
//     for (let i = 0; i < length; i++) {
//         numbers.push(i + 1);
//     }
//
//     return numbers
// }
//
// f()

// 2) WHAT WILL BE THE OUTPUT AND WHY?
// console.log(typeof '5' === 'string' && 10 > '5' && 5 % 2 === 0);
// console.log(parseInt(5.5));
// console.log(parseInt('5.5'));
// console.log(parseInt(5.5 + ''));
// console.log(typeof parseInt('5.5'));

// 3) WHAT WILL BE THE OUTPUT AND WHY?
// const arr = [5, 'banana', 'name'];
// arr.length = 0;
// arr.length = 2;
// arr.push('element');
// console.log(arr)

// 4) WHAT WILL BE THE OUTPUT AND WHY?
// f();
// var x = 5;
// function f() {
//     console.log(x)
// }
// f();

//5) WHAT WILL BE THE OUTPUT AND WHY?

// let a = 2

// var x = 5;
// f();
// let f = function () {
//     console.log(x)
// }


// 6) WHAT WILL BE THE OUTPUT AND WHY?

// let x = 5;
// let f = () => {
//     console.log(x)
// }
// x = 7;
// f();
// x = 8

// 7) WHAT WILL BE THE OUTPUT AND WHY?
// function foo (name) {
//     switch(!!name) {
//         case 'john':
//             console.log(3);
//             break;
//         case 5 > 2:
//             console.log(2);
//         case true:
//             console.log(4);
//             break;
//         default:
//             console.log(1);
//             break;
//     }
// }
// let a = 1;
// foo('john');

// 8) WHAT WILL BE THE OUTPUT AND WHY?
// let f = function g() {
//     console.log('hi');
// };
// console.log(g());

// 9) WHAT WILL BE THE OUTPUT AND WHY?
// (function(x) {
//     return (function(y) {
//         console.log(y + x);
//     })('hi')
// })('john');

// 10) WHAT WILL BE THE OUTPUT AND WHY?
// const length = 4;
// const numbers = [];
// for (let i = 0; i < length; i++) {
//     numbers.push(i + 2);
// }
//
// console.log(numbers === [2, 3, 4, 5]);

// 11) WHAT WILL BE THE OUTPUT AND WHY?
// let a = 2
// while(a !== 5) {
//     if (a > 0) {
//         a+=1;
//         console.log(a++)
//     } else {
//         console.log(++a)
//     }
//     a += 1;
// }

// 12) WHAT WILL BE THE OUTPUT AND WHY?
// var b = 3;
// let a =5;
// do {
//     if (++a % 3 === 0 && b % 2 === 0) {
//         console.log(1);
//     } else if (a === 5 || a % 2 === 0) {
//         console.log(2);
//     }
// } while (a < 8);

// 13) WHAT WILL BE THE OUTPUT AND WHY?
// function foo () {
//     switch(true) {
//         case a > 2:
//             console.log(3);
//             break;
//         case a <= 1:
//             console.log(2);
//             break;
//         case a <= 1:
//             console.log(4);
//             break;
//         default:
//             console.log(1);
//             break;
//     }
// }
// let a = 1;
// foo();

// 14) WHAT WILL BE THE OUTPUT AND WHY
// function sayWelcome (name) {
//     let message = 'hello ' + name;
//     return function() {
//         console.log(message);
//     };
// }
// sayWelcome("Henry")();

// 15) INCHPES KANCHEL FUNCTION@ VOR TPI "Message"
// function logger() {
//     return function () {
//         return function () {
//             console.log("Message");
//         }
//     }
// }
