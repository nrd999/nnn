// 1) greq function constructor vorn kcarayi vorpes calculator
//    kancheluc kstana erku tiv, ev kunena gumarman hanman, bajanman ev bazmapatkman methodner
//    voronq kancheluc kveradarcni hamapatasxan gorcoxutyan arjeq@

// Mariam
// function Calc(num1, num2) {
//     this.add = function () {
//         return num1 + num2
//     };
//     this.add1 = function () {
//         return num1 - num2
//     };
//     this.add2 = function () {
//         return num1 * num2
//     };
//     this.add3 = function () {
//         return num1 / num2
//     };
// }
  
// let result = new Calc(30, 10);
// console.log(result.add());
// console.log(result.add1());
// console.log(result.add2());
// console.log(result.add3());

// Nik
// function Calc(num, num1) {
//     this.add = function () {
//         return num + num1
//     };
//     this.sub = function () {
//         return num - num1
//     };
//     this.mul = function () {
//         return num * num1
//     };
//     this.div = function () {
//         return num / num1
//     };
// }

// let result = new Calc(5, 5);
// console.log(result.mul());

// Gor
// function Calc (num1, num2) {
//     this.sum = () => num1 + num2;
//     this.remove = () => num1 - num2;
//     this.divide = () => num1 / num2;
//     this.multiply = () => num1 * num2;
// }

// // const n1 = new Calc(10, 5);
// // console.log(n1.multiply());

// // ----------- ANSWER -----------
// function Calculator(a,b) {
//     this.a = a;
//     this.b = b;

//     this.add = () => {
//         return this.a + this.b
//     };

//     this.diff = () => {
//         return this.a - this.b
//     };

//     this.multiply = () => {
//         return this.a * this.b
//     };

//     this.divide = () => {
//         return this.a / this.b
//     }
// }
// const calculator = new Calculator(5,5);
// console.log(calculator.add());
// console.log(calculator.diff());
// console.log(calculator.multiply());
// console.log(calculator.divide());

// 2) greq function constructor vory kcarayi vorpes vayrkyanachap
//    kunena 3 method, start, stope ev reset ev kkatari hamapatasxan gorcoxutyunnery
//    kanchelov start method@ console-um ktpi 1,2,3 ev ayln (amen vayrkyan) ev ktpi aynqan minchev chenq kanchi stop method@
//    reset@ method@ kancheluc vayrkyannern kzroyana, ete vayrkyanachapn @ntacqi mej e reset chenq karox anel.
//    reset karox enq anel menak stop taluc heto

// Mariam: no answer

// Gor
// let count = 0;
// let id;
// let resetWork = false;
// function Methods () {
//     this.start = () => {
//         id = setInterval(() => console.log(++count), 1000);
//     }
//     this.stop = () => {
//         console.log(count);
//         clearInterval(id);
//         resetWork = !resetWork;
//     }
//     this.reset = () => {
//         if (resetWork) {
//             count = 0;
//         }
//     }
// }

// let timer1 = new Methods();
// timer1.start()
// timer1.stop()
// timer1.reset()

// ----------- ANSWER -----------
// function Timer() {
//     this.intervalId = null;
//     this.count = 0;
//     this.start = () => {
//         if(this.intervalId) {
//             return 'Timer has already started';
//         }else {
    //         this.intervalId = setInterval(() => console.log(++this.count), 1000);
    //         return 'Timer start';
    //     }
    // };

    // this.stop = () => {
    //     if(!this.intervalId) {
    //         return 'Timer has already stopped'
    //     }else {
    //         clearInterval(this.intervalId);
    //         this.intervalId = null;
    //         return 'Timer stopped'
    //     }
    // };

//     this.reset = () => {
//         if (!this.intervalId) {
//             this.count = 0;
//             return this.count
//         }else {
//             return 'You must stop timer'
//         }
//     };
// }
//
// const timer = new Timer();
// timer.start()

// 1) WHAT WILL BE THE OUTPUT AND WHY
// function Student(name, gender) {
//     this.name = name;
//     this.gender = gender;

//     this.sayHi = () => {
//         return `Hi ${this.name}`
//     };

//     return {
//         name,
//         gender
//     }
// }
// //
// let student1 = new Student('Poxos', true);
// console.log(student1.name);

// Mariam
// ete return chaneinq ktper hi poxos,bayc qani vor return enq anum error a talis

// Gor
// qani vor returnenq anum urish object
// kasi vor sayHi function goyutiun chuni

// Nik
// Output will be ERROR` sayHi is not a function.
// Constructor functiony chi karox arrow function linel. Arrow functiony new keywordov erbeq chi kanchvum.

// 2) WHAT WILL BE THE OUTPUT AND WHY
// function Student(name, gender) {
//     this.name = name;
//     this.gender = gender;

//     this.sayHi = () => {
//         return `Hi ${this.name}`
//     };
//     return this.name
// }
// let student1 = new Student('Poxos', true);
// console.log(student1.sayHi());

// Mariam
// estex arden ktpi hi poxos qani vor this.name-n enq return anum

// Gor
// Hi Poxos;

// Nik
// Output will be only "Hi Poxos" 

// 3) WHAT WILL BE THE OUTPUT AND WHY
// function Student(name, gender) {
//     this.name = name;
//     this.gender = gender;

//     this.sayHi = function() {
//         return `Hi ${this.name}`
//     };
// }
// let student1 = new Student('Poxos', true);
// let student2 = Object.assign({}, student1, {name: 'Petros'});
// student1.sayHi = () => `Goodbye ${student1.name}`;
// console.log(student1.sayHi());
// console.log(student2.sayHi());

// // Mariam
// // arajin functionum kanchum enq name vor@ = e poxos erkrord functionum nor obj enq sarqel vori mej avelarel enq name:petros hetevabar ktpi arden petros

// // Gor
// // `Goodbye Poxos`
// // `Hi Petros`

// // Nik
// // Output will be 'Goodbye Poxos', and after will be "Hi Petros", the value of our first function is changed in the last line before consoles. 

// // 4) WHAT WILL BE THE OUTPUT AND WHY
// function Student(name, gender) {
//     this.name = name;
//     this.gender = gender;

//     this.sayHi = () => {
//         return `Hi ${this.name}`
//     };
// }

// let student1 = new Student('Poxos', true);
// let student2 = student1;
// student1.sayHi = () => `Goodbye ${student1.name}`;
// console.log(student2.sayHi());
// console.log(student1.sayHi());

// Mariam
// arajin@ tpum e goodbye poxos qani vor  kanchel enq studen2 vor@= e student 1 .sayHi @ ,erkrordn el nuyn@

// Gor
// `Goodbye Poxos`
// `Goodbye Poxos`

// Nik
// Output will be two times 'Goodbye Poxos', because student 1= student2 and their value are changed but references are same;

// 5) WHAT WILL BE THE OUTPUT AND WHY
// function Student(name, gender) {
//     this.name = name;
//     this.gender = gender;

//     this.sayHi = function() {
//         return `Hi ${this.name}`
//     };
// }
//
// let student1 = new Student('Poxos', true);
// let student2 = new Student('Petros', true);
// let student3 = new Student('Martiros', true);
// //
// student1.nested = student2;
// student2.nested = student3;
// console.log(student1.sayHi());
// console.log(student1.nested.sayHi());
// console.log(student1.nested.nested.sayHi());

// Mariam
// console.log(student1.nested.sayHi());// hi petros qani vor student.1nested=student2
// console.log(student1.nested.nested.sayHi());//hi martiros qani vor  student.1nested=student2 isk student2.nested-n el = e student 3

// Gor
// Hi Petros
// Hi Martiros

// Nik
// Output will be first time 'Hi Petros', and next 'Hi Martiros':