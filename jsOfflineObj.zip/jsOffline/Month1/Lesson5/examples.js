// let str = 'someLongString';
// for(let i = 0; i < str.length;  i++) {
//     console.log(str[i] + ' is iteration ' + i)
// }

// let str = 'someLongString';
// for(let i = str.length - 1; i >= 0;  i--) {
//     console.log(str[i] + ' is iteration ' + i)
// }

//---- TASK 1 zuyg numbers-----

// let num = 100;
// for(let i = 1; i <= num; i++) {
    // if(i%2 === 0) {
    //     console.log(i)
    // }
    //or
    // if(i%2 === 0) console.log(i)
    //  or
    // i % 2 === 0 && console.log(i)
// }
//---with while
// let num = 100;
// let i = 1;
// while (i <= num) {
//     if(i%2 === 0) {
//         console.log(i)
//     }
//     i++
// }


//-----test time------
// let num = 100;
//
// let start = performance.now();
//
// for(let i = 1; i <= num; i++) {
//     i % 2 === 0 && console.log(i)
// }
//
// let end = performance.now();
// //
// console.log(`execution time is: ${end - start}`);


// ----TASK 2 sum of digits-----

// let num = 12548;

// let numStr = num.toString();

// let result = 0;
// // numStr = '12548'
// for(let i = 0; i < numStr.length;  i++) {
//     result += +numStr[i];
// }

// console.log(result);

// TASK 3 is there 0
// let enteredNum = prompt('please enter number');
// its always string thats why we put +

// for (let i = 0; i < enteredNum.length; i++) {
//     if(+enteredNum[i] === 0) {
//         console.log(`yes there is ${enteredNum[i]}`);
//         break;
//     }
//     console.log(enteredNum[i])
// }
//---with while
// let i = 0;
// while(i < enteredNum.length) {
//     if(+enteredNum[i] === 0) {
//         console.log(`yes there is ${enteredNum[i]}`);
//         break;
//     }
//     i++
// }
// TASK 4 zeros count

// let zerosCount = 0;
//
// for (let i = 0; i < enteredNum.length; i++) {
//     if(+enteredNum[i] === 0) {
//         zerosCount++;
//     }
// }
//
// console.log(zerosCount);

// TASK 5 prime numbers

// let isPrime = true;
//
// for (let i = 2; i < +enteredNum; i++) {
//     if(enteredNum % i === 0) {
//         isPrime = false;
//         console.log(`${enteredNum} is not prime`);
//         break;
//     }
// }
//
// isPrime && console.log(`${enteredNum} is Prime`);

// we can divide 2 enteredNum / 2



