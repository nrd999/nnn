// 1) greq function vor@ stanum e tveri array ev mek number argument ev veradarcnum nor array vori mej klinen miayn number argumentov stacvac tvic mec tver@

// 2) greq function vor@ kstana 3 argument, arajin erkusy number, errordy string ('sum' || 'divide' || 'minus' || 'multiply')
//    ev kaxvac errod argumentic kkatari ayd tveri het hamapatasxan gorcixutyun ev kveradarcni arjeq@;

// 3) greq function vor@ stanum e array argument numbernerov ev stugum ete ayd arrayi arajin u verjin tveri gumar@ mec e amboxj arrayi elementeri gumaric
//    apa kveradarcni true hakarak depqum false

// 4) CLOSURI MIJOCOV STACEQ GUMARMAN FUNCTION;
// aysinqin f(1)(2) ---> ksatananq 3

// 5) CLOSURI MIJOCOV STEXCEQ FUNCTION VOR@  ERKROD KANCHI ZHAMANAK STACVAC TIV@ KLCNI ARRAY MEJ,
// ARAJIN KANCHI ZHAMANAK STACVAC TVI CHAPOV;
