// ----------  ARROW FUNCTIONS  --------

// let doSomething = function (a, b) {
//     return a + b;
// };
// doSomething(5, 7);

// let doSomething = (a, b) => a + b;

// doSomething(5,7);

// let doSomething = a => a * a;
// doSomething(5);

// let doSomething = a => {
//     const res = a * a;
//     console.log(res)
// };
// doSomething(5);

// -----arrow function as callback-----

// function f(callback) {
//    console.log(callback(-8))
// }
//
// function isPositive(num) {
//    // return num > 0 ? true : false;
//    return num > 0;
// }
//
// let isPositive = (num) => num > 0;
//
// f(isPositive);
// f((num) => num > 0);
