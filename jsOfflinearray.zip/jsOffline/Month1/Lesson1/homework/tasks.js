// 1) Ի՞նչ կարտատպի և ինչո՞ւ
//     let a = 5;
//     let b = 4;
//     let c;
//     let d = a = 5;
//     c = b = 4;
//     console.log(a, b, c, d);

// 2) Ի՞նչ կարտատպի և ինչո՞ւ
//     let a;
//     console.log(a);
//     a = 5;
//     console.log(typeof a);
//     console.log(a);

// 3) Ի՞նչ կարտատպի և ինչո՞ւ
//     let str = 'some string';
//     let age = 21;
//     age  = str;
//     str = null;
//     console.log(age, str);

// 4) Ի՞նչ կարտատպի և ինչո՞ւ
//     let name = `John`;
//     let message = `my name is ${name}`;
//     console.log(typeof message);
//     console.log(message);

// 5) Ի՞նչ կարտատպի և ինչո՞ւ
//     let isChecked = null;
//     isChecked = true;
//     let isChecked = false;
//     console.log(isChecked);

// 6) Ի՞նչ կարտատպի և ինչո՞ւ
    // const name = 'John';
    // let otherName = "Tom";
    // otherName = name;
    // console.log(otherName);
    // name = 'Jonathan';
    // console.log(name);

// 7) Ի՞նչ կարտատպի և ինչո՞ւ
//     let age = 44;
//     const newAge = 27;
//     let newAge = 30;
//     console.log(age, newAge);

// 8)* Առանց 3րդ փոփոխական հայտարարելու փոխեք հետևյալ 2 արժեքների տեղերը․
    // let num1 = 12345;
    // let num2 = 67890;
    // num1 = num1 + num2;
    // num2 = num1 - num2;
    // num1 = num1 - num2;
    // console.log(num1, num2)
//    Այսինքն պիտի ստանաք num1 = 67890, num2 = 12345;
//    Չի կարելի օգտագործել ուրիշ թվեր կամ ուրիշ փոփոխական։ 
//    Կոդը պիտի ճիշտ լինի num1-ի և num2-ի ցանկացած արժեքի դեպքում։

