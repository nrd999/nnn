// console.log(6);
// alert("Alert text"); // '', ``
// console.log("Console text");
// prompt("Say your name!");
// confirm("Confirm terms");

// let, var, const

// var age = 14;
// console.log(age);
// age = 4;
// console.log(age);
// console.log(age);
// let anotherAge = "age";
// console.log(anotherAge);
// let username = 5;
// let sayHi = `Say hi ${username}`; 
// console.log(sayHi);
// let isProgrammer = false;
// console.log(isProgrammer);
// console.log(name);
// var name = "Nona";
// const isProgrammer = true;

// ----- Data types -----
// Number
// let num = 0;
// let num1 = "num" / 4;
// console.log(num1);
// // Infinity, -infinity, NaN
// // NaN - Not a Number
// console.log(4 / 0);

// String
// let age = "Nona";
//  "" '' ``
// console.log(`Say hi ${age}`);

// Boolean
// let isEmpty = true;
// true, false

// Null

// Undefined
// let age;
// console.log(age)

// BigInt
// 2^53 - 1
// -(2^53 - 1)

// Symbol

// Object

// ---- +, -, *, /, %, ** , ! ----
// console.log(3 + 5);
// console.log(3 - 5);
// console.log(3 * 5);
// console.log(4/2);
// console.log(13%5);
// console.log(2**2);
// !!true --> !false --> true
// console.log(!false);
// console.log("2" + "3")
// console.log("2" + "3" + 4 + 5);
// console.log(4 + 2 + "2" + "3");
// console.log(+"2" + +"3");
// console.log("2" - 6);
// console.log("6" / "2");

// ----- Type converting -----
// string to number
// let num = "2";
// console.log(+num);
// console.log(Number(num));
// console.log(Number("text"));

// number to string
// let num = 5;
// console.log(String(num))
// console.log(num + "");

// Boolean to number
// console.log(Number(true));
// console.log(Number(false));
// console.log(+true);
// console.log(+false);

// String to boolean
// console.log(Boolean(""));
// console.log(Boolean(" "));
// console.log(Boolean(0));
// console.log(Boolean("0"));
// console.log(Boolean(1));
// console.log(Boolean(null));
// console.log(Boolean(undefined));
// console.log(Boolean(NaN));
// console.log(Boolean(-0));

// =, ==, ===, !=, !==
// let age = 12;
// age = 6;
// console.log("12" >= 12);
// console.log("12" !== 12);
















