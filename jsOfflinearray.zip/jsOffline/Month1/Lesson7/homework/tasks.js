// 1) Greq function vor@ vorpes argument kstana array ev ktpi tvyal arrayum exac bolor tver@;(arrayi mej karan tveric baci urish elementner el linen)

// 2) Greq function vor@ kstana 2 array argument ev ktpi aveli erkar arrayi meji bolor string elementnery;

// 3) Greq function vor@ kstana erku array voric mek@ datark e, ev myus arrayi meji elementery klcni datark arrayi mej u kveradarcni ayd array@

// 4) Greq function vor@ stanum a 2 argument mek@ array myus@ number type-i; ev stugum a ete arrayum ka 2rd argumentov stacvac tiv@
// apa veradarcnum a ayd tiv@  hakarak depqum veradarcnum a false

// 5) Greq function vor kstana 4 argument bolor@ number ev kveradarcni array vori mej klinen ayd 4 numberneri krknapatiknern
