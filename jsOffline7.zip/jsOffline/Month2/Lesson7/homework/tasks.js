// Unenq user object vorn uni inch vor propertyner. Unenq user1 object vorn uni ir propertynery ev jarangum e useriny.
// Greq function vory kveradardzni array, vori mej klinen konkret user1 objecti keyery.Orinak ete usern uni canLike: true
// key, isk user1y voch, jarangeluc user1i ptoyoyum kavelana ayd keyy, bayc da chi hamarvum henc user1i key, da jarangvac 
// key a, aysinqn dzer veradardzvox arrayi mej chi linelu. Chaseq chhaskaca.