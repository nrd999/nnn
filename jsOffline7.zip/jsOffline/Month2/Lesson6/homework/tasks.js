// 1) greq function vor@ mer studentsi objectneric cankacac meki contextum kancheluc kveradarcni
//   tvyal object@ keyeri ev valuenri texery poxac
//   Orinak ete kanchem {Gori objecti contetxum} -----> kveradarcni {Gor: 'name', 17: 'age', false: 'gender', 3: 'id'}
//   functionn petq e lini lriv arandzin objectic durs
//   (esorva dasna u this@)

const students = [
    {
        id: 3,
        name: 'Gor',
        gender: false,
        age: 17
    },
    {
        id: 4,
        name: 'Nik',
        gender: false,
        age: 20
    },
    {
        id: 1,
        name: 'Mariam',
        gender: true,
        age: 21
    },
    {
        id: 2,
        name: 'Argisht',
        gender: false,
        age: 22
    },
];

// Nik
// function reversedKeyValue() {
//     let obj={};
//     for (const key in this) {
//         obj[this[key]]=key
//     }
//     return obj
// }
// console.log(reversedKeyValue.call(students[1]));

// Gor
// function f() {
//     let arr = Object.entries(this);
//     Object.keys(this).forEach(key => delete this[key]);
//     arr.forEach(array => this[array[1]] = array[0]);
    
//     return this
// }
// let kanch = f.bind(students[3]);
// console.log(kanch());
// console.log(students);

// Mariam
// function  student(){
//     let obj = {};
//     for (var key in this) {
//         obj[this[key]] = key;
//     }
//     return obj
// }

// let stud = student.bind(students[0]);
// console.log(stud());
// ----------- ANSWER -----------
// function f() {
//     let obj = {};
//     for(let key in this) {
//         obj[this[key]] = key
//     }
//     return obj
// }

// console.log(f.call(students[0]));

// 2) ger function vor@ kstana mer students arrayi objectneric voreve mek@ ev kveradarcni url(aysinqq string)
//    vor@ kunena hetevyal tesq@ orinak Gori objecty stanalu depqum
//    'http://students.com/path?id=3&name=Gor&gender=false&age=17'
//    aysinqn minchev ? nshan@ static nuyn textna dranic heto kaxvac objectic
//    (es xndirn esorva dasi het kap chuni)

// Nik
// function url() {
//     return `http://students.com/path?id=${this.id}&name=${this.name}&gender=${this.gender}&age=${this.age}`
//     }
// console.log(url.call(students[1]));

// Gor
// function f (obj) {
//     return `http://students.com/path?id=${obj.id}&name=${obj.name}&gender=${obj.gender}&age=${obj.age}`;
// }

// console.log( f(students[0]));

// ----------- ANSWER -----------
// function f(student) {
//     return `http://students.com/path?id=${student.id}&name=${student.name}&gender=${student.gender}&age=${student.age}`
// }

// console.log(f(students[3]));

// 1) WHAT WILL BE THE OUTPUT AND WHY
// let student = {
//     name: 'John',
//     getName: function () {
//         return this.name;
//     }
// };

// let getName = student.getName;
// console.log(getName.call(student));
// console.log(student.getName());

// Gor
// 2 depqumel tpelu a John qani vor 2 functionnernel katarumen nuyn gorcy

// Mariam
// console.log(getName.call(student));//john
// console.log(student.getName());//John

// 2) WHAT WILL BE THE OUTPUT AND WHY
// function foo () {
//     console.log(this.a)
// }

// let obj = {
//     foo: foo,
//     a: 5
// };

// foo();
// foo.bind(obj);
// foo();
// obj.foo();


// Gor
// undefined qani vor thisy es depqum global objectna 
// foo.bind(obj) i depqum ban chenq tesni qani vor petqe veragrenq popoxakani nor kanchenq
// undefined qani vor krkin thisy global objectna
// ktesnenq 5 qani vor ays tarberakum foo i this y objn a

// Mariam
// foo();//undefined
// foo.bind(obj);
// foo();//undefined
// obj.foo();//5

// 3) WHAT WILL BE THE OUTPUT AND WHY
// let foo = () => {
//     console.log(this.a)
// };

// let obj = {
//     foo: foo,
//     a: 5
// };

// let otherFoo = foo.bind(obj);
// obj.foo();
// foo.call(obj);
// otherFoo();

// Gor
// 3 kancheri depqumel ktesnenq undefined qani vor arrow functioni thisy es depqum windown a

// Mariam
// obj.foo();//5
// foo.call(obj);//undefined
// otherFoo();//undefined

// 4) WHAT WILL BE THE OUTPUT AND WHY
// let obj = {
//     foo: function () {
//         let func = () => console.log(this.a);
//         func()
//     },
//     a: 5
// };
//
// let anotherFoo = obj.foo;
// anotherFoo();
// anotherFoo.call.obj;
// anotherFoo.call(obj);
// obj.foo();

// Gor
// anotherFoo() depqum ktesnenq undefined qani vor this y verabervum e windowin
// anotherFoo.call.obj depqum ban chi tpi qani vor call i greladzevy ayspes chi
// anotherFoo.call(obj) depqum ktpi 5 qani vor call i mijocov this enq talis anotherFoo in
// obj.foo() depqum ktensnenq krkin 5

// Mariam
// anotherFoo();//undefined
// anotherFoo.call.obj;
// anotherFoo.call(obj);//5
// obj.foo();//5

// 5) WHAT WILL BE THE OUTPUT AND WHY
// let obj1 = {
//     foo: function () {
//        console.log(this.a)
//     },
//     a: 5
// };
// let obj2 = {
//     a: 10
// };
// obj1.foo();
// obj1.foo.call(obj2);
// obj1.foo.bind(obj2);
// obj1.foo();

// Gor
// 5
// 10
// ban chenq tesni
// 5

// Mariam
// obj1.foo();//5
// obj1.foo.call(obj2);//10
// obj1.foo.bind(obj2);//5
// obj1.foo();

