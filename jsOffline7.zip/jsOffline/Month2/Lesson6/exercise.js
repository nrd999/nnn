
// let engLetters = ['a', 'b', 'c', 'd','e','f','g','h','i','j','k','l','m','n',
//     'o','p','q','r','s','t','u','v','w','x','y','z'];

// greq function vorn stanuma array baxkacac 2 taric;
// ev veradarcnum object vortex vorpes keyer nshvac klinen tarer@ isk vorpes valuener te vorerordn en
// ev kveradarcni 3rd key orinak between: vori valuenq klini ayn
// tareri qanak@ voronq gtnvum en poxancac erku tareri aranqum
// {
//     a: 1,
//     c: 3,
//     between: 1
// }

// function foo(arr) {
//     return arr[1] > arr[0] ? {
//         [arr[0]]: engLetters.indexOf(arr[0]) + 1,
//         [arr[1]]: engLetters.indexOf(arr[1]) + 1,
//         between: engLetters.indexOf(arr[1]) - engLetters.indexOf(arr[0]) - 1
//     } : {
//         [arr[0]]: engLetters.indexOf(arr[0]) + 1,
//         [arr[1]]: engLetters.indexOf(arr[1]) + 1,
//         between: engLetters.indexOf(arr[0]) - engLetters.indexOf(arr[1]) - 1
//     }
// }
// console.log(foo(['d', 'a']))