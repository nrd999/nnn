// ------------------ toString() ------------------
// let arr = [1, 2, undefined, 4]

// console.log(arr.toString());

// let obj = {
//     id: 5,
//     isTest: true,
//     name: 'John'
// }

// const x = obj.toString();
// console.log(x);

// -----------------------------------------------
// let obj1 = {
//     id: 5,
//     isTest: true,
//     name: 'John'
// }
// let obj2 = {
//     id: 5,
//     isTest: true,
//     name: 'John'
// }

// console.log(obj1 + obj2);
// console.log(obj1 - obj2);
// console.log(obj1 * obj2);

// console.log(obj1 > obj2);
// console.log(obj1 == obj2);
// console.log(obj1 <= obj2);

// let x = null
// console.log(String(x));

// console.log('[object Object]' >= '[object Object]');


