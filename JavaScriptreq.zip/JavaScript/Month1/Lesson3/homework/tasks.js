// 1) WHAT WILL BE THE OUTPUT AND WHY
// let str = 'my name is ana';
// let length = str.length - 1;
// for (let i = 0; i < str.length; i++) {
//    if(i === 2 || i === 7 || i === 10) {
//        console.log(str[i] + str[length]);
//        length--
//    }
// }

// Suren
/*2-rd toxum nshvuma verjin tar@ aysinqn a
3-rd toxum nshvuma vor qani i-n poqra stringi lenghtic iteracian sharunakvi minchev verjin tar@
4-rd toxum if-ov tvaca payman */

// Sveta David
/*let length@ klini 13 heto for-i mej 0 poqr klini 13ic u if-i mej payman@
chi bavararvi ev kancni hajordin mijev khasnenq 2-i,payman@ kbararvi u ktpvi 
13rd index@ aysinqn a , heto 13@ kdarna 12:
erb darna i = 7 kmtni blocki mej u ktpi 12rd index@ aysinqn n ,
heto 12@ kdarna 11, u eli kstugi michev hasni i = 10, 
u ktpi a aysinqn 11 index@ cikl@ kavartvi erb i mec klini lenght-ic. 
consolum ktpi ana.*/ 

// Alex
/** length darnuma str.length - 1 = a heto cikla gnum u i++ linum
 *  heto erkrord angam fraluc tpuma str[i] + str[length] aysinqn '' + a aysinqn tpuma a heto length-- linum
 *  heto 7erord cikli jamanak tpuma n u length-- linum 
 *  heto 10erord cikli jamanak tpuma a u length-- linum*/


// 2) WHAT WILL BE THE OUTPUT AND WHY
// let x = 10 > 5;
// while(x) {
//     console.log('dont test this in console');
//     x = !!x 
// }

// Suren: no answer

// Hrach
///  haytararum enq x = 10 > 5 stanumenq boolean arjeq True;
//// asumenq x@ tox consol lini  String
//// poxumenq x arjeqy = darcnelov trueic false dra patcharov el darnuma infinite loop;

// 3) Greq nuyn code@ while-i mijocov
// for(let i = 0; i < 10; i++) {
//     console.log(i)
// }

// Suren: no answer

// Hrach
// let i = 0;
// while (i <= 10) {
//     console.log(i);
//     i++;
// }

// Anna
// let x = 5
// while (x < 10){
//     console.log(x);
//     x++
// }

// Alex
// let x = 0;
// while(x <= 10){
//     x++;
//     console.log(x)
// }

// -------------- ANSWER --------------
// let  i = 0;
// while(i < 10) {
//     console.log(i);
//     i++
// }

// 4) Greq nuyn code@ for-i mijocov
// let x = 5;
// while (x !== 10) {
//     console.log(x);
//     x++
// }

// Suren: no answer

// Anna
// let x = 5;
// for (x; x < 10; x++){
//     console.log(x);
// }

// let num = 9;
// for(let i = 5; i < 10; i++){
//     console.log(i);
//     if(i === num) break;
// }

// Alex
// for( x = 5; x !== 10; x++){
//     console.log(x);
// }
// console.log(x);

// Alex
// let x = 5
// for(let x = 5; x !== 10; x++){
//     console.log(x)
// }

// -------------- ANSWER --------------
// for(let x = 5; x !== 10; x++) {
//     console.log(x)
// }

// 5) while cikli mijocov tpeq 10-100 mijakayqum bolor tver@

// Alex
// let x = 10;
// while (x < 100){
//     ++x
//     if(x === 100){
//         break;
//     }
//     console.log(x);
// }

// Alex
// let x = 10;
//    while(x <= 100){
//        x++;
//        console.log(x)
//    }

// -------------- ANSWER --------------
// let num = 10;
// while(num < 100) {
//     console.log(num)
//     num++
// }

// 6) for loop-i mijocov reversedName popoxakanin veragreq name popoxakan@ aynpes vor text@ lini ajic dzax grvac ev tpeq:
// orinak ete name = 'HAJIME' petq e stanaq 'EMIJAH';

// Suren
// let name = 'HAJIME';
// reversedName = name;
// for(let i = name.length - 1; i >= 0;  i--) {
//     console.log(name[i])
// }

// Alex
// let reversedName = 'alex';
// let length = reversedName.length - 1;
// for(let i = 0; i < reversedName.length; i++){
//     console.log(reversedName[length]);
//     length--
// }

// David Sveta
// let reversedName = 'LevelUp';
// for(let i = reversedName.length - 1; i >= 0;  i--) {
//     console.log(reversedName[i])
// }

// Anna: no answer

// -------------- ANSWER --------------
// let name = 'HAJIME';
// let reversedName = '';

// for(let i = name.length - 1; i >= 0; i--) {
//     reversedName += name[i];
// }
// console.log(reversedName)

// 7) for loop-i mijocov tpeq 1-1000 mijakayqum bolor minaish kam erknish tvery

// Suren
// for ( let i = 1; i < 1000; i++) {
//     if(i%10 === 0) {
//         console.log(i * 1, i * 2, i * 3, i * 4,
//             i * 5, i * 6, i * 7, i * 8, i * 9)
//         break;
//     }
// }

// David Sveta
// for(i = 10; i <= 1000;i++) {
//     if(i >= 10 && i <= 99) {
//         console.log(i);

//     }
// }

// Hrach, Alex
//  for ( let i = 1; i < 100; i++) {
//           console.log(i);      
//       }

// -------------- ANSWER --------------
// for(let i = 1; i < 1000; i++) {
//     if(i < 100)  console.log(i)
// }

// 8) for loop-i mijocov tpeq 1-1000 mijakayqum(1-@ ev 1000-@ neraryal) bolor kent tveri gumar@ ---->>  patasxan@ petq e stanaq 250000

// Alex: no answer

// David Sveta
// let num = 1000;
// let result = 0;
// for(let i = 0; i <= num; i++) {
//     if(i%2 === 1){
//         result += i;
//     }
// }

// console.log(result);

// -------------- ANSWER --------------
// let res = 0;
// for (let i = 1; i <= 1000; i++) {
//     if(i % 2 !== 0) {
//         res += i;
//     }
// }
// console.log(res);

// 9) while cikli mijocov tpeq 1-ic 10 mijakayqum gtnvox 3rd handipac zuyg tiv@;

// David Sveta, Hrach, Suren, Anna: no answer

// Alex
// let x = 1;
// while (x < 10) {
//     x++;
//     if(x / 2 === 3){
//       console.log(x);
//     }
// }

// -------------- ANSWER --------------
// let count = 0;
// let num = 1;
// while(num < 10000) {
//     if(num % 2 === 0) {
//         count++;
//         if(count === 3) {
//             console.log(num);
//             break;
//         }
//     }
//     num++;
// }
