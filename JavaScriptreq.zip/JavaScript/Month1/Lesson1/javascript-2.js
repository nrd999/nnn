 // ================WHAT IS JAVASCRIPT=================

 // ===============HOW IT WORKS===============
 // Sync, one thread,...
 // V8

 // ==============<script> tag=================
 // examples in index.html
 // how sites works, request domain response, how index.html loaded


 // ==============DEVELOPER TOOLS===========
 // console.log('show text');

//  ============= CODE STRUCTURE =============
//  ;
// new line

