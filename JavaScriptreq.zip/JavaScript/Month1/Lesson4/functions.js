// ----------- FUNCTIONS -----------
// alert('some'); log('some');

// ------ FUNCTION DECLARATION ------
// function makeSomething() {
//     console.log('Log the text inside me')
// }

// makeSomething();

//----- call it 3 times ------
// function makeSomething() {
//     console.log('log the text inside me')
// }

// makeSomething();
// makeSomething();
// makeSomething();

// ------------ARGUMENTS-------------
// function showName(name, surname) {
//     name = 13;
//     console.log(name, surname);
//     // console.log(surname);
//     // console.log(`${name} ${surname}`)
//     // alert(typeof name)
// }

// showName()
// showName('John');
// showName('Cillian', 'Murphy')
// showName('sth', 'sth')
// showName(4,5)

// function showName(name, surname) {
//     // name = 'otherName';   /*error*/
//     // console.log(`${name} ${surname}`)
// }

// showName('John', 'Wick');

// -----default argument value----

// function showName(name, surname = 'Wick') {
//     console.log(`${name} ${surname}`)
// }

// showName('John');

// --------------- return value --------------
// function sumOfTwoNumbers(a, b) {
//     return a + b
// }

// console.log(sumOfTwoNumbers(4, 5));
// let result = sumOfTwoNumbers(1, 2);
// console.log(result); 
// console.log(sumOfTwoNumbers(1, 2))


// function sumOfTwoNumbers(a, b) {
//     return a + b
// }
// let result = sumOfTwoNumbers(1, 2);
// console.log(result);
// console.log(sumOfTwoNumbers(1, 2));
// console.log(sumOfTwoNumbers(result, 6));

// -----after return function stops-------
// function sumOfTwoNumbers(a, b) {
//     return a + b;
//     console.log('Text');
// }

// let result = sumOfTwoNumbers(1, 2);
// console.log(result);

// function generateNumber() {
//     let num = Math.ceil(Math.random() * 10);
//     return num;
// }

// let result = generateNumber();
// console.log(result);

// function generateNumber() {
//     console.log('Something');
//     return;
// }

// let result = generateNumber();
// console.log(result);

// many returns
// function generateNumber() {
//     let num = Math.ceil(Math.random() * 10);
//     // if(num > 6) {
//     //     console.log(num);
//     //     return 'Number Big Then 5'
//     // } else {
//     //     console.log(num);
//     //     return 'Number small Then 5'
//     // }
//     return num > 6 ? 'Number Big Then 5' : 'Number small Then 5';
// }
// //
// let result = generateNumber();
// console.log(result);

// return syntax
// function someFunction() {
//     return 
//        5
// }

// console.log(someFunction());

// function someFunction() {
//     return (
//         5
//     )
// }

// console.log(someFunction());


// Examples
// 1) 
// function doSomething() {
//     for (let i = 1; i < 100; i++) {
//         if (i % 2 === 0) {
//             return i;                     /*return instead of break*/
//         }
//     }
// }
// //
// let res = doSomething();
// console.log(res);

// 2) 
// function isEven(num) {
//     return num % 2 === 0;
// }
// function getEvenNumber() {
//     for (let i = 1; i < 100; i++) {
//         if (isEven(i)) {
//             return i
//         }
//     }
// }
// const res = getEvenNumber();
// console.log(res);

// function in functions
// function f() {
//     function f1() {
//         function f2() {
//             // ...
//         }
//     }
// }

