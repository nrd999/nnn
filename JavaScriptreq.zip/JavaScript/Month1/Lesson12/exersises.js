// let library = [ 
//     {
//         author: 'Bill Gates',
//         title: 'The Road Ahead',
//         readingStatus: true
//     },
//     {
//         author: 'Steve Jobs',
//         title: 'Walter Isaacson',
//         readingStatus: false
//     },
//     {
//         author: 'Suzanne Collins',
//         title:  'Mockingjay: The Final Book of The Hunger Games', 
//         readingStatus: false
//     }
// ];

// // You heave already read 'The Road Ahead' by 'Bill Gates'
// // You still need to read 'Walter Isaacson' by 'Steve Jobs'

// function foo(library){
//     // if(library.readingStatus) {
//     //     return `You heave already read ${library.title} by ${library.author}`
//     // } else {
//     //     return `You still need to read ${library.title} by ${library.author}`
//     // }
//     return library.readingStatus ? `You heave already read ${library.title} by ${library.author}` : `You still need to read ${library.title} by ${library.author}`
// }
// for(let i = 0; i < library.length; i++) {
//     console.log(foo(library[i]))
// }

