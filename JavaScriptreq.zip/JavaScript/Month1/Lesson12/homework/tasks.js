// destructuring
// https://learn.javascript.ru/destructuring-assignment

// define property
// https://learn.javascript.ru/property-descriptors

// setter getter
// https://learn.javascript.ru/property-accessors

// 1) uneq angleren aybuben@ arrayov, greq function vor kstana voreve tar ev kveradardzni object
//    vortex vorpes key nshvac klini stacac tar@ isk vorpes value te vorerord tarn e aybubenum
//    orinak f('a') kveradardzni {a: 1}
// let arr = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];

// Anna
// let randomLetter = arr[Math.floor((Math.random()*arr.length))]

// function f(letter) {
//     let a = arr.indexOf(letter);
//     let obj = {};
//     obj[`${letter}`] = ++a;
//     return obj;
// }

// console.log(f(`${randomLetter}`));

// Hrach
// let obj = {}; 
//   function newArr(value){
//     // let findArr = arr.find(l => l === value);
//     let indexArr = arr.indexOf(value);
//      return  Object.defineProperty(obj, value, {
//              value: ++indexArr,
//              writable: true,
//     });
// }
// console.log(newArr("a"));

// David Sveta
// let obj = {};
// const foo = (x,arr,obj) =>{
//     arr = arr.indexOf(x)
//     obj[x] = ++arr
    
//     return obj
// };
// console.log(foo("c",arr,obj));

// Alex
// let obj = {};
// function foo(value){
//     for(let elem of arr){
//         if(elem === value) obj[elem] = arr.indexOf(value) + 1;
//     }
//     return obj;
// }
// console.log(foo('p'));

// --------- ANSWER ---------
// function f(letter) {
//     return {
//         [letter] : arr.indexOf(letter) + 1
//     }
// }

// console.log(f('b'));

// 2) greq function vory stanum e object ev veradarcnum array vortex objecti amen key valuen krkin array e;
//    orinak f({a:1, b: 2, c: 3}) ------>>> [['a',1],['b',2],['c',3]]
//    aysinqn grum eq Object.entries methody

// Anna
// let object = {
//     a: 1,
//     b: 2,
//     c: 3
// }
// function f(obj) {
//     return Object.entries(obj)
// }

// console.log(f(object));

// Hrach
// function newArr(obj){
//    let arr = [];
//    for(let key in obj){
//      arr.push([key,obj[key]])
//    }
//    return arr
// }

// console.log(newArr({a:1, b: 2, c: 3}));

// David Sveta
// function foo(obj){
//     return Object.entries(obj)
// }
// console.log(foo({a:1,b:2,c:3}))


//-----------OR----------

// function foo(obj){
//     let arr = [];
//     for(let key in obj){
//         arr.push([key,obj[key]])
//     }
//     return arr
// }
// console.log(foo({a:1,b:2,c:3}))

// Alex
// let res = arr => Object.entries(arr); console.log(res({a:1, b: 2, c: 3}));

// --------- ANSWER ---------
// function f(obj) {
//     // const arr = [];
//     // for(let key in obj) {
//     //     arr.push([key, obj[key]])
//     // }
    
//     // return arr

//     // OR
//     // return Object.keys(obj).map(key => [key, obj[key]])
// }

// console.log(f({a: 1, b: 2, c: 3}));

// 3) greq function vory kstana  arajin argumentov nshvac students array@
//    ev  2 rd argument object, vortex klini mek key-value--> name, gender, kam age,
//    orinak {name: 'Anna'} kam {gender: true} kam {age: 21} ev kveradardzni
//    array ayn usanoxneri objectnerov voronq hamapatasxanum en 2rd argumentov trvac parametrin
//    orinak {gender: true} stanalu depqum kveradarcni [{Annai}, {Svetai}] objectner@
//    ete vochmiban chi hamapatasxanum datark array

// const students = [
//     {
//         name: 'Mko',
//         gender: false,
//         age: 20
//     },
//     {
//         name: 'Anna',
//         gender: true,
//         age: 21
//     },
//     {
//         name: 'Hrach',
//         gender: false,
//         age: 22
//     },
//     {
//         name: 'Suren',
//         gender: false,
//         age: 23
//     },
//     {
//         name: 'Alex',
//         gender: false,
//         age: 20
//     },
//     {
//         name: 'David',
//         gender: false,
//         age: 21
//     },
//     {
//         name: 'Sveta',
//         gender: true,
//         age: 22
//     },
//     {
//         name: 'Alex',
//         gender: false,
//         age: 16
//     }
// ];

// Anna
// function f(arg1, arg2) {
//     for (let i = 0; i < arg1.length; i++){
//         if (arg1[i].hasOwnProperty('gender') && arg1[i].gender === true){
//             console.log(arg1[i]);
//         } 
//     } 
// }

// f(students, {gender: true});

// Hrach
// function select(students, obj){
//   let newArr = [];
//   for(let key of students){
//     if(key.name === obj.name){
//       newArr.push(key)
//     }
//   }
// }
// console.log(select(students, {} ));

// David Sveta
// function foo(arr,x) {
//     return arr.filter(obj => obj.gender === x)
// }
// console.log(foo(students,true))

// --------- ANSWER ---------
// function f(students, filter) {
//     const filterKey = Object.keys(filter)[0];
//     return students.filter(student => student[filterKey] === filter[filterKey])
// }

// const filter = {age: 16};
// console.log(f(students, filter));

// 1) WHAT WILL BE THE OUTPUT AND WHY
// function foo () {
//     return
//     {
//         bar: 'hello'
//     }
// }

// console.log(foo());

// Hrach: no answer

// Anna
// undefined qani vor return chi anum voreve arjeq

// David Sveta
// return enq ogtagorcum funciayi katarum@ dadarecvum e
// dra patcharov console-um  kunenanq undefined 
// isk ete scop@ drvi returni koxq@ ktper {bar: "hello"}

// 2) WHAT WILL BE THE OUTPUT AND WHY
// function foo () {
//     return {
//         name: 'John',
//         skills: ['Fight', (() => console.log(1))()]
//     }
// }

// console.log(foo.skills);
// console.log(foo().skills[1]);

// Anna, Hrach: no answer

// David Sveta
// skzbum ktpi clg um undefined qani vor function chisht chenq kanchum foo ic heto petqe liner ()
// ekrord kanchi jamanak kvercni skills 1 indexum exac@ vor@ kta clgum 1 ev undefined 


// 3) WHAT WILL BE THE OUTPUT AND WHY
// let x = (function foo (name) {
//     return {
//         name,
//         skills: ['Fight', () => console.log(1)]
//     }
// })('John')

// console.log(x);
// console.log(foo.name);
// console.log(foo);

// Anna, Hrach: no answer

// David Sveta
// kta error qani vor function vercvac e pakagceri mech ete hanenq arten function i kancher@ kashxaten

// 4) WHAT WILL BE THE OUTPUT AND WHY
// let obj = {name: 5};
// let x = 'name';
// obj[x] = 10;

// console.log(obj);

// console.log(obj.toString())

// Hrach: no answer

// Anna
// console.log(obj.toString())  /*[object Object] */

// David Sveta
// skzbum obj havasar klini {name:5}, heto  valuen obj[x] ov kpoxvi
// nuyn tivn e tarberutyun chenq zga ete dnenq 6 kpoxvi valun 6-i 
// 1-in clg ktpi {name:5}
// 2rd console um ktpi [object Object] qani vor object@ toStringi jamanak espes e talis

// 5) WHAT WILL BE THE OUTPUT AND WHY
// let obj = {name: 5};
// let x = {key: 5};
// let y = {key: 7};

// obj[x] = x.key;
// obj[y] = y.key;
// // let obj = {
// //     '[object Object]': 7
// // }

// console.log(obj);
// console.log(obj[x]);

// Anna, Hrach: no answer

// David Sveta
// skzbum kta undefined qani vor obj.x arjeq chuni 
// 2 rdum kta 7 qani vor kvercni y - i arjeq@