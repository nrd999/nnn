// 1) greq function vorn stanum e object ev stugum datark e te voch ---> hampatasxan veradardznelov true kam false
// Suren
// let obj = {age: 5}

// function isEmpty(obj) {
//     return Object.keys(obj).length === 0;
// }

// console.log(isEmpty(obj))

// Alex
// function foo(x){
//     // let res = Object.values(x);
//     // res = res.length === 0 ? true : false;
//     return Object.values(x).length === 0;
// }

// console.log(foo({age: 5}));

// David Sveta
// 1
// let obj = {foo: 1};
// function foo(x) {
//     return Object.keys(x).length === 0;
// }
// console.log(foo(obj)); 

// 2
// function foo(obj) {
//     for (let key in obj) {
//         return false;
//     }
//         return true;
// }
// console.log(foo({}));

// Alex
// function myFunction() {
//         let obj = {}
//         if (obj.length === 0){
//             return true;
//         }
//         else {
//             return false;
//         }
//     }

//     console.log(myFunction({}))

// Anna
// let obj = {}
// function f(obj) {
//     let values = Object.values(obj)
//     if (values.length === 0) {
//         return true
//     }
//     return false
// }
// console.log(f(obj));

// ------------ Answer ------------
// function f(obj) {
//     // for (let key in obj) {
//     //     if (obj.hasOwnProperty(key)) {
//     //         return false
//     //     }
//     // }
//     // return true

//     // or

//     return Object.keys(obj).length > 0
// }

// console.log(f({}));

// 2) greq function vorn stanum e nerqevum nshvac  object@ ev hashvum bolor ashxatoxneri ashxatavardzeri gumar@

// let employeeSalaries = {
//     John: '100$',
//     Arthur: '200$',
//     Thomas: '1000$',
// }

// Suren, Alex: no answer

// Alex
// let employeeSalaries = {
//     John: 100,
//     Arthur: 200,
//     Thomas: 1000,
// }

// function foo(res, employeeSalaries){
//     for(let key in employeeSalaries){
//         res += employeeSalaries[key];
//     }
//     return res;
// }
// console.log(foo(0, employeeSalaries));

// David Sveta
// 1
// let employeeSalaries = {
//     John: '100',
//     Arthur: '200',
//     Thomas: '1000',
// }
// function foo(obj){
//    let res = 0;
//    let val = Object.values(obj);
//     for(let i = 0; i < val.length;i++){
//     res += +val[i]
// }
// return res
// }
// console.log(foo(employeeSalaries))

// 2
// let employeeSalaries = {
//     John: '100$',
//     Arthur: '200$',
//     Thomas: '1000$',
// }
// function foo(obj){
//     let res = 0;
//     for (let key in obj) {
//         let x = parseInt(obj[key])
//         res += x
//     }
//     return res + '$'
// }
// console.log(foo(employeeSalaries))

// Anna
// let result = 0;    
// function f(obj) {
//     for (let key in obj){
//         result += parseFloat(obj[key]);
//     }  
//     return result
// }
// console.log(f(employeeSalaries));

// ------------ Answer ------------
// function f(obj) {
//    let sum = 0;
//    for (let key in obj){
//         sum += parseInt(obj[key]);
//    }
//    return sum;
//}
// console.log(f(employeeSalaries));

// 3) greq function vorn stanum e object ev veradardznum mek ayl object vortex klinen naxord objecti number value-neri krknapatiknery
// orinak ete stacel enq {price: 100, name: 'John'} kveradardzni --> {price: 200, name: 'John'}

// Suren
// let obj = {
//     'a': 1,
//     'b': 2,
//     name: 'John'
// }

// let clone = {}
// function foo() {
//     for (let key in obj) {
//         clone[key] = obj[key]
//         if (typeof obj[key] === 'number') {
//             clone[key] *= 2
//         }
//     }
//     return clone
// }
// console.log(obj);
// foo()
// console.log(clone)

// Alex
// function foo(obj1, obj2) {
//     for(let key in obj2){
//         obj1[key] = obj2[key]
//         obj1[key] === +obj2[key] && (obj1[key] *= 2);
//     }
//     return obj1
// }
// console.log(foo({}, {price: 100, name: 'John', surname : 'Hovsepyan', id : 502}));

// David Sveta
// function foo(obj) {
//     for (let key in obj) {
//       if (typeof obj[key] === 'number') {
//          obj[key] *= 2;
//       }
//     }
//     return obj
// }
// console.log(foo({price: 100, name: "John"}))

// Alex
// function double() {
//     let obj1 = {
//         name: 'John',
//         price: 200,
//         age: 11
//     }
//     let obj2 = {}
// }
// let obj2 = 2 * obj1
// console.log(double)

// Anna
// let object = {
//     price: 100,
//     name: "John",
//     age: 17
// }
// function f(obj) {
//     for (let key in obj){
//         if (typeof obj[key] === "number"){
//             obj[key] *= 2
//         }
//     }
//     return obj
// }
// console.log(f(object));

// ------------ Answer ------------
// function f(obj) {
    // const resObj = {};
    // for (let key in obj) {
    //     if(typeof obj[key] === 'number') {
    //         resObj[key] = obj[key] * 2
    //     }else {
    //         resObj[key] = obj[key]
    //     }
    //         // or
    //         // resObj[key] = typeof obj[key] === 'number' ? obj[key] * 2 : obj[key]
    // }
    // return resObj
// }

// console.log(f({price: 100, name: 'John'}))

// 4) greq function vorn stanum e object ev veradarcnum mek ayl object vortex values keyov klinen stacvac objecti value-nern arrayov
//    isk keys keyov stacvac objecti keyer@ arrayov,
//    orinak stanum e {id: 5, name: 'John'} kveradardzni --> {values: [5,'John'], keys: ['id', 'name']}

// Alex: no answer

// Suren
// let obj1 = {
//     'a': 1,
//     'b': 2,
//     'c': 3,
// }

// function f(obj1) {
//     // let obj2 = Object.assign({}, obj1);
//     let values = Object.values(obj1)
//     let keys = Object.keys(obj1)

//     return {
//         values,
//         keys
//     }
// }

// console.log(f(obj1))

// Alex
// function foo(obj){
//     let obj2 = {}
//     obj2.values = Object.values(obj);
//     obj2.keys = Object.keys(obj)
//     return obj2;
// }
// console.log(foo({id: 5, name: 'John'}));

// David Sveta
// let obj = {id: 5,name:"John"}
// function foo(obj){
//     let emptyObj = {}
//     let val = Object.values(obj)
//     let key = Object.keys(obj);
//     emptyObj.values = val
//     emptyObj.keys = key
//     return emptyObj
// }
// console.log(foo(obj))

// Anna
// let object = {
//     name: 'Anna',
//     age: 25
// }
// function f(obj) {
//     let value = Object.values(obj)
//     let key = Object.keys(obj)
//     let object2 = {key,value}

//     return object2
// }
// console.log(f(object));

// ------------ Answer ------------
// function f(obj) {
//     // const resObj = {};
//     // resObj.values = Object.values(obj);
//     // resObj.keys = Object.keys(obj);
//     // //
//     // return resObj

//     return {
//         values: Object.values(obj),
//         keys: Object.keys(obj),
//     }
// }
// //
// console.log(f({id: 5, name: 'John'}));

// 1) WHAT WILL BE THE OUTPUT AND WHY
// let person = {
//     name: 'John',
//     surname: 'Smith',
//     friends: ['empty', undefined]
// }
// let str = '';
// for (let key in person) {
//     if (person.hasOwnProperty(key)) {
//         str += key
//     }
// }

// console.log(str);

// Alex: no answer

// Suren
// ktpi irar kpac namesurnamefriends vorovhetev stugel en ira key-er@ u concat arel str-i het

// Alex
// cikla sksvum u hashvuma person-i keyery u ete person-y uni key str-in avelacvuma key aysinqn stacvuma name + surname + friends u tpuma namesurnamefriends

// David Sveta
//for loop-ov str = '' avelacnum enq bolor key-i gumar@ qani vor ayn string e`
//console um ktpi namesurnamefriends 

// Anna
// ktpi namesurnamefriends  

// 2) WHAT WILL BE THE OUTPUT AND WHY
// const person = {
//     knowladges: ['programming', 'driving'],
//     child: {
//         name: 'John',
//         surname: 'Smith'
//     }
// }
// console.log(typeof person.child['name'])
// console.log(typeof person.knowladges)

// Suren
// mi hat ktpi string takic el object vorovhetev key-eri typeof@ misht string a
// isk array-@ objecta

// Alex
//tpuma personi childi namei arjeqi type aysinqn tpuma string heto tpuma personi knowladges-i arjeqi tesaky u tpuma object vorovhetev array-y object type-a

// David Sveta
//1-in clg ktpi string qani vor name@ aysinqn key@ string type e
//2-rd clg ktpi object qani vor array nuyn pes object e 

// Alex
// mi hat ktpi string,vorovhetevy typeof-y tenc er,myusn el object

// Anna
//string  object

// 3) WHAT WILL BE THE OUTPUT AND WHY
// let obj = {
//     id: 1,
//     name: 'John',
//     surname: 'Smith'
// }

// const value = Object.values(obj);
// value.push(obj.id);
// console.log(value);

// Suren
/* qani vor Object.values-@ mez veradardznuma object array sarqac
ed patcharov kunenq array vori mej klini 1, 'John, 'Smith' yev 1 qani vor push e arvel id-in */

// Alex
// value-in avelacvuma obj-i arjeqnery array-i mej heto push-a anum obj-i id-i arjeqy u tpuma 1, John, Smith, 1 

// David Sveta
//const value skszbum klini [1,John,Smith] heto push kanenq  obj-i id vor@ 1 e 
//clg ktpi [1,John,Smith,1]

// Alex
// skzbum ktpi objecti exac bolor arjeqnery [1, 'John', 'Smith] heto mi hate el ktpi menak valuen-aysinqn 1

// Anna
// arrayi mej [1, 'John', 'Smith', 1]

// 4) WHAT WILL BE THE OUTPUT AND WHY
// let obj = {
//     id: 1,
//     name: 'John',
//     surname: 'Smith'
// }

// const keys = Object.keys(obj);
// console.log(keys.length)

// Suren
// Object.values-@ krkin veradardzdrela array heto stugvela array-i length-@ vor@ 3-

// Alex
// keys-in avelacvuma obj-i keyery array-i mej aysinqn stacvuma [ud, name, surname] u tpuma keys-i length-y aysinqn 3

// David Sveta
//skzbum const keys@ skzbum klini [1,John,Smith] ev clg um ktpi 3 vorovhetev lenght @ 3 e

// Alex
// ktpi 3 vorovhetev key-eri lenght-y aydqan e

// Anna
// ktpi arrayi length-y 3

// 5) WHAT WILL BE THE OUTPUT AND WHY
// let obj1 = {
//     id: 1,
//     name: 'John',
//     surname: 'Smith'
// }
// let obj2 = {
//     id: 5,
//     isTest: false,
//     person: {
//         gender: 'man',
//     }
// }
//
// const obj = Object.assign(obj1, obj2);
// console.log(obj.id);
// console.log(obj2, obj1, obj);
// const anotherObj = Object.assign(obj1, obj2);
// anotherObj.person.skills = ['fight'];
// console.log(obj1.person.skills)
// console.log(obj1, obj2);

// Alex: no answer

// Suren
/* skzbic ktpi 5 qani vor nor obj-in assign a arvel obj1-i yev obj2-i id key-n
yev qani vor obj2-i id-in verjinna inq@ vercrela henc 5-@ */
// heto stexcvela mi hat el anotherObj vori mej obj1-in assign a arvel obj2-@
/* heto anotherObj-n vor arden havasara obj2-i meji key-erin ira meji person objectin
avelcvela skills key-n ['fight'] value-ov heto et value-n console.log-a arvel */
// aysinqn ktpi mi hat 5 takic el ['fight']

// Alex
// obj-i mej  copy-a anum obj1 u obj2 keyery u arjeqnery heto tpuma 5 vorovhetev vercnuma obj2-i id-n heto anotherObj-i mej copy-a anum erkusi arjeqnery
// heto anotherObj-i person-i mej skills-a avelanum ira [fight] arrayov u tpuma [fight]

// David Sveta
//const obj = klini mi obyekti vor@ kunena obj1 ev obj2 tvyalner@
//ev clg obj.id klini 5 qani vor kverci obj2 id-in,
//anotherObj-i personin kavelcanenq key skills vorin el ktanq value ['fight']
//clg ktpi ['fight']

// Anna
// const obj = Object.assign({}, obj1, obj2); /*{{}, id:5, name: "John", surname:'Smith',isTest: false,person: {gender: 'man',}} */
// console.log(obj.id);  /*5 */
// const anotherObj = Object.assign(obj1, obj2); /* {id:5, name: "John", surname:'Smith',isTest: false,person: {gender: 'man',}} */
// anotherObj.person.skills = ['fight'];
// console.log(obj2.person.skills) /*es mtacum ei undefined */