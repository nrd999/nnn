// 1. popoxakanneri haytararman dzever@

// 2. dranc tarberutyun@ (hoisting, scope)

// 3. constov haytararvac popoxakanner (vor depqum kareli e poxel)

// 4. js typer@

// 5. inch e NaN@, vor typein e patkanum ev vor depqerum e stacvum NaN

// console.log(NaN**0);

// 6. inch en undefined@ ev null@
// console.log(0 == '0');
// 7.  ==  ev === havasarutyunneri tarberutyun

// 8. looperi tesakner
// let i = 0;
// for(var i = 0; i < 5; i++){
//     console.log(i);
// }
// console.log(i);
// console.log(foo);
// let foo = function() {
//     return 5
// }
// SIF IIFE
// let foo = (function(){})()
// (function(){})()

// 9. functioni haytararman dzever
// let arr = [1, 3];
// console.log(arr.indexOf(5));
// console.log(arr.filter(item => item < 0));
// 10. dranc tarberutyunner@

// 11. rest ev spread operatorner

// 12. arrayi masin reference type

// 13. inch e irenic nerkayacnum functioni mej return artahayatutyun@ ev dra bacakayutyun@

// 14. hoisting (inch e irenic nerkayacnum ev inchn e entarkvum hoistingi js-um)
// console.log(x);
// x = 5
// x = 6
// console.log(x);

// 15. global ev local popoxakanner

// 16. scope. (inch e block scop@, vor popoxakannern en entarkvum block scopi voronq voch)

// 17. inchpes en ashxatum || , && operatornern

// 18. inchpes en ashxatum ++, -- operatornern

// 19. inchpes e ashxatum switch case@

// 20. inchpes aveli karch ogtagorcel if else@ (ternary operator)

// 21. inchpes arrayic jnjel inchvor element

// 22. inchu xorhurd chen trvum shift unshift methodnern

// 23. inchpes datarkel array@

// 24. inch methodner giteq arrayi het asxhatelu

// 25. inch e closure@

// 26. inch vat koxmer uni

// 27. inch e rekursian (vat koxmer@)

// 28. arrayi haytararman inch dzever giteq

// 29. inchpes stugel popoxaknn arjeq uni te voch (zhxtman operator)

// 30. iife, self invokig function (inch en sranq ev inchpes een ogtagorcvum)