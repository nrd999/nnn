// -----if statement-----
// if (true) {
//     console.log('its working')
// }

// if(true) console.log('its working');

// let age = 20;
// if(age === 20) {
//     console.log(age)
// }

// let age = 20;
// if (age === 20) {
//     console.log(age);
//     console.log(5);
//     let x = 'string';
//     console.log(x);
// }

// 0, '', null, undefined, NaN, false ---> false

// if(0) {
//     console.log("It doesn't work.")
// }
//
// if(null) {
//     console.log("It doesn't work.")
// }

// if(5) {
//     console.log("It works!")
// }

// let username = 'John';

// if(username === 'John') {
//     console.log(username)
// }

// OR

// if(username) {
//     console.log(username)
// }

// ------- else ------------
// if (true) {
//     console.log('It works when condition is true.');
// } else {
//     console.log('It works when if doesn't work.');
// }

// ------ else if ------

// let age = 10;
// if (age === 20) {
//     console.log(`Age is equal to ${age}.`)
// } else if (age > 20) {
//     console.log(`Age is bigger then ${age}.`)
// } else {
//     console.log(`Age is smaller then ${age}.`)
// }

// if(true) {
//     console.log('sth');
// }

// if(true) {
//     console.log('else');
// }



// let age = 70;
// let isOld;

// if (age > 60) {
//     isOld = true;
// } else {
//     isOld = false;
// }

// console.log(isOld);

// ---- Short writing: Ternary operator (?, :)
//
// let age = 80;
// age > 70 ? console.log(age) : console.log('small');

// let age = 70;
// let isOld;
// if (age > 60) {
//     isOld = true
// } else {
//     isOld = false
// }

// isOld = age > 60 ? true : false;
// console.log(isOld);


// let result = age > 100 ? 'big then 100' : age > 70 ? 'older' : age > 50 ? 'its ok' : null;


//----if in if-----

// let x = 5;
// if (x === 5) {
//     let y = 15;
//     if (y > 10) {
//         console.log('x is equal to 5 and y is bigger then 10.')
//     } else {
//         console.log('x is equal to 5 but y is smaller then 10.')
//     }
// } else {
//     if (x > 7) {
//         console.log('x is bigger then 5 and 7.')
//     }
// }

// --------Why we use === instead of ==?-------

// let num = '7.123';
// if (num == 7.123) {
//     let x = num.toFixed(1);
//     console.log(x)
// }




