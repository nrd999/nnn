// unenq mer studentneri html@ ev tak@ mihat div(dasin vor anum einq et htmly, eventDelegation.js fayluma)
// u studentneri array@

// const students = [
//     {
//         name: 'Mko',
//         gender: false,
//         age: 20
//     },
//     {
//         name: 'Anna',
//         gender: true,
//         age: 21
//     },
//     {
//         name: 'Hrach',
//         gender: false,
//         age: 22
//     },
//     {
//         name: 'Suren',
//         gender: false,
//         age: 23
//     },
//     {
//         name: 'Alex',
//         gender: false,
//         age: 20
//     },
//     {
//         name: 'David',
//         gender: false,
//         age: 21
//     },
//     {
//         name: 'Sveta',
//         gender: true,
//         age: 22
//     },
//     {
//         name: 'Gor',
//         gender: false,
//         age: 16
//     },
//     {
//         name: 'Mariam',
//         gender: true,
//         age: 22
//     },
//     {
//         name: 'Nik',
//         gender: false,
//         age: 23
//     },
// ];

// studenti x-i vra click aneluc stugeq ete nshvac student@ vori vra click enq arel ka mer arrayum (stugeq id-ov) ev
// nra vra click chi exel uremn nshvac studentin inchvor style ktanq vor haskanali lini vor dra vra click exav
// u arrayi mej nshvac studenti objectum key kavelacnenq orinak clicked: true; ev tak@ textov knshenq;
// orinak useri vra click exav; kam useri vra arden click e exel; kam nshvac usery chka mer arrayum

// 1. INCH TARBERUTYUN KA
// const num = 5;
// const num1 = new Number(5);
// console.log(num1 + num);

// 2. WHAT WILL BE THE OUTPUT AND WHY
// const num = 5;
// const num1 = new Number(5);
// console.log(num === num1)

// 3. WHAT WILL BE THE OUTPUT AND WHY
// (() => {
//     console.log(1);
//     setTimeout(() => { console.log(2) }, 1000);
//     setTimeout(() => { console.log(3) }, 0);
//     console.log(4);
// })();

// 4. WHAT WILL BE THE OUTPUT AND WHY
// const obj = {};
// [ 'zebra', 'horse' ].forEach(function(i) {
//     obj[i] = i;
// });
// console.log(obj);

// 5. WHAT WILL BE THE OUTPUT AND WHY
// let foo = () => {
//     console.log(this.a)
// }
// let obj = {
//     foo: foo,
//     a: 5
// };
// foo();
// obj.foo();








