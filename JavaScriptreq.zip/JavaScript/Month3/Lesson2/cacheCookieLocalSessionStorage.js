// --------------- cache ---------------
// --------------- cookies ---------------
// --------------- localStorage ---------------
// zhamket chunen, pahvum en browsern pakel baceluc heto

// localStorage.setItem('id', 5);
// //
// let id = localStorage.getItem('id');
// console.log(id);

// localStorage.clear();

// cankacac arjeq veracvuma stringi
// dra hamar aveli lava menq sarqenq string

// ---------------------------------------
// ref typery stringify
// let obj = {
//     id: 1,
//     skills: [1,2,3]
// }

// localStorage.setItem('myObj', obj);
//
// localStorage.setItem('myObj', JSON.stringify(obj));
//
// let myObj = localStorage.getItem('myObj');
// console.log(myObj);
// 
// let parsedMyObj = JSON.parse(myObj);
// console.log(parsedMyObj);

// --------------- sessionstorage ---------------

// sessionStorage.setItem('id', 'someString');

// let id = sessionStorage.getItem('id');
// console.log(id);


