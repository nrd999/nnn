// ogtvelov mer studentneri htmlic ev arrayic
// click aneluc nshvac studenti object@ qceq localstorage
// 2rd angam click aneluc jnjeq storagic

// const students = [
//     {
//         id: 1,
//         name: 'Mko',
//         gender: false,
//         age: 20
//     },
//     {
//         id: 2,
//         name: 'Anna',
//         gender: true,
//         age: 21
//     },
//     {
//         id: 3,
//         name: 'Hrach',
//         gender: false,
//         age: 22
//     },
//     {
//         id: 4,
//         name: 'Suren',
//         gender: false,
//         age: 23
//     },
//     {
//         id: 9,
//         name: 'Alex',
//         gender: false,
//         age: 20
//     },
//     {
//         id: 6,
//         name: 'David',
//         gender: false,
//         age: 21
//     },
//     {
//         id: 7,
//         name: 'Sveta',
//         gender: true,
//         age: 22
//     },
//     {
//         id: 8,
//         name: 'Gor',
//         gender: false,
//         age: 16
//     },
//     {
//         id: 10,
//         name: 'Mariam',
//         gender: true,
//         age: 22
//     },
//     {
//         id: 5,
//         name: 'Nik',
//         gender: false,
//         age: 23
//     },
// ];