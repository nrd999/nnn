// 1) greq function constructor vorn kcarayi vorpes calculator
//    kancheluc kstana erku tiv, ev kunena gumarman hanman, bajanman ev bazmapatkman methodner
//    voronq kancheluc kveradarcni hamapatasxan gorcoxutyan arjeq@

// Alex: no answer

// Suren
// function Calc(num1, num2) {
//         this.plus = function () {
//             return num1 + num2
//         };
//         this.minus = function() {
//             return num1 - num2
//         }
//         this.multi = function() {
//             return num1 * num2
//         }
//         this.divison = function() {
//             return num1 / num2
//         }
//     }
    
//     let result = new Calc(5, 5);
//     console.log(result.multi());

// David Sveta
// function Calculator(x, y) {
//     this.sum = function () {
//         return x + y
//     }
//     this.minus = function () {
//         return x - y
//     }
//     this.divide = function () {
//         return x / y
//     }
//     this.multiply = function () {
//         return x * y
//     }
    
// }

// let result = new Calculator(10, 5);
// console.log(result.multiply());

// Hrach
// function Calc(num1, num2){
//     this.plus = function(){
//         return num1 + num2
//     }
//     this.multi
//      = function(){
//         return num1 * num2
//     }
//     this.divison = function(){
//         return num1 / num2
//     }
//     this.minus = function(){
//         return num1 - num2
//     }
// }
// let sum = new Calc(5, 10)
// console.log(sum.plus());

// Alex
// function Math() {
//     this.sum = (num, num1) => {
//         if(typeof num !== 'string' && typeof num1 !== 'string') return num + num1
//     }

    // this.multiply = (num, num1) => {
    //     if(typeof num !== 'string' && typeof num1 !== 'string') return num * num1
    // }

    // this.divide = (num, num1) => {
    //     if(typeof num !== 'string' && typeof num1 !== 'string') return num / num1
    // }

//     this.minus = (num, num1) => {
//         if(typeof num !== 'string' && typeof num1 !== 'string') return num - num1
//     }
// }

// let math = new Math();
// console.log(math.sum(10, 10));
// console.log(math.multiply(10, 10));
// console.log(math.minus(10, 10));
// console.log(math.divide(10, 10));

// Anna
// let Calc = function(num1, num2) {
//     this.plus = () => {
//         return num1 + num2
//     };
//     this.multiple = () => {
//         return num1 * num2
//     };    
//     this.subtract = () => {
//         return num1 - num2
//     };
//     this.divide = () => {
//         return num1/num2
//     }
// }
// let sum = new Calc(5,6).plus()
// console.log(sum);

// let multiple = new Calc(5,6).multiple()
// console.log(multiple);

// let sub = new Calc(5,6).subtract()
// console.log(sub);

// let divide = new Calc(5,6).divide()
// console.log(divide);     

// ----------- ANSWER -----------
// function Calculator(a,b) {
//     this.a = a;
//     this.b = b;

//     this.add = () => {
//         return this.a + this.b
//     };

    // this.diff = () => {
    //     return this.a - this.b
    // };

    // this.multiply = () => {
    //     return this.a * this.b
    // };

//     this.divide = () => {
//         return this.a / this.b
//     }
// }
// const calculator = new Calculator(5,5);
// console.log(calculator.add());
// console.log(calculator.diff());
// console.log(calculator.multiply());
// console.log(calculator.divide());

// 2) greq function constructor vory kcarayi vorpes vayrkyanachap
//    kunena 3 method, start, stope ev reset ev kkatari hamapatasxan gorcoxutyunnery
//    kanchelov start method@ console-um ktpi 1,2,3 ev ayln (amen vayrkyan) ev ktpi aynqan minchev chenq kanchi stop method@
//    reset@ method@ kancheluc vayrkyannern kzroyana, ete vayrkyanachapn @ntacqi mej e reset chenq karox anel.
//    reset karox enq anel menak stop taluc heto

// Suren, Alex: no answer

// David Sveta
// function foo(){
//    this.start = function (){
//         let x = setInterval(()=> {
//             console.log(++x);
//         },1000)
//         return --x 
//     };
//     this.stop = function (){
// };
//     this.reset = function (){
//        clearInterval(this.x) 
//     }
// }
// let res = new foo();
// console.log(res.start())
// res.reset()
// res.stop()

// Hrach
// function Timer (start, stop , reset){
//     this.startWatch = function(){
//         let timeId = start.setInterval(() => {
//         }, 1000);
//         return timeId
//     }

    // this.stopWatch = function(){
    //     if(timerId === 100){
    //         return  stop.clearInterval(timeId)
    //     }
    // }
    // this.resetWatch = function(){
    //     if(stop.clearInterval){
    //         let reset = 0;
    //         return 0
    //     }
    // }
    // }



// let timerWatch = new Timer(1, 99 , 0);
// console.log(timerWatch.start())

// Alex
// function Timer(){
//     let a = 0;
//     let val = false;
//     let res = 0;
//     this.start = () => {
//         res = setInterval(() => console.log(++a), 1000)
//     }
//     this.stop = () => {
//         val = true
//         clearInterval(res);
//     }
//     this.reset = () => {
//         if(val) {
//             clearInterval(res);
//             a = 0
//         }                
// }
// }

// let timer = new Timer()

// timer.start()
// timer.stop()
// timer.reset()

// ----------- ANSWER -----------
// function Timer() {
//     this.intervalId = null;
//     this.count = 0;
//     this.start = () => {
//         if(this.intervalId) {
//             return 'Timer has already started';
//         }else {
//             this.intervalId = setInterval(() => console.log(++this.count), 1000);
//             return 'Timer start';
//         }
//     };
//     this.stop = () => {
//         if(!this.intervalId) {
//             return 'Timer has already stopped'
//         }else {
//             clearInterval(this.intervalId);
//             this.intervalId = null;
//             return 'Timer stopped'
//         }
//     };
//     this.reset = () => {
//         if (!this.intervalId) {
//             this.count = 0;
//             return this.count
//         }else {
//             return 'You must stop timer'
//         }
//     };
// }
// //
// const timer = new Timer();

// 1) WHAT WILL BE THE OUTPUT AND WHY
// function Student(name, gender) {
//     this.name = name;
//     this.gender = gender;
//
//     this.sayHi = () => {
//         return `Hi ${this.name}`
//     };
//
//     return {
//         name,
//         gender
//     }
// }
//
// let student1 = new Student('Poxos', true);
// console.log(student1.sayHi());

// Suren
// ktpi student1.sayhi is not a function
// syntaxi mej yerkrord return@ sxala grac vor dzevavor pakagcer@ hanenq
// u name, gender@ grenq returni koxk@ kam @ndhanrapes jnjenq normal ktpi Hi Poxos

// David Sveta
// Kta error verchi returni patcharov

// Alex
// ktpi student1.sayHi-y function chi

// Hrach
// amena taki returni c erorr kta vorovhetev object chenq poxancum

// Alex
// errora talis vorovhetev Student-i mej return enq anum object u sayHi-y darnuma undefined u qani vor undefined-y function chi kanchelu jamanak erora talis

// 2) WHAT WILL BE THE OUTPUT AND WHY
// function Student(name, gender) {
//     this.name = name;
//     this.gender = gender;
//
//     this.sayHi = () => {
//         return `Hi ${this.name}`
//     };
//
//     return this.name
// }
// let student1 = new Student('Poxos', true);
// console.log(student1.sayHi());

// Suren
// ktpi Hi Poxos vorovhetev kanchvela student1-i (vor@ vor function cunstructorna) sayHi-@ 

// David Sveta
// ktpi Hi Poxos qani vor this.name constructor -ov Poxos  e @ndunum

// Alex
// Es depqum return-y chisht kashxati ev ktpi HI Poxos

// Hrach
// es normal ktpi hi Poxos syntaxy chishta

// Alex
// student1-in veragrvuma Student-y heto kanchvuma student1-i sayHi function u returna anum Hi this.name aysinqn tvyal depqum tpuma Hi Poxos

// 3) WHAT WILL BE THE OUTPUT AND WHY
// function Student(name, gender) {
//     this.name = name;
//     this.gender = gender;

//     this.sayHi = function() {
//         return `Hi ${this.name}`
//     };
// }
// let student1 = new Student('Poxos', true);
// let student2 = Object.assign({}, student1, {name: 'Petros'});
// student1.sayHi = () => `Goodbye ${student1.name}`;
// console.log(student1.sayHi());
// console.log(student2.sayHi());

// Alex: no answer

// Suren
// mi hat ktpi Goodbye Poxos vorovhetev student1-i sayHi-in veragrvela goodbye-@
// mi hat el takic ktpi petros vorovhetev student2-in assign-a arvel student 1-@ name-@ poxac

// David Sveta
// 1clg ktpi goodbye Poxos qani vor mtnum e ir verevi function mej student1 name el Poxos e 2clg ktpi hi Petros kmtni sayHi returni mej 

// Hrach
// student erkusi mej assign enq anuum student1 name: poxelov Petros

// Alex
// student1-in veragrvuma Student-y u talisa 'Poxos', true arjeqnery 
// heto student2-y copy-a anum student1-i arjeqnery u name-in talisa 'Petros' arjeqy u student2-i mej name-y "Petros"-a linum
// heto nor sayHi function-a grac vory veradardznuma `Goodbye ${student1.name}` heto kanchuma student1-i sayHi u tpuma Goodbye Poxos
// heto kanchuma student2-i sayHi-y u tpuma Hi Petros

// 4) WHAT WILL BE THE OUTPUT AND WHY
// function Student(name, gender) {
//     this.name = name;
//     this.gender = gender;

//     this.sayHi = () => {
//         return `Hi ${this.name}`
//     };
// }

// let student1 = new Student('Poxos', true);
// let student2 = student1;
// student1.sayHi = () => `Goodbye ${student1.name}`;
// console.log(student2.sayHi());
// console.log(student1.sayHi());

// Suren
// irar takic 2 hat Goodbye Poxos ktpi vorovhetev student2-in veragrvela student1-@
// erkusi hascen nuynna dra hamar mi tex vor sayHi-i hi-@ poxvela goodbye-ov erkusi
// vra el andradardzela

// David Sveta
// student1 ev student2 havasar en irar ev ayd erkus@ kancheluc clg kunenanq Goodbye Poxos qani vor mtnum e ***student1.sayHi = () => *** function mej

// Alex
// student 1-y u 2-y khavasaracni irar erku texnel ktpi Poxos u erkusin el kavelacni goodbye aysinqn kstacvi 2 angam Petros Goodbye

// Hrach
// erkusnel kanen goodbye Poxos Student2 in talisenq student 1 i hascen u iranc mej inch avelacnenq kam poxenq nuynen linelu

// Alex
// es angam erku depqumel tpuma Goodbye Poxos vorovhetev student2-in veragrvela student1-i hascen

// 5) WHAT WILL BE THE OUTPUT AND WHY
// function Student(name, gender) {
//     this.name = name;
//     this.gender = gender;

//     this.sayHi = function() {
//         return `Hi ${this.name}`
//     };
// }

// let student1 = new Student('Poxos', true);
// let student2 = new Student('Petros', true);
// let student3 = new Student('Martiros', true);
// student1.nested = student2;
// student2.nested = student3;
// console.log(student1);
// console.log(student1.nested.sayHi());
// console.log(student1.nested.nested.sayHi());

// Suren
// ktpi Hi Petros yev Hi Martiros vorovhetev student1-i nested-@ havasara
// darnum student 2-in isk student2-i nested-@ student 3-in
// yerb vor console loga arvum student1-i nested-@ da arden veraberuma Petrosin
// isk student1-i nested-i nested-@ Martirosin

// David Sveta
// 1clg um ktpi hi Petros vorovhetev student1 in avelacrel enq nested student2
// 2clg um ktpi hi Martiros qani vor student1 nested arden student2 e dra nested student3 vori name el Martiros er

// Alex
// es depqum Poxosy sarquma Petros isk Martirosin dzerq chi talis u verjum stacvuma Hi Petros Hi Martiros

// Hrach
// iranq unenumen nuyn hascenery

// Alex
// student-nerin veragrvuma Student-y tarber arjeqnerov heto student1-mej avelanuma nested key vory stanuma vorpes arjeq student2
// student2-i mejel avelanuma nested key student3 arjeqov, heto kanchvuma student1-i nested-i sayHi function-y u tpuma Hi Petros
// heto kanchvuma student1-i nested-i nested-i sayHi-y u tpuma Hi Martiros

