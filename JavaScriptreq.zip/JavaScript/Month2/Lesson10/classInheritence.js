// // -------------------class inheritence------------
// class User {
//     constructor() {
//         this.name = 'Unknown User';
//     }

//     arrow = () => console.log('sth');

//     like() {
//         console.log('like')
//     }

//     share() {
//         console.log('share')
//     }

//     post() {
//         console.log('post')
//     }
// }

// class User1 extends User{
//     constructor() {
//         super();
//     }

//     post() {

//     }
// }

// let user1 = new User1();
// console.log(user1);

// class User1 extends User {
//     constructor(name, age) {
//         super()
//         this.name = 'John';
//         this.age = '30';
//     }

//     like() {
//         console.log(`${this.name} like it`)
//     }

//     comment() {
//         console.log('comment')
//     }
// }

// let user1 = new User1();
// let user2 = new User();
// user2.comment()
// console.log(user1.post());

// chi ashxati
// petq e kanchel super@ constructori mej;
// erb kanchum enq class@ sovorakan depqum construcotry kanchvuma ev seta arvum this@ u veradarcvum obejct
// zharangman depqum da texi chi unenum vortev zharangox class@ spasuma vor da kani cnox construcotry
// bayc cnox contructory chi kanchvum qani vor menq haytararel enq arandzin constructor


// ---- aranc constructor ----
// class User1 extends User {
//     like() {
//         console.log(`${this.name} like it`)
//     }

//     comment() {
//         console.log('comment')
//     }
// }

// let user1 = new User1();
// console.log(user1);

// // user1.like()

// // super@ kanchuma cnoxi constructor@

// class User1 extends User {
//     constructor(name, age) {
//         super();              /*this.name = 'unknow user'*/
//         this.name = name;   /*name-@ poxvec*/
//         this.age = age;
//     }
//     like() {
//         console.log(`${this.name} like it`)
//     }

//     comment() {
//         console.log('comment')
// //     }
// // }

// // let user1 = new User1('John', 16);
// // console.log(user1);

// // user1.like()

// // // ---------- super.method() -----------

// class User1 extends User {
//     constructor(name, age) {
//         super();             
//         this.name = 'John'; 
//         this.age = '30';
//     }

//     like() {
//         console.log(`${this.name} like it`)
//     }

//     comment() {
//         super.like()
//         console.log('comment')
//     }
// }

// let user1 = new User1();
// console.log(user1);

// user1.comment()

// ---------------------------------------------------
// class User1 extends User {
//     constructor(name, age) {
//         super();              /*this.name = 'unknow user'*/
//         this.name = 'John';   /*name-@ poxvec*/
//         this.age = '30';
//     }

    // like() {
    //     console.log(`${this.name} like it`)
    // }

//     comment() {
//         super.post()
//         console.log('comment')
//     }
// }

// let user1 = new User1();
// console.log(user1);

// 1. ete child class-um ogtagorcum enq constructor apa petq e kanchel super() parenti construcotry henc skzbic
// 2. nor object stexceluc arrow functionenry constructori mejen grvum
// 3. zharangeluc child classum grvum e nayev 2rd keti nshvacnery
// 4. mnacacy aysinqn functionenrn grvum en prototypeum

// let super = {
//     x: 7
// }

// let obj = {
//     x: 6,
//     y: function () {
//         console.log(super.x);
//     }
// }