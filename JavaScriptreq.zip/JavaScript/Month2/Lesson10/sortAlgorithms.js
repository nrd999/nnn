// const _mergeArrays = (a, b) => {
//     const c = [];
//     while (a.length && b.length) {
//         c.push(a[0] > b[0] ? b.shift() : a.shift())
//     }

//     while (a.length) {
//         c.push(a.shift())
//     }
//     while (b.length) {
//         c.push(b.shift())
//     }

//     return c
// }

// const mergeSort = (a) => {
//     if (a.length <= 1) return a
//     const middle = Math.floor(a.length / 2)
//     const a_l = a.slice(0, middle)
//     const a_r = a.slice(middle, a.length)
//     const sorted_l = mergeSort(a_l)
//     const sorted_r = mergeSort(a_r)
//     return _mergeArrays(sorted_l, sorted_r)
// }

// console.log(_mergeArrays([1, 2, 5, 8], [3, 4, 6]))
// a_l = [1, 2, 5, 8]
// [1,2] [5,8]
// [1] [2] [5] [8]
// [1, 2, 5, 8]
// a_r = [7, 10, 6, 89, 3]
// [7, 10, 6, 89, 3]
// [7, 10] [6, 89, 3]
// [7] [10] [6] [89, 3]
// [7] [10] [1] [3, 89]
// console.log(mergeSort([1, 2, 5, 8, 7, 10, 6, 89, 3]));

// -------------------------------------------------------------
// const _mergeArrays = (a, b) => {
//     const c = [];
//     while (a.length && b.length) {
//       c.push(a[0] > b[0] ? b.shift() : a.shift())
//     }
  
//     return [...c, ...a, ...b];
// }
    
// const mergeSort = (a) => {
//     return a.length < 2 ? a : _mergeArrays(mergeSort(a.splice(0, a.length/2)), mergeSort(a))
// }
    
// console.log(mergeSort([1, 2, 5, 8, 7, 10, 6, 89, 3]));

// function bubbleSort(arr){
//     for(let i = 0 ; i < arr.length - 1 ; i++){
//         for (let j = 0 ; j < arr.length - 1 - i ; j++){
//             if(arr[j] > arr[j+1]){
//                 const temp = arr[j];
//                 arr[j] = arr[j+1];
//                 arr[j+1] = temp;
//             }
//         }
//     }
//     return arr;
// }

// console.log(bubbleSort([12,5,8,94,15,1,2,34,5,66,65,63,65]))

// -------------------------------------------------------------
// function quickSort(arr){
//     if (arr.length === 1 ) return arr;

//     const randomNum = arr[arr.length-1];
//     const smallNumArr = [];
//     const biggerNumArr = [];

//     for (let i = 0 ; i < arr.length - 1 ; i++){
//         if (arr[i] < randomNum){
//             smallNumArr.push(arr[i])
//         } else {
//             biggerNumArr.push(arr[i])
//         }
//     }

//     if (smallNumArr.length > 0 && biggerNumArr.length > 0){
//         return [...quickSort(smallNumArr) , randomNum , ...quickSort(biggerNumArr)]
//     } else if(smallNumArr.length > 0){
//         return [...quickSort(smallNumArr) ,  randomNum];
//     } else {
//         return [randomNum , ...quickSort(biggerNumArr)];
//     }

// }
// console.log(quickSort([1,21,4,45,66,89,31,1,5,2,512,5]))

// -------------------------------------------------------------
// function quickSort(arr){
//     if (arr.length < 2 ) return arr;

//     let index = Math.floor(Math.random() * arr.length);

//     let leftAndRight = arr.reduce((acc,el,i)=>{
//         if(i !== index){
//             el < arr[index] ? acc[0].push(el) : acc[1].push(el)
//         }
//         return acc
//     },[[],[]])

//     return [...quickSort(leftAndRight[0]), arr[index], ...quickSort(leftAndRight[1])]
// }
// console.log(quickSort([1,21,4,45,66,89,31,1,5,2,512,5]))

// -------------------------------------------------------------
// let arr = [9, 10,8,7,6,5,4,3,2,1];

// function sort(arr) {
//     for (let i = 0; i < arr.length; i++) {
//         for (let j = 0; j < arr.length; j++) {
//             if (arr[j] > arr[j + 1]) {
//                 let temp = arr[j]; 
//                 arr[j] = arr[j + 1];
//                 arr[j + 1] = temp;
//             }
//         }
//     }
//     return arr
// }

// console.log(sort(arr));
