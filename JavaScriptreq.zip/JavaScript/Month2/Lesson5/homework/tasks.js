// 1) greq function vor@ mer studentsi objectneric cankacac meki contextum kancheluc kveradarcni
//   tvyal object@ keyeri ev valuenri texery poxac
//   Orinak ete kanchem {Annai objecti contetxum} -----> kveradarcni {Anna: 'name', 20: 'age', true: 'gender', 8: 'id'}
//   functionn petq e lini lriv arandzin objectic durs
//   (esorva dasna u this@)

// const students = [
//     {
//         id: 8,
//         name: 'Anna',
//         gender: true,
//         age: 20
//     },
//     {
//         id: 7,
//         name: 'Mko',
//         gender: false,
//         age: 21
//     },
//     {
//         id: 3,
//         name: 'Sveta',
//         gender: true,
//         age: 22
//     },
//     {
//         id: 6,
//         name: 'Hrach',
//         gender: false,
//         age: 22
//     },
//     {
//         id: 4,
//         name: 'Suro',
//         gender: false,
//         age: 20
//     },
//     {
//         id: 1,
//         name: 'Alex',
//         gender: false,
//         age: 21
//     },
//     {
//         id: 2,
//         name: 'David',
//         gender: false,
//         age: 22
//     },
//     {
//         id: 5,
//         name: 'Alex',
//         gender: false,
//         age: 16
//     }
// ];

// Suro
// let obj = {
//     id: 4,
//     name: 'Suro',
//     gender: false,
//     age: 28
// }
// let swapped = Object.fromEntries(Object.entries(obj).map(a => a.reverse()))
// console.log(swapped)

// or

// let num = Math.floor(Math.random() * students.length);
// let newObj = students[num];

// function reverseObj() {
//     console.log(this);
//     return Object.fromEntries(Object.entries(this).map(a => a.reverse()))  
// }
// // console.log(reverseObj(newObj));
// console.log(reverseObj.call(newObj))

// David Sveta
// function foo(userName){
//     let revers = this.filter(obj => obj.name === userName)
//     console.log(revers);
//     return Object.keys(revers[0]).reduce((val, key) =>{
//         val[revers[0][key]] = key;
//         return val;
//     },{});    
// }
// console.log(foo.call(students,'Hrach'))

// Hrach
// let num = Math.floor(Math.random() * obj.length);
// let newObj = obj[num];

// function reverseObj(newObj){
//     return  Object.fromEntries(Object.entries(newObj).map(a => a.reverse()))  
// }
// console.log(reverseObj(newObj));

// Alex
// let random = students[Math.round(Math.random() * (students.length - 1))]
// let obj2 = {};
// function foo() {
//     for(let elem in random) {
//         obj2[this[elem]] = elem
//     }
//     return obj2
// }

// console.log(foo.call(random));

// Anna
// let x;
// let y;
// let object = {};
// function f() {
//     for (let key in this[0]){
//         x = this[0][`${key}`] + "";
//         y = `${key}`;
//         object[x] = y;
//     }
//     return object
// }

// let res = f.bind(students)
// console.log(res());

// ----------- ANSWER -----------
// function f() {
//     let obj = {};
//     for(let key in this) {
//         obj[this[key]] = key
//     }
//     return obj
// }

// console.log(f.call(students[0]));

// 2) ger function vor@ kstana mer students arrayi objectneric voreve mek@ ev kveradarcni url(aysinqq string)
//    vor@ kunena hetevyal tesq@ orinak Annai objecty stanalu depqum
//    'http://students.com/path?id=8&name=Anna&gender=true&age=20'
//    aysinqn minchev ? nshan@ static nuyn textna dranic heto kaxvac objectic
//    (es xndirn esorva dasi het kap chuni)

// Suro
// let output = "";

// for(let i = 0; i < students.length; i++){
//     output = output + students[i].id+"="+students[i].name+"="+students[i].gender+"="+students[i].age+"&"
// }

// output = output.substring(0, output.length-1);
// console.log(output)

// David Sveta
// let student = {id: 3,name:'Sveta',gender: true,age: 20}
// let http = "http://students.com/path?"
// const foo = student => http + Object.keys(student).map(item =>`${item}=${student[item]}`).join('&')
// console.log(foo(student))

// Hrach
// function send(newObj){
//     if(newObj.gender === false){
//         return  `http://students.com/path?id=${newObj.id}&name=${newObj.name}&gender=${newObj.gender}&age=${newObj.age} `
//     }
//     else{
//         return "gender is True"
//     }
// }
// console.log(send(newObj))

// Alex
// let random = Math.floor(Math.random() * students.length)
// function foo() {
//     let url = 'http://students.com/path?';
//     let res2 = Object.keys(students[random]);
//     let res3 = Object.values(students[random])
//     for(let i = 0; i < students.length / 2; i++){
//         url += `${res2[i]}=${res3[i]}&`
//     }   
//     return url.substring(0, url.length - 1)
// }

// console.log(foo())

// Anna

// let object = {}
// function f(obj) {
//     let y = "";
//     for (let key in obj){
//         y += key +"="+obj[key]+"&";
//     }
//     y = "http://students.com/path?" + y
//     return y.slice(0, -1);
// }

// console.log(f(students[0]));

// ----------- ANSWER -----------
// function f(student) {
//     return `http://students.com/path?id=${student.id}&name=${student.name}&gender=${student.gender}&age=${student.age}`
// }
//
// console.log(f(students[0]));

// 1) WHAT WILL BE THE OUTPUT AND WHY
// let student = {
//     name: 'John',
//     getName: function () {
//         return this.name;
//     }
// };

// let getName = student.getName;
// console.log(getName.call(student));
// console.log(student.getName());

// Suro
// ktpi irar takic erku hat John vorovhetev erku console.log-n el nuyn bann en
// getName@ vercrela studenti this-@

// David Sveta
// erku kanchi jamanak el kta John qani erkusum el this@ chisht e voroshvum i shnorhiv *** let getName = student.getName;

// Alex
// getName-in veragrvuma student-i getName-y heto kanchvuma getName u vercnuma student-i name-y aysinqn tpuma John 
// heto kanchvuma student-i getName function-y u tpuma eli John

// Anna
// getName popoxakanin veragrum enq objecti miji funkcian, ev kanchum enq call-ov vorpisi funkciayi this-y vercni studenty, ev ktpi John,
// myus toxov kanchum en objecti miji funkcian vory veradardznum e john

// 2) WHAT WILL BE THE OUTPUT AND WHY
// function foo () {
//     console.log(this.a)
// }
//
// let obj = {
//     foo: foo,
//     a: 5
// };
//
// foo();
// foo.bind(obj);
// foo();
// obj.foo();

// Suro
// foo()-n ktpi undefined vorovhetev chuni this.a
// foo.bind(obj)-n ktpi vochinch chi tpi
// foo()-n noric ktpi undefined
// foo: foo-i hashvin kvercni ira verevi function-i a-n yev valuen kdarna 5 (this.a-n aysinqn) u ktpi 5

// David Sveta
// skzbum klini undefined qani vor foo mej (a) chi gtnum
// 2rd i jamanak vochinchi chi ta qani vor bind enq ogtagorcum vor@ petq e veragrvac lini inchvor popoxakani ev kancheinq ayd popoxakan@
// 3rd i jamanak nuyn arajini skzbunqn e ashxatum kta undefined
// 4rd i jamanak kta 5 qani vor foo this@ ir obj e 

// Alex
// skzbic tpuma undefined vorovhetev a-n undefined-a heto foo-n kapuma obj-in bayc chi kanchum u voch mi ban chi tpum 
// heto eli kanchvuma foo-n u tpuma undefined heto kanchvuma obj-i foo-n u tpuma obj-i a-n aysinqn 5

// Anna
// foo-n kanchenq this.a-n haskanum e windowi miji a, undefined
// hajord toxov foo-i this-y darnum e obj-n bayc qani vor chenq veragrel popoxakani chi tpi, undefined
// ktpi 5 

// 3) WHAT WILL BE THE OUTPUT AND WHY
// let foo = () => {
//     console.log(this.a)
// };
// let obj = {
//     foo: foo,
//     a: 5
// };

// let otherFoo = foo.bind(obj);
// obj.foo();
// foo.call(obj);
// otherFoo();

// Suro: no answer

// David Sveta
// 3um el kta undefined qani vor arrow function e 

// Alex
// 3 hat undefined ktpi vorovhetev arrow function-ov chi linum this grel

// 4) WHAT WILL BE THE OUTPUT AND WHY
// let obj = {
//     foo: function () {
//         let func = () => console.log(this.a);
//         func()
//     },
//     a: 5
// };

// let anotherFoo = obj.foo;
// anotherFoo();
// anotherFoo.call.obj; 
// anotherFoo.call(obj);
// obj.foo();

// Suro: no answer

// David Sveta
// skzbum ktpi undefined qani vor mtnelov foo function mej ev chi gtni this a
// anotherFoo.call(obj) ktpi 5 qani vor call enq anum obj ev vercnum  e a-i value-n
// verjum ktpi 5 vmtnelov functioni mej func() noric kanchum enq ev tpum e 

// skzbum ktpi undefined vorovhetev arrow function-a heto call-ov kanchvuma u tpuma obj-i a-n aysinqn 5 myus toxum chenq kanchel u ban chi tpum heto kanchvuma obj- foo-n u tpuma 5

// 5) WHAT WILL BE THE OUTPUT AND WHY
// let obj1 = {
//     foo: function () {
//        console.log(this.a)
//     },
//     a: 5
// };
// let obj2 = {
//     a: 10
// };
// obj1.foo();
// obj1.foo.call(obj2);
// obj1.foo.bind(obj2);
// obj1.foo();

// Suro
// erku obj1.foo()-er@ ktpen 5 vorovhetev ira this.a-n 5-a
// en erkus@ chgitem

// David Sveta
// ktpi 5 qani vor ir this obj1 vorn el 5 e
// call mijocov poxum enq this @ obj2 ov u kta 10
// bind i depqumm vochinch chi ta qani vor bind chen veragrel popoxakani u chenq kanchel
// hajordn el ashxatum e arajini pes u tpum 5

// Alex
// skzbic vercnuma obj1-i a-n u tpuma 5 heto call-ov foo-n kapvuma obj2-in u tpuma 10 heto bind-ov eli kapvuma bayc chi kanchum heto tpuma eli 5

// Anna
// 5
// 10
// bind-y chenq veragrel popoxakani
// 10