// 1) Greq function constructor Person, vory vorpes argument kstana name ev age.
// Baci ayd argumentnery, kunena nayev stomach(stamoqs) anunov key, vory datark array e.
// Constructoric durs, iren hnaravorutyun tveq katari erku gorcoxutyun: eat("uteliq"), poop(). (ogtagorceq prototype)
// Ete kanchem eat-y u poxancem incvor uteliq, et uteliqy piti avelana stomach arrayum. Ete ayd arrayum elementneri qanaky hasni 10i,
// el chenq kara ban tanq uti es mardy. poop() funkcian henc kanchem array-y piti datarkvi.
// Personi hamar greq nayev toString() method, vory kveradardzni string` mer personi name-ov u age-ov("Mary, 20")

// Gor
// function Person (name, age) {
//     this.name = name;
//     this.age = age;
//     this.stomach = ['sth'];
// }

// Person.prototype.eat = function (food) {
//     if (this.stomach.length >= 10) {
//         return "Thank you, i'm not hungry";
//     }
//     this.stomach.push(food);
// }
// Person.prototype.poop = function () {
//     console.log('-------');
//     this.stomach.length = 0;
//     // this.stomach = []
// }
// Person.prototype.toString = function () {
//     return `${this.name} is ${this.age} years old`;
// }

// let person1 = new Person('Mary', 20);
// person1.eat('pizza');
// person1.eat('pizza');
// person1.eat('pizza');
// person1.eat('pizza');
// console.log(person1.toString())

// console.log(person1);

// person1.poop();
// console.log(person1.stomach);

// console.log(person1);
// console.log(person1.toString());

// Alex
// function Person(name, age){
//     this.name = name;
//     this.age = age;
//     obj2 = {
//         stomach : []
//     }
// }

// let obj = new Person('Alex', 15)

// Person.prototype.toString = function () {
//     return `${this.name}, ${this.age}`;
// }

// Person.prototype.eat = function (...args) {
//     console.log(obj2.stomach = args.slice(0, 10))
//     // for(let elem of args){
//     //     obj5.stomach.length !== 10 && obj5.stomach.push(elem)
//     // }
// }

// Person.prototype.poop = function () {
//        obj2.stomach.splice(0) && console.log(obj2.stomach);
//     // obj.stomach.length = 0; && console.log(obj5.stomach);
// }

// console.log(obj2);
// // obj.toString()
// console.log(obj.stomach);
// console.log(obj.eat(1, 2, 3, 4, 5, 6, 7,1, 2, 3, 4, 5, 6, 7));
// obj.poop()

// David Sveta
// function Person(name, age) {
//     this.name = name;
//     this.age = age;
//     this.stomac = [];   
// }
// Person.prototype.toString = function () {
//         console.log(`Hi my name is ${this.name} I am ${this.age} years old`)
// }
// Person.prototype.eat = function (x) {
//     this.stomac.push(x)
// //     if(this.stomac.length > 10){
// //         this.stomac.length = 10;
// //     }
// // }
// // Person.prototype.pop = function () {
// //     this.stomac = []
// // }
// // let person1 = new Person('Tom', 10);

// person1.toString()
// person1.eat('hamburger')
// person1.eat('hotdog')
// person1.eat('sandwich')
// person1.eat('pizza')
// person1.eat('fish')
// person1.eat('taco')
// person1.eat('fries')
// person1.eat('cheeseburger')
// person1.eat('yogurt')
// person1.eat('chicken')
// console.log(person1);
// console.log(person1.pop());
// console.log(person1);

// Hrach
// function Person (name, age){
//     this.name = name;
//     this.age = age;
//     this.stomach = [];
//     this.poop = function (){
//         this.stomach.length = 0
//     }
// }
// Person.prototype.poop = function (){
//     this.stomach.length = 0
// }
// Person.prototype.eat = function(food){
//         this.stomach.push(food)
//         if(this.stomach.length === 10){
//                 return this.poop()
//         }
// }


//     Person.prototype.toString = function () {
//     console.log(`Hello My Name is ${this.name} I am ${this.age} Years Old`)
// }        

// let account = new Person('Tom', 10);

// account.toString()
// account.eat('Pizza')
// account.eat('Sushi')
// account.eat('Sandwich')
// account.eat('Ice-Cream')
// account.eat('Fires')
// console.log(account);
// account.poop()
// // account.eat('Burger')
// account.eat('Shawarma')
// account.eat('Dolma')
// account.eat('Desert')
// account.eat('Kabab')
// console.log(account);

// console.log(account.poop());


// Mariam
// function Person(name,age){
//     this.name = name;
//     this.gender = age;
//     this.stomach=[]
// }
// let foo=new Person();

// Person.prototype.eat=function eat(){
// for (let i = 0; i < 10; i++) {
//            if(Person(this[i])) {
//                this.stomach.push(this[i])
//            }
//            return eat
           
// }
// Person.prototype.poop=function poop(){
//    return this.stomach.length=0;
// }

// // ---------- Answer ----------
// function Person(name, age) {
//     this.name = name;
//     this.age = age;
//     this.stomach = [];
// }
  
// Person.prototype.eat = function(food) {
//     if (this.stomach.length < 3) {
//         this.stomach.push(food);
//     }
// };

// Person.prototype.poop = function() {
//     this.stomach = [];
// };

// Person.prototype.toString = function() {
//     return `${this.name}, ${this.age}`;
// };

// let user1 = new Person('John', 18);
// user1.eat('Pizza')
// user1.eat('Sushi')
// user1.eat('Sandwich')
// console.log(user1);
// user1.poop()

// let obj = {
//         x: 5
// }

// console.log(obj);

// obj.__proto__.y = 6
// debugger;
// let arr = [1,2]

// console.log(arr);
// for(let i = 0; i < arr.length; i++) {
//         console.log(arr[i]);
// }

// arr.push(6)
// arr.pop()

// let obj = {};

// console.log(obj);

// obj.name = 'Alex';