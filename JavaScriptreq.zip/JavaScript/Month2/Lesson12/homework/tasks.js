// Unem 2 hat datark input, ev 2 button. Buttonneric meki valuen + e myusiny -. 
// +y patasxanatu a gumarman gorcoxutyan hamar -y hanman.
// Unem Result vory iskzbane 0 a. Piti enpes anenq vor usery inputneri mej tver gri,
// sexmi + buttonin, cuyc tanq ir grac tveri gumary, - in sexmeluc tarberutyuny.
// Ete tiv chi grel u sexmuma knopkaneric voreve mekin, text cuyc tveq vory kasi vor usery piti tiv gri partadir.

// 1. WHAT WILL BE THE OUTPUT AND WHY?
// let person = {
//     name: 'John',
//     surname: 'Smith',
//     friends: ['empty' undefined]
// }
// let str = '';
// for (let key in person) {
//     if (person.hasOwnProperty(key)) {
//         str += key
//     }
// }
// console.log(str);


// 2. WHAT WILL BE THE OUTPUT AND WHY?
// const person = {
//     knowladges: ['programming', 'driving'],
//     child: {
//         name: 'John',
//         surname: 'Smith'
//     }
// }
// console.log(typeof person.child.__proto__)
// console.log(typeof person.knowladges[0].__proto__)


// 3. WHAT WILL BE THE OUTPUT AND WHY?
// var obj = {
//     foo: 'bar',
//     func: function () {
//         var self = this;
//         console.log(this.foo);
//         console.log(self.foo);
//         (() => {
//             console.log(this.foo);
//             console.log(self.foo);
//         })
//     }
// }
// obj.func();

// 4. WHAT WILL BE THE OUTPUT AND WHY?
// function foo () {
//     return {
//         bar: 'hello'
// };
// }
// function foo1 () {
//     return
//     {
//         bar: 'hello'
//     }
// }
// foo ();
// foo1();