// --------- static methods -----------
// class User {
//     constructor() {
//         this.name = 'Unknown User';
//     }

    // static x = 5;

    // static like() {
    //     return 'like'
    // }

    // share() {
    //     return 'share'
//     }

// }

// let user = new User();
// console.log(user);

// karox enq kanchel static methodn
// User.like()
// console.log(User.x);

// static methodnern u propertinern zut classi hamar en aysinqn petq chi vor drancic stexcvox object@ vercni ayd method@