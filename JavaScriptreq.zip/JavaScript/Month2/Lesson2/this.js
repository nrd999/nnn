// --------------- WINDOW GLOBAL OBJECT ---------------
// In browser global object is window
// universal globalThis

// // console.log(window);
// var a = 5;
// console.log(window);

// let arr = new Array();
// Array() is in window

// --------------- "use strict" ---------------
// "use strict"
// x = 10;
// console.log(x);

// console.log(this);
// function foo() {
//     console.log(this);
// }

// foo()

// Assignment to a non-writable property
// var obj = {
//     x: 42
// };
// Object.defineProperty(obj, 'x', { writable: false });
// obj.x = 9;
// console.log(obj);

// --------------- this ---------------
// console.log(this);
// let person = {
//     name: 'Smith',
//     sayHi: function () {
//         console.log(this);
//         return `Hi ${person.name}`
//     }
// };

// person.name = 'John';
// person.sayHi()

// let obj = {
//     x: 4,
//     y: {
//         id: 16,
//         sayHi: function () {
//             console.log(this);
//         }
//     }
// }

// obj.y.sayHi()

// --------------------------------------
// let anotherPerson = person;
// person = null;
// console.log(anotherPerson.sayHi())

// -------- we can write this instead object name --------
// let person = {
//     name: 'John',
//     sayHi: function () {
//         return `Hi ${this.name}`
//     }
// }
//
// console.log(person.sayHi());
// let anotherPerson = person;
// console.log(person.sayHi());
// person = null;
// console.log(anotherPerson.sayHi())

// ---------------------------------------------------------------
// let student1 = {
//     name: 'Alex',
//     sayHi: function () {
//         return `Hi ${student1.name}`
//     }
// }
//
// let student2 = {
//     name: 'Anna',
//     sayHi: function () {
//         return `Hi ${student2.name}`
//     }
// }

// let student1 = {
//     name: 'Alex',
//     // sayHi: function () {
//     //     return `Hi ${this.name}`
//     // }
// }
// let student2 = {
//     name: 'Anna',
// }
// function sayHi() {
//     return `Hi ${this.name}`
// }
// console.log(sayHi());
// student1.sayHi = sayHi;
// student2.sayHi = sayHi;

// console.log(student1.sayHi())
// console.log(student2.sayHi())
// --------------------------------------
// this without context
// function f() {
//     console.log(this)
// }

// f();

// --------------------------------------
// let obj = {
//     id: 1,
//     sayHi: function () {
//         console.log(this);
//         console.log(this.id);
//     }
// }

// obj.sayHi();
//
// let f = obj.sayHi;
// f()

// ---------- arrow functions haven't this ----------
// let obj = {
//     id: 1,
//     sayHi: () => {
//         console.log(this);
//         console.log(this.id);
//     }
// }

// console.log(obj.sayHi());
// let x = obj.sayHi
// x()

// -------------------------------------------------

// arrow function this take parent function this
// let obj = {
//     id: 1,
//     sayHi: function () {
//         let f = () => console.log(this);
//         f()
//     }
// }
// //
// obj.sayHi()

// let obj = {
//     word: 'letter',
//     letters: ['a', 'b', 'c'],
// //     showLetters: function () {
// //         this.letters.forEach(item => console.log(`${this.word} is ${item}`))
// //     },
// // }

// // obj.showLetters()

// // ------------------------------------------------------
// let obj = {
//     a: 1,
//     showLetters: function (b) {
//         let self = this;
//         return function f(c) {
// //             console.log(c + b + self.a)
// //         }
// //     }
// // }

// let obj1 = {
//     a: 2,
//     showLetters: function (b) {
//         let self = this;
//         return function f(c) {
//             console.log(c + b + self.a)
//         }
//     }
// }
// let f = obj1.showLetters(2);
// f(3)


// let x = window;
// console.log(x);
// window.__proto__.constructor.name = 'hopar'
// Window.prototype.constructor.name = 'Sth'
// console.log(window);

// console.log(this == window);