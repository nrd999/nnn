// <div id='timer'>0</div>;
// unenq nshvac div@
// stexceq 3 hat button, start, stop, reset
// 1. start-@ ksksi mecacnel 0 tivy vorpes timer
// 2. stop@ stop kta
// 3. resety kzroyacni
// 4. minchev stop chtanq reset chenq karox anel

// 1. WHAT WILL BE THE OUTPUT AND WHY
// console.log(b)
// console.log(a)
// let a = 6;
// var b = 9;

// David Sveta
// 1in clg um ktpi undefined vorovhetev b haytararvac e irenic heto var-ov 
// 2rd um kta error eli clg ic heto e haytararvac ev let ov 

// Gor
// undefined, cennot access a before initalization

// Alex
// ktpi undefined vorovhetev var-ova haytararvac u ktpi error vorovhetev let-ova haytararvac

// Anna
// b - undefined,
// a- error

// 2. WHAT WILL BE THE OUTPUT AND WHY
// let arr = {
//     first: 1,
//     second: 2,
// }
// console.log(arr[1])
// console.log(arr['first'])

// David Sveta
// 1-in clg kta undefined vorovhetev mer arr -@ object e ev chuni index
// 2rd um kta mer first-i arjeq@ vor@ 1 e 

// Gor
// undefined qani vor menq 1 in value chenq talis;
// 1

// Alex
// ktpi undefined vorovhetev 1-ov key chka u first-i arjeqy 1 

// Anna
// 2
// 1

// 3. WHAT WILL BE THE OUTPUT AND WHY
// let timerID = setInterval (function () {
//     console.log(1)
// }, 1000);

// David Sveta
// 1 vrk mek ktpi mer clg um 1

// Gor
// amen mi varkyany mek ktpi 1;

// Alex
// amen 1 vayrkyanum ktpi 1

// Anna
// amen mek vayrkyan heto ktpi 1

// 4. WHAT WILL BE THE OUTPUT AND WHY
// let a = 4;
// setTimeout(function() {
//     console.log(a);
//     ++a
// });

// console.log(a);

// David Sveta
// ktpi 4 qani vor mer a-n 4 e isk a++@ haytararvac e clg-ic heto

// Gor
// ktesnenq 4
// bayc inqy meka ansinxrona ashxatelu;

// Alex
// mi angam ktpi 4 vorovhetev setTimeout-a u ++a-y nerqevuma grac 

// Anna
// ktpi mek hat 4, vayrkyan chenq tvel te qani vayrkyan heto tpi

// 5. WHAT WILL BE THE OUTPUT AND WHY
// setTimeout(function () {
//     setTimeout(function () {
//         console.log(222);
//     }, 2000);
// }, 1000);

// David Sveta
// ktpi 2vrk heto 222

// Gor
// nax araji set i 1 varkyany kancni heto myusi 2 varkyany u ktesnenq 222;

// Alex
// 1 vayrkyan heto kashxati function-y u kmtni setTimeout-i mej u 2 vayrkyan heto ktpi 222

// Anna
// 3 vayrkyan heto ktpi 222

// 6. WHAT WILL BE THE OUTPUT AND WHY
// let a = 7;
// setTimeout(function () {
//     setTimeout(function () {
//         console.log(a);
//     }, 0);
//     console.log(++a);
// }, 2000);

// David Sveta
// skzbum ktpi 2vrk heto 8 qani vor clg um 7@ darnum e 8
// heto miangamic (0) kashxati myus setTimeout@ vortex a-n darcel er 8 
// kunenanq erku 8

// Gor
// 2 varkyan heto ktesnenq 8, 8;
// qani vor arajiny kashxati taki console.log y;

// Alex
// skzbum kataruma console.log-y u tpuma ++a aysinqn 8 heto ashxatuma setTimeout-y u tpuma 8

// Anna
// erku vayrkyan heto ktpi 7 8

// 7. vorn e object??
// let array = {};
// let obj = {};
// let obj = new Object();
// let obj = Array.prototype
// console.log(obj);

// David Sveta
// 4n el object en 

// Gor
// 4nel objecten;

// Alex
// bolornel object en. 1 u 2-y object en, 3-y urish dzeva haytararvac bayc eli objecta, 4-y objecta vororvhetev prototype-y eli hamarvuma object

// Anna
// bolory baci Array.prototype-ic 

// 8. QANI METHOD KA person OBJECTUM
// let person = {
//     name: undefined,
//     surname: 'Johnson'
// }
// person.age = 88;

// David Sveta
// clg kunenanq name,surname,age irenc valuenerov

// Gor
// konkret objecum chka bayc prototypei mech kan ir jarangvac methodnery;

// Alex
// personi mej avelanuma age-key u unenuma 3 hat key ir arjeqnerov

// document.all.from()






