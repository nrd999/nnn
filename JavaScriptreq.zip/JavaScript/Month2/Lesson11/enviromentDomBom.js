// --------------- enviroment ---------------
// js@ crossplatforma, aysiqnn ashxtauma amen tex, ira asxhatelu tex@(browser, node...) kochvuma enviroment(mijavayr)
// tvyal enviroment@ baci lezvic hnaravorutyuna talis ogtagorcel nayev ira objectner@

            // window
// DOM            BOM            JS
// document      navigator      object
// ....          location       array
//                .....          ....

// ------ BOM ------
// Browser Object Model
// console.log(navigator) 
// browser info
// console.log(location)

// ------ DOM ------
// Document Object Model
// tramadruma eji amboxj parunakutyun@ objectneri tesqov,
// tramadruma functionner eji parunakutyuny poxelu hamar
// console.log(document);