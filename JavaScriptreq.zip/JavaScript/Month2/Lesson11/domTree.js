// ------- dom tree -------
{/* <html>
    <head>
        <title>title</title>
    </head>
    <body>
        text
    </body>
</html> */}
// dom@ html documentna cari tesqov (dom tree)
// document object model
// bolor tager@ nerkayanum en objectneri tesqov

// {
//     html: {
//         head: {
//             title: {}
//         },
//         body: {}
//     }
// }
// html@ document.documentElement domi amenaverevi objectna
//
// console.log(document.documentElement);
// let documentElement = {
//     head: {
//         title: {}
//     },
//     body: {}
// }

// orinak
{/* <body>
    <div>
        <span>text1</span>
        <span>text</span>
    </div>
    <div>
        <div>
            <span></span>
        </div>
    </div>
</body> */}

// {
//     div1: {
//         span1: {},
//         span2: {},
//     },
//     div2: {
//         div: {
//             span: {}
//         }
//     }
// }