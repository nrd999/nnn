// function User() {
//     this.name = 'John';
// }
// function User1() {};
// User.prototype.like = function () {
//     return 'like'
// }
// //
// User1.prototype = Object.create(User.prototype);
// //
// const obj = new User1();
// console.log(obj)
// console.log(obj.like())

// Inheriting own properties
// function User() {
//     this.name = 'John';
// }
// User.prototype.like = function () {
//     return 'like'
// }
// function User1() {
//     User.call(this)
// }

// User1.prototype = Object.create(User.prototype);

// console.log(new User())
// console.log(new User1())

// const obj = new User1();
// console.log(obj)
// console.log(obj.like())

//----------------------------------------
// function User() {}

// User.prototype.like = function () {
//     return 'like'
// }

// User.prototype.share = function () {
//     return 'share'
// }

// function User1() {}

// console.log(User.prototype);
// console.log(User1.prototype);

// User1.prototype = Object.create(User.prototype);
// console.log(User.prototype);
// console.log(User1.prototype);

// User1.prototype.like = function () {
//     return 'user1 like'
// };

// User1.prototype.comment = function () {
//     return 'comment'
// };

// let x = new User1()
// console.log(User.prototype);
// console.log(User1.prototype);

// console.log(x.like());
