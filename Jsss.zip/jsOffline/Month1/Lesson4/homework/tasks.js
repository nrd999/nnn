// 1) WHAT WILL BE THE OUTPUT AND WHY
// let str = 'my name is ana';
// let length = str.length - 1;
// for (let i = 0; i < str.length; i++) {
//    if(i === 2 || i === 7 || i === 10) {
//        console.log(str[i] + str[length]);
//        length--
//    }
// }


// 2) WHAT WILL BE THE OUTPUT AND WHY
// let x = 10 > 5;
// while(x) {
//     console.log('dont test it in console');
//     x = !!x
// }

// 3) Greq nuyn code@ while-i case-i mijocov
// for(let i = 0; i < 10; i++) {
//     console.log(i)
// }

// 4) Greq nuyn code@ for-i mijocov mijocov
// let x = 5;
// while (x !== 10) {
//     console.log(x);
//     x++
// }

// 5) while cikli mijocov tpeq 10-100 mijakayqum bolor tver@

// 6) for loop-i mijocov reversedName popoxakanin veragreq name popoxakan@ aynpes vor text@ lini ajic dzax grvac ev tpeq:
// orinak ete name = 'JOHN' petq e stanaq 'NHOJ'

// 7) for loop-i mijocov tpeq 1-1000 mijakayqum bolor minaish ev erknish tvery

// 8) for loop-i mijocov tpeq 1-1000 mijakayqum(1-@ ev 1000-@ neraryal) bolor kent tveri gumar@ ---->>  patasxan@ petq e stanaq 250000

// 9) while cikli mijocov tpeq 1-ic 10 mijakayqum gtnvox 3rd handipac zuyg tiv@;