// ---------------- for  ------------
//LOOPS ARE A WAY TO REPEAT THE SAME CODE MULTIPLE TIMES.

// execute numbers from 0 - 10;
// console.log(1);
// console.log(2);
// console.log(3);
// console.log(4);
// console.log(5);
// console.log(6);
// console.log(7);
// console.log(8);
// console.log(9);
// console.log(10);

// or

// for(let i = 1; i <= 10; i*=2) {
//     console.log(i)
// }

// WE CAN WRITE LIKE THIS BUT DONT DO THIS


// for(;;) {
//     console.log(i)
// }

//ONE CODE EXECUTE CALLED ITERATION

// ----if in loop----

// let num = 5;
// for (let i = 0; i < 10; i++) {
//     console.log(`iteration ${i}`);
//     if (i === num) {
//         console.log(i);
//     }
// }

// -----break-----

// let num = 5;
// for (let i = 0; i < 10; i++) {
//     console.log(`iteration ${i}`);
//     if (i === num) break;
// }

// ------continue---> next iteration------

// let num = 5;
// for (let i = 0; i < 10; i++) {
//     console.log(`iteration ${i}`);
//     if (i === num) continue;
//     console.log(i);
//     console.log('No break')
// }
