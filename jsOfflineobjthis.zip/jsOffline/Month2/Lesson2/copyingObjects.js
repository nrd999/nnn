// let user = {
//     id: 1,
// }

// let admin = user;

// user.name = 'John';

// console.log(user);
// console.log(admin);

// ------- comparing objects ==, === -------
// let obj1 = {};
// let obj2 = {};

// console.log(obj1 == obj2);
// console.log(obj1 === obj2);

// ----------------------------------------
// let obj1 = {};
// let obj2 = obj1;

// console.log(obj1 == obj2);
// console.log(obj1 === obj2);

// ------- objects with const -------
// const obj = {
//     id: 5
// }
// obj = {};

// const obj = {
//     id: 5
// }
// obj.skill = [];
// // //
// console.log(obj);

