// ------ SPLICE ------

// let arr = [5, 'SOME', true];
// let returnedVal = arr.splice(1, 1, 'home'); // CHANGES ARRAY;
// console.log(arr);
// console.log(returnedVal); // RETURNS REMOVED ELEMENTS;

// let returnedValue = arr.splice(1);
// console.log(arr);
// console.log(returnedValue);

// let returnedValue = arr.splice(1, 2);
// console.log(arr);
// console.log(returnedValue);

// let returnedValue = arr.splice(1, 1, 'a', 'b', 'c');
// console.log(arr);
// console.log(returnedValue);

// let returnedValue = arr.splice(1, 0, 'a', 'b', 'c');
// console.log(arr);
// console.log(returnedValue);

// let returnedValue = arr.splice(-1, 0, 'a', 'b', 'c');
// console.log(arr);
// console.log(returnedValue);

// ------ SLICE ------
// let arr = [5, 'SOME', true, 'a', 154];

// let returnedVal = arr.slice(1, 4); // DOES NOT CHANGE ARRAY;
// console.log(arr);
// console.log(returnedVal); //RETURNS ARRAY WITH COPIED ELEMENTS;

// let returnedVal = arr.slice(1);
// console.log(arr);
// console.log(returnedVal);

// let returnedVal = arr.slice(-3, -1);
// console.log(arr);
// console.log(returnedVal);

// let returnedVal = arr.slice();
// console.log(arr);
// console.log(returnedVal);

// ALSO USED FOR STRINGS 

// ------ CONCAT ------
// let arr = [5, 'SOME', true, 'a', 154];

// let returnedVal = arr.concat(1, 5) // DOES NOT CHANGE ARRAY;
// console.log(arr);
// console.log(returnedVal); // RETURNS CONCATED ARRAY;

// SAME AS SPREAD
// let returnedVal = [...arr, ...[5,7]];
// console.log(arr);
// console.log(returnedVal);

// ------ REVERSE ------
// let arr = [5, 'SOME', true, 'a', 154];

// let returnedVal = arr.reverse() // CHANGES ARRAY;
// console.log(arr);
// console.log(returnedVal); //RETURNS CHANGED ARRAY;

// ------ JOIN, SPLIT ------
// let arr = ['l', 'l', 'l', 'l', 'l'];

// let returnedVal = arr.join('a ') // DOES NOT CHANGE ARRAY;
// console.log(arr);
// console.log(returnedVal); // RETURNS CHANGED STRING;

// let str = 'lalalala';
// let returnedVal = str.split('')
// console.log(str);
// console.log(returnedVal);

// let str = 'John, Doe';
// let returnedVal = str.split(', ')
// console.log(str);
// console.log(returnedVal);

// ------ ARRAY.ISARRAY ------
// let arr = ['l', 'l', 'l', 'l', 'l'];
// let notArr = 7;
//
// console.log(Array.isArray(arr));
// console.log(Array.isArray(notArr));

// ------ FINDING METHODS ------
// let arr = [9, 'SOME', true];

// let returnedVal = arr.indexOf('SOME')
// console.log(returnedVal); // INDEX OF ELEMENT or -1

// let returnedVal = arr.includes('SOME')
// console.log(returnedVal); // RETURNS TRUE OR FALSE

// ------ FOREACH ------
// let arr = [9, 'SOME', true];
// arr.forEach(
//     function (item, index, array) {
//         console.log(`${item} has index ${index} in [${array}]`)
//     }
// )

// ------------------------------------------

// function showLog(item, index, array) {
//     console.log(`${item} has index ${index} in [${array}]`)
// }
//
// arr.forEach(showLog)

// ------------------------------------------

// arr.forEach((item, index, array) => console.log(`${item} has index ${index} in [${array}]`));

// ------ FIND ------
// let arr = [6, 10, 15, -5];
//
// let res = arr.find((item, index, array) => item > 7);
// console.log(res)

// let res = arr.find(function (item) {
//     return item > 7
// })
// console.log(res)

// ------ FILTER ------
// let arr = [6, 10, 15, -5];
//
// let res = arr.filter((item, index, array) => item > 7);
// console.log(res);
// console.log(arr);

// let res = arr.filter(function (item) {
//     return item > 7
// })
// console.log(res)

// ------ MAP ------
// let arr = [6, 10, 15, -5];

// let res = arr.map((item, index, array) => item  * 10);
// console.log(res)

// let res = arr.map((item, index, array) => {
//     if(item > 7) {
//         return item * 10
//     }
//     return item
// });
// console.log(res)

// ------ SORT ------
// let arr = [5, 7, 0, -8];
// let returnedValue = arr.sort((a, b) => a - b);
// console.log(arr);
// console.log(returnedValue); // CHANGES ARRAY AND RETURNS CHANGED ARRAY