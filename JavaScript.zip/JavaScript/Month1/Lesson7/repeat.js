// 1) greq function vor@ stanum e tveri array ev mek number argument ev veradarcnum nor array vori mej klinen miayn number argumentov stacvac tvic mec tver@

// Anna
// let arr = [1, 50, 14];
// let num= 10;
// function f(arr,num) {
//     let newArr = arr.filter(number => number > num);
//     return newArr;
// }

// console.log(f(arr, num))

// David Sveta
// function x(a,b){
//     let result = [];
//     a.forEach(item => {
//         if(item > b){
//             result.push(item)
//         }    
//     })
//     return result
// }
// console.log(x([5,9,448,545],6))

// Alex
// function foo(x, args){
//     return args.filter(args => args > x)
// }
// console.log(foo(6, [20, 10, 5]))

// 2) greq function vor@ kstana 3 argument, arajin erkusy number, errordy string ('sum' || 'divide' || 'minus' || 'multiply')
//    ev kaxvac errod argumentic kkatari ayd tveri het hamapatasxan gorcixutyun ev kveradarcni arjeq@;

// Anna
// let x = 5;
// let y = 10;
// let z = 'multiply';
// function f(x, y, z){
//         let result = 0;
//         z === 'sum' && (result = x+y);
//         z === 'devide'&& (result =x/y);
//         z === 'minus'&& (result = x-y);
//         z === 'multiply' && (result = x*y);
//         return result;
//     }

//     console.log(f(x,y,z));

// Hrach
// function arr(num1, num2, action){
//     switch(action){
//         case 'sum':
//             return num1 + num2;
//         case 'divide':
//             return num1 / num2;
//         case 'minus':
//             return num1 - num2;
//         case 'multiply':
//             return  num1 * num2    
//         }
// }
// console.log(arr(10, 5, 'multiply'))

// esel if ov)

// function arr(num1, num2, action){
//     if(action === 'sum'){
//         return num1 + num2;
//     }
//     else if(action === 'divide'){
//         return num1 / num2;
//     }
//     else if (action === 'minus'){
//         return num1 - num2;
//     }
//     else if(action === 'multiply'){
//         return num1 * num2
//     }
// }

// David Sveta
// function x( a,b,c){
//     if(c === "sum"){
//         return a+b;
//     }else if(c === "minus"){
//         return a-b;

//     }else if(c === "divide"){
//         return a / b;
//     }else {
//         return a * b;
//     }
    
 
// }
// console.log(x(5,10,"sum"))

// //----OR--------------

// function mySwitch(x,y,z){
//     switch (z){
//     case 'sum':
//         return x + y;
//     case 'minus':
//         return x - y;
//     case 'multi':
//         return x * y;
//     case 'divide':
//         return x / y;
//     default:
//        return 'Sorry!'
// }
// }
// console.log(mySwitch(10,5,"multi"));

// Alex
// function foo(a, b, c) {
//     if (c === 'sum') {
//       return  a + b;
//     }
//     else if (c === 'divide'){
//       return  a / b;
//     }
//     else if (c === 'minus'){
//        return a - b;
//     }
//     else {
//        return a * b;
//     }
    
// }
// console.log(foo(10, 20, 'minus'));

// 3) greq function vor@ stanum e array argument numbernerov ev stugum ete ayd arrayi arajin u verjin tveri gumar@ mec e amboxj arrayi elementeri gumaric
//    apa kveradarcni true hakarak depqum false

// Anna
// let arr = [20, -5, 10]
// function f(arr) {   
//     let x = arr[0] + arr[arr.length-1];
//     let sum;
//     for(let i = 0; i < arr.length; i++){
//         sum += arr[i]; 
//     }
//     return x > sum ? true : false;
// }

// console.log(f(arr))

// Hrach
// function arr(array){
//     let sum = 0;
//     for(let i = 0; i < array.length; i++){
//         sum += array[i];
//     }
//     if(sum > array[0] + array[array.length -1]){
//         return true
//     }
//     else{
//         return false
//     }
// }
// console.log(arr([10, 5, 4, 1, 10]));

// David Sveta

// function x(a){
//         let res = 0;
      
//         for(let i = 0; i < a.length; i++){
//             res += a[i]
//         }
//         if(a[0] + a[a.length - 1] > res ){
//             return true
//         }else{
//             return false
//         }


// }
// console.log(x([2,-3,3]))

// Alex
// function foo(arr){
//     let res = 0;
//     for (let i = 0; i < arr.length; i++){
//         res += arr[i]
//     }
//     if(arr[arr.length - 1] + arr[0] > res){
//         return true;
//     }
//     else {
//         return false;
//     }
// }
// console.log(foo([10, 20, 30]));

// 4) CLOSURI MIJOCOV STACEQ GUMARMAN FUNCTION;
// aysinqin f(1)(2) ---> ksatananq 3

// Anna
// function getSum(num1){
//     return function (num2){
//         return num1 + num2
//     }
// }

// console.log(getSum(1)(2));

// Hrach    
// function foo(x){
//     return function (y) {
//         return  x + y;
//     }
// }
// console.log(foo(1)(2));

// David SVeta
// function f(x) {
//     return function (y) {
//         return x + y
//     }
// }
// console.log(f(1)(2));

// Alex
// function f(x){
//     return function (y) {
//         return x + y;
//     }
// }
// let res = f(1)(2);
// console.log(res);

// 5) CLOSURI MIJOCOV STEXCEQ FUNCTION VOR@  ERKROD KANCHI ZHAMANAK STACVAC TIV@ KLCNI ARRAY MEJ,
// ARAJIN KANCHI ZHAMANAK STACVAC TVI CHAPOV;

// Anna
// let arr = []
// function f(num1) {
//     return function (num2) {
//         for (let i = 0; i < num1; i++){
//             arr.push(num2)
//         }
//         return arr
//     }
// }

// console.log(f(5)(2));

// Hrach
// function foo(count){
//     let arr = [];
//     return function(number){
//         for(let i = 0; i < count; i++){
//                 arr.push(number)
//         }
//         return arr
//     }
// }
// console.log(foo(5)(3));

// David Sveta
// function f(x) {
//     return function () {
//         return [...x];
//     }
// }
// console.log(f([1515,84848,554])());

// Alex
// function foo(...args) {
//     return args;
// }
// console.log(foo());
// console.log(foo(20, 10, 30, 50, 2));

