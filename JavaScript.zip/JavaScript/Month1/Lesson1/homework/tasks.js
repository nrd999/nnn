// 1) Haytarareq bolor primitive typerov popoxakanner ev tpeq dranq

// Hrach
// let name = "Hrach";
// let surName = "Sughyan";
// let age = 20;
// const country = "Armenia"
// console.log(name,surName,(typeof age),country);

// let phonenumber = +37496202521;

// let addres = davitashen ${addNum}
// console.log(addres)

// Sveta
// boolean
    // let a = 5;
    // let b = 8;
    // let c = 4;
    // console.log(a > b < c);

// David
/*Boolean Type*/
//  let x = 10;
//  let y = 20;
//  console.log(x >=! y );

// 2) Haytarareq number type popoxakan heto poxeq arjeq@ string type-i(tarber exanaknerov)

// Anna
// let x=5
// console.log ("x")

// Alex, Sveta, David
// var age = 15;
// age = String(age);
// console.log(typeof age);
// let myAge = 35;
// myAge = myAge + '';
// console.log(typeof myAge); 

// 3) Haytarareq boolean popoxakan vor hnaravor chlini poxel

// Anna
// const x=5
// x=6

// console.log(x)

// 4) WHAT WILL BE THE OUTPUT AND WHY
//     let a = 5;
//     let b = 4;
//     let c;
//     let d = a;
//     c = b;
//     console.log(a, b, c, d);

// 5) WHAT WILL BE THE OUTPUT AND WHY
//     let a;
//     console.log(a);
//     a = 5;
//     console.log(typeof a)
//     console.log(a);

// 6) WHAT WILL BE THE OUTPUT AND WHY
//     let str = 'some string';
//     let age = 21;
//     age  = str;
//     str = null;
//     console.log(age, str);

// Alex
// let str = 'some string';
// let age = 21;
// age  = str;                                    // age-ը դառնում է str(some string)
// str = null;                                    // str-ն դառնում է null
// console.log(age, str); 

// 7) WHAT WILL BE THE OUTPUT AND WHY
//     let name = `John`;
//     let message = `my name is ${name}`;
//     console.log(typeof message);
//     console.log(message);

// Sveta
// 2-rd console-um ayn uni shex chakertner vori shnorhiv karox enq
// exac arjequm avelacnel nor arjeq

// 8) WHAT WILL BE THE OUTPUT AND WHY
//     let isChecked = null;
//     isChecked = true;
//     let isChecked = false;
//     console.log(isChecked);

// Alex
// let isChecked = null;         
// isChecked = true;                              // Ցույց է տալիս false որովհետև վերջին արժեքը false է
// let isChecked = false;
// console.log(isChecked); 


// 9) WHAT WILL BE THE OUTPUT AND WHY
    // const name = 'John';
    // let otherName = "Tom";
    // otherName = name;
    // console.log(otherName);
    // name = 'Jonathan';
    // console.log(name);

// Suren
// araji depqum vochmiban chi artatpvi uxxaki datark vandak vorovhetev othername=name nshanakuma vor otherNamei arjeq@ poxvela anhayt anunov isk yerkrorduk name-in arden trvela jonathan dra hamar kartatpvi henc jonathan

// Sveta, David
// const-y misht anpopox e isk consolum kunenanq error

// 10) WHAT WILL BE THE OUTPUT AND WHY
    // let age = 44;
    // const newAge = 27;
    // let newAge = 30;
    // console.log(age, newAge);

// Anna
//     44 27

// Suren
// kta error vorovhetev yete haytararaca const u heto arjeq@ poxvaca inq@ chi ashxati. Consti reference@ chi lini poxel



