
// what is javascript
// https://learn.javascript.ru/intro

// variables
// https://learn.javascript.ru/variables#tasks

