// ! , !==, !=
// !!true --> !false --> true
// console.log(!true);
// console.log(1 + NaN);
// console.log("5" + 5)
// console.log("2" + "3" + 4 + 5);
// console.log(4 + 2 + "2" + "3");
// console.log(+"2" + +"3");
// console.log("2" - 6);
// console.log("6" / "2");

// ----- Type converting -----
// string to number
// let num = "2a";
// console.log(+num);
// console.log(Number(num));
// console.log(Number(5));

// number to string
// let num = 5;
// console.log(String(num))
// console.log(num + "");

// Boolean to number
// console.log(Number(true));
// console.log(Number(false));
// console.log(+true);
// console.log(+false);

// String to boolean
// console.log(Boolean(""));
// console.log(Boolean(" "));
// console.log(Boolean(0));
// console.log(Boolean("0"));
// console.log(Boolean(1));
// console.log(Boolean(null));
// console.log(Boolean(undefined));
// console.log(Boolean(NaN));
// console.log(Boolean(-0));


// >, <, <=, >=, !==, +=
// console.log(4 < 6);
// console.log(8 <= 6);
// console.log(4 >= 3);
// console.log("4" !== 4);

// let a = 5;
// a = a + 5;
// a += 5; 
// console.log(a);

// Math
// let a = 4.5;
// let random = Math.random();
// console.log(random);
// console.log(Math.floor(a));
// console.log(Math.ceil(a));
// console.log(Math.round(a));
// console.log(Math.max(10, 5, 16));
// console.log(Math.min(10, 5, a));
// console.log(Math.round(random * 10));

// toFixed()
// let a = Math.random();
// console.log(a);
// console.log(a.toFixed(6));

// parseInt, parseFloat
// let width = "15.5px5";
// console.log(parseInt(width));
// console.log(parseFloat(width))

// toString
// let a = 11;
// console.log(a.toString());

// String lenght
// let a = "some string";
        // 0 1 2 3
// console.log(a.length);
// console.log(a[6]);
// console.log(a[a.length - 1]);
// console.log(a.indexOf('i'));

// toLowercase, toUppercase
// let a = "soMe string";
// console.log(a.toUpperCase());