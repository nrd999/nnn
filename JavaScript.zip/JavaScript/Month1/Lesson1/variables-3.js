// ================VARIABLES================

// 3 WAYS TO DECLARE

// var, let, const

// SET DECLARATION METHOD--let, SET NAME--country, = , AND VALUE

// let name;
// let age;
// ----------------------------------------------------------------
// ----CAMEL CASE NAME----

// let name = 'John';
// let age = 18;
// let country = 'Armenia';

// -----------------------------------------------------------
//-----in one line----
// let name = 'John', age = 25, country = 'Armenia';
// let name = 'JOhn';
// let age = 25;
// ------------------------------------------------------------

// --------show with console.log------
// let x = 7;
// x = 'some string';
// console.log(x);

// ---change value of variable---

// let name = 'John';
// console.log(name)
// name = 'Armen';
// console.log(name);
// ------------------------------------------------------------
// ---we cant declare twice---

// let name = 'John';
// let name = 'Armen';
// -----------------------------------------------------------
// --- copy variable-----

// let age = 15;
// let otherAge;
// //
// otherAge = age;
// //
// console.log(age, otherAge)

// -----------------------------------------------------------
//copy to defined value

// let age = 15;

// let otherAge = 27;

// console.log(age, otherAge);

// otherAge = age;

// console.log(age, otherAge);
//------------------------------------------------
//other example
// let message = 5;
// message = 'Tom';
// let name;
// name = message;
// console.log(name, message)


//-----------------------------------------------------------
// ========DIFFERENCE WITH CONST==============

// const name = 'John';
// name = 'Armen';

// ========VAR==============
// old version

//========WHY WE NEED IT============
// hardcode

// explain with prompt
// prompt('Say Your Name!');
// let name = prompt('Say Your Name!');
// console.log(name);
// let a = 5;
// confirm(a)



