// ---------------- Object.assign() ----------------
// clone object with loop
// let obj = {
//     name: 'John',
//     surname: 'Wick',
//     age: 30,
// }

// console.log(obj);

// let a = 'str';
// let x = new String(5)
// console.log(a);
// console.log(x.toLowerCase());
// let arr = [];
// console.log(arr);
// arr.
//
// let obj2 = {};
// //
// for(let key in obj) {
//     obj2[key] = obj[key]
// }

// clone object with assign
// let obj = {
//     id: 5,
//     name: 'John'
// }

// let clonedObject = Object.assign({}, obj);
// console.log(clonedObject);
// console.log(clonedObject === obj);

// --------------------------------------------
// let obj1 = {
//     id: 5,
//     isTest: true,
//     name: 'John',
// }
// let obj2 = {
//     id: 7,
//     surname: 'Wick'
// }
// console.log(obj1, obj2);
// Object.assign(obj1, obj2);
// obj2 = obj1
// console.log(obj1);
// console.log(obj2);
// console.log(obj1 === obj2);

// ---------------- Object.values() ----------------
// let obj1 = {
//     id: 5,
//     isTest: true,
//     name: 'John'
// }

// let values = Object.values(obj1)
// console.log(values)

// ---------------- Object.keys() ----------------
// let obj1 = {
//     id: 5,
//     isTest: true,
//     name: 'John'
// }

// let keys = Object.keys(obj1);
// for(let i = 0; i < keys.length; i++) {}

// ---------------- Object.entries() ----------------
// let obj1 = {
//     id: 5,
//     isTest: true,
//     name: 'John'
// }

// let keys = Object.entries(obj1);
// console.log(keys)

// ---------------- Object.hasOwnProperty() ----------------
// let hasProperty = obj1.hasOwnProperty('age');
// console.log(hasProperty)

