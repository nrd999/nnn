// let user = {
//     id: 1,
// }

// let admin = user;

// user.name = 'John';

// console.log(user);
// console.log(admin);


// ------- comparing objects ==, === -------
// let obj1 = {};
// let obj2 = {};

// console.log(obj1 == obj2);
// console.log(obj1 === obj2);

// ----------------------------------------
//  let obj1 = {};
//  let obj2 = obj1;

//  console.log(obj1 == obj2);
//  console.log(obj1 === obj2);

// ------- objects with const -------
// const obj = {
//     id: 5
// }
// obj = {};

// const obj = {
//     id: 5
// }
// obj.skill = [];
// //
// console.log(obj);


// var x = 5;

// typeof x
// console.log(5/"i");

// for(let i = 0; i < 5; i++) {
//   console.log(i);   
// }

// console.log(++i);
// console.log(x());
// var x = function foo () {
//     return 5
// };

// console.log("55" / 55);

// console.log("10" / "5");

// let i = 0;
// ++i;
// console.log(i);
// i + 1;
// console.log(i);

// console.log(...[1,2]);
// (function (){
//     let x = 5;
//     return x
// })()
