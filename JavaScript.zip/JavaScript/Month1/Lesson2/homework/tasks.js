// 1) Haytarareq 2 eranish tvov popoxakan;
//    Veraceq string type-i ev gumareq irar;
//    Vercreq stacvac arjeqi naxaverjin element@;
//    Bazmapatkeq js-i koxmic generacvox tvov(random);
//    Tpeq stacvac arjeq@ kotorakayin tesqov aynpes, vor ketic heto lini 2 tiv orinak 2.22;

// David Sveta
// let x = 123;
// let y = 251;
// z = x + "" + y + "" ;
// // Can I write like this: z = x + "" + y
// z = (z[z.length - 2]); // no need of ()
// let g = Math.random();
// z = g * z;
// z = z.toFixed(2);
// console.log(z);

// Hrach
// let x = 525; 
// let y = 128; 
// x = x.toString(); 
// y = y.toString(); 
// console.log(x + y) 
// let number =  x + y; 
// console.log(Math.random() * Number(number[number.length - 2])); 
// console.log(number[number.length- 2]); 
// let result = Math.random(); 
// console.log(result.toFixed(2)) 

// Suren
// let number = 123;
// let anotherNumber = 456;
// console.log(String(number + anotherNumber));

// ---------- ANSWER ----------
// let num = 132;
// let num2 = 456;
// let sum = num.toString() + num2.toString();
// let preLastElem = sum[sum.length - 2];
// let result = preLastElem * Math.random();
// console.log(result.toFixed(2));

// 2) Haytarareq popoxakan ev veragreq 0: 6 angam tpeq popoxakan@ aynpes vor tpi 0, 1 ev 2 tvery hetevyal hertakanutyamb
// 0
// 2
// 1
// 1
// 2
// 0
// Ogtagorceq increment ev decrement;

// David Sveta
// let x = 0;
// console.log(x++);
// console.log(++x);
// console.log(--x);
// console.log(x++);
// console.log(x++);
// console.log(--x - --x - x--);

// Suren
// let postFixValue = 0;
// let newValue = ++postFixValue;
// console.log(--newValue);
// console.log(++postFixValue);
// console.log(--postFixValue);
// console.log(postFixValue++);
// console.log(postFixValue++);
// console.log(newValue--);

// ---------- ANSWER ----------
// let x = 0;
// console.log(x++);
// console.log(++x);
// console.log(--x);
// console.log(x++);
// console.log(x--);
// console.log(--x);

// 3) Haytarareq popoxakan ev veragreq '123javascript';
//    Tvyal popoxakanic staceq meji tiv@;
//    Aynuhetev tpeq tvyal tvi tvanshanneri gumary;
//    Gumarman gorxocutyuny piti chisht ashxati cankacac eranish tvi hamar;
//    Aysinqn 123i poxaren inch eranish tiv grem piti chisht ashxati;

// David Sveta
// let x = "123javascript";
// let y = +x[0];
// let z = +x[1];
// let t = +x[2];
// console.log(y + z + t);

// Hrach
// let name = '123javascript'; 
// let newName = parseInt(name); 
// console.log(newName); 
// let num = newName.toString(); 
// console.log(+num[0] + +num[1] + +num[2]); 

// Suren
// let scr = '123javascript';
// console.log(scr);

// ---------- ANSWER ----------
// let x = '123javascript';
// let num = parseInt(x);
// let stringNum = num.toString();
// let result = +stringNum[0] + +stringNum[1] + +stringNum[2];
// console.log(result);

// 4) Greq nuyn code@ switch case-i mijocov
// let x = 5;
// if (x > 7) {
//     console.log('Bigger than 7.')
// } else if (x >= 5) {
//     console.log('Equal or bigger than 5.')
// } else {
//     console.log("Smaller than 5");
// }

// Alex: No answer

// Hrach, Suren
// let x = 5; 
// switch (x) { 
//     case x > 7: 
//         console.log('Bigger than 7.'); 
//         break;    

//     case x >= 5: 
//         console.log('Equal or bigger than 5.'); 
//         break; 
    
//     default: 
//         console.log("Smaller than 5")     
// } 

// ---------- ANSWER ----------
// let x = 5;
// switch (true) {
//     case x > 7: {
//         console.log('big');
//         break;
//     }
//     case x >= 5: {
//         console.log('equal');
//         break;
//     }
//     default:
//         console.log('i dont know')
// }

// 5) Greq nuyn code@ if else-i mijocov
// let y = 'some';
// switch (y) {
//     case 'some text':
//         console.log('some text');
//         break;
//     case 'some':
//         console.log('some');
//         break;
//     default:
//         console.log('no text')
// }

// ---------- ANSWER ----------
// let y = 'some';
// if (y === 'some text') {
//     console.log('some text')
// } else if (y === 'some') {
//     console.log('some');
// } else {
//     console.log('no text')
// }

// 6) result popoxakanin veragreq anun@ ete ayn erkar e 4ic, hakarak depqum veragreq 'name is long' ev tpeq result@
// let name = 'John';
// let result = null;

// Alex
// let name = 'John';
// let result = name.lenght > 4 ? name : 'name is long'
// console.log(result);

// David Sveta
// let name = 'John';
// name = name.length;
// let result = null;
// if (name <= 4) {
//      console.log("John");
  
// }else if(name >= 5){
//     console.log(" name is long");
 
// }

// Hrach
// let name = 'Joha'; 
// let result = null; 
 
// if (name.length > 4 )  { 
//    console.log('name is long'); 
// } else { 
//     result = name;  
//    console.log(result); 
// } 

// Suren
// let name = 'John'
// let result = null;
// if (result > 4) {
//     console.log(name)
// } 
// else {
//     console.log(result)
// }

// ---------- ANSWER ----------
// if (name.length > 4) {
//     result = name;
// } else {
//     result = 'name is long'
// }
// console.log(result);
// OR
// result = name.length > 4 ? name : 'name is long';
// console.log(result)

// 7) Haytarareq 3 popoxakan anun azganun tariq; ev greq script vory tpum e 'done' ete bolor popoxakannern unen arjeq;

// Alex
// let name = 'Alex';
// let surName = 'Hovsepyan';
// let age = 15;

// if (name, surName, age !== undefined){
//     console.log('done');
// }
// else {
//     console.log(undifined);
// }

// David Sveta
// let name;
// name = "Davo";
// let surname;
// surname = "Simonyan";
// let age;
// age = 26;
// if(name && surname && age) {
//     console.log("done")
// }

// Anna
// if (name.length > 0 && surname.length > 0 && age > 0){
//     console.log('done');
// }

// Hrach
// if (surName && name  && age) { 
//    console.log('done') 
// } 

// Suren
// let name = "Suren";
// let surname = "Mheryan";
// let age = "28";
// if (name === "Suren") {
//     console.log("done")
// }
// if (surname === "Mheryan") {
//     console.log("done")
// }
// if (age === "28") {
//     console.log("done")
// }

// ---------- ANSWER ----------
// let name = 'John';
// let surname = 'Doe';
// let age = 30;
// if(name && surname && age) {
//     console.log('done')
// }
// or
// if (name && surname && age) console.log('done')
// or
// name && surname && age && console.log('done');

// 8) result popoxakanin veragreq anun@ ete ayn ka hakarak depqum azganun@;
    // let username = 'John';
    // let surname = 'Smith';
    // let result;

// Alex
// if(username !== undefined){
//     result = username
// }
// else{
//     result = surname
// }

// console.log(result);

// David Sveta
// if(result === username){
// console.log(surname);
// }else if(result === surname){
// console.log(username);
// }

// Anna
//   if (username.length > 0) {
//       result = username;
//   }
//   else {
//       result = surname;
//   }

// Suren
// let name = "John";
// let surname = "Smith";
// let result;
// if (name === true) {
//     result = name;
// }
// else {
//     console.log(surname);
// }

// ---------- ANSWER ----------
// result = username ? username : surname;
// result = username || surname;

// 9) Greq script vor kstugi ete user@ uni anun apa ayd anvany kavelacni 777 ev ktpi ayn;
//     ete anun chuni ev tariq@ poqr e 18-ic, stugi ete 16 kam 17 tarekan e apa  tpi 'soon';
//     mnacac bolor depqerum tpi useri tariq@ bayc string typov;
    // let userName;
    // let userAge = 14;

// Alex: no answer

// David Sveta
// let userName ;
// let userAge ;
// if(userName){
//     console.log(userName + 777);
// }else if(userAge < 18){
//     if(userAge === 16 || userAge === 17) {
//          console.log("soon");      
//     } else{
//         console.log(userAge.toString());
//     }
// }else{
//     console.log(userAge.toString());
// }

// Anna
// if (userName){
//     console.log(userName + 777);
// }
// else if (userAge < 18 && (userAge === 16 || userAge === 17))  {
//     console.log('soon');
// } else {
//     console.log(userAge.toString());
// }

// Hrach
// if (userName){ 
//    console.log(userName + '777') 
//  }  
// else if (userAge < 18) { 
//     console.log('soon'); 
//  } 
//  else {  
//     console.log(userAge.toString()); 
//   } 

// Suren
// let username = "John";
// let age = 17;
// if (username = "John") {
//     console.log(username + 777);
// }

// ---------- ANSWER ----------
// if (userName) {
//     console.log(userName + 777);
// } else if(userAge < 18) {
//     (userAge === 16 || userAge === 17) && console.log('soon');
// } else {
//     console.log(userAge.toString());
// }

// 10) WHAT WILL BE THE OUTPUT AND WHY
    // let a = 5;
    // let b = String(a);
    // let c = Boolean(b);
    // let d = c.toString();
    // d += d;
    // console.log(d);

// Hrach
// let a = 5;  // estex a=5
// let b = String(a); /// estex b="5"
// let c = Boolean(b); // c=5 string nel true arjeq a
// let d = c.toString(); // estex d= c-i true in nran sargelov "" string;
// d += d;  /// stex el arajin d='true' +=d darcnum a stringy tvi
// console.log(b);

// 11) WHAT WILL BE THE OUTPUT AND WHY
    // let x;
    // let y = Boolean(x);
    // let z = Number(y);
    // let q = z++;
    // console.log(q);

// Alex
// let x;              undefined
// let y = Boolean(x); false
// let z = Number(y);  0
// let q = z++;        0
// console.log(q);     0

// Hrach
// let x; // x = undefined
// let y = Boolean(x); /// y = x-i arjeqin vory false a
// let z = Number(y); /// sarguma tiv z = y i false arjeqin vory false = 0
// let q = z++; /// q = 0 ++ aysinqn ete mi angam el tpenq q ktpi 1
// console.log(q);

// 12) WHAT WILL BE THE OUTPUT AND WHY
    // let str = 'some string';
    // let str4 = str[4];
    // str4 += '';
    // let sum = 10 + str4;
    // console.log(sum);

// Alex
// let str = 'some string';  'some string'
// let str4 = str[4];        ''
// str4 += '';               ' '
// let sum = 10 + str4;      '10 '
// console.log(sum);  

// David Sveta
/* str4 false e aysinqn 0 ,isk sum-um 10+0 = 0*/

// Suren: No answer

// 13) WHAT WILL BE THE OUTPUT AND WHY
//     let num = 124.5;
//     let someStr = 'some';
//     let line = num + someStr;
//     let parsedLine = parseInt(line);
//     let something = ++parsedLine;
//     const result = something >= '';
//     console.log(result);

// Alex
// let num = 124.5;
// let someStr = 'some';
// let line = num + someStr;             '124.5some'
// let parsedLine = parseInt(line);      124
// let something = ++parsedLine;         125
// const result = something >= '';        true 
// console.log(result);

// David Sveta
// line@ kta 124.5some  isk parsedLine i jamanak kmna 124 ,
// ++i shnorhiv mek nishov kavela kdarna 125  .  const resultum stanum enq true ev false 
// aysinqn da knshanaki vor ayn true e patasxan@` true

// Hrach
// let num = 124.5;
// let someStr = 'some';
// let line = num + someStr; /// darnuma "124.5some"
// let parsedLine = parseInt(line); /// vercnuma dimaci tivy minchev kety
// let something = ++parsedLine; /// darcnuma 125 ++ ov
// const result = something >= '';
// console.log(result);

// Suren: No answer

// 14) WHAT WILL BE THE OUTPUT AND WHY
//     let bool = true;
//     let notBool = 'string';
//     let val = +bool + 1;
//     let newVal = val + 'notBool';
//     let len = newVal.length;
//     let newLen = len + +'5.12345';
//     const res = newLen.toFixed(1);
//     console.log(res);

// Alex
/** val veragrvuma 2 vorovhetev true = 1 u 1 + 1 = 2 newVal veragrvuma 2notBool vorovhetev tvin stringa gumarum heto len veragrvuma 7
 *  newLen veragrvuma 12.12345 heto res veragrvuma 12.1 vorovhetev toFixed(1) . heto 1 tiva toxum */

// let bool = true;     
// let notBool = 'string';
// let val = +bool + 1;                     2
// let newVal = val + notBool;             '2notBool'
// let len = newVal.length;                 7
// let newLen = len + +'5.12345';           12.12345
// const res = newLen.toFixed(1);           12.1
// console.log(res)

// Hrach
// let bool = true; // 1
// let notBool = 'string';
// let val = +bool + 1; // 2
// let newVal = val + notBool; //"2string"
// let len = newVal.length; // talisa tveri qanaky 
// let newLen = len + +'5.12345'; /// 7 + +""=number 
// const res = newLen.toFixed(1); /// ketic heto vernuma arajin tivy 
// console.log(res);

// 15) WHAT WILL BE THE OUTPUT AND WHY
    // let lastString = 'string';
    // let whatOutput = lastString.indexOf('t');
    // let getSymbol = lastString[lastString.length - whatOutput];
    // let isEqual = getSymbol === 'g';
    // console.log(isEqual);

// Suren: No answer

// 16) WHAT WILL BE THE OUTPUT AND WHY
//     let age = 44;
//     let newAge = age++;
//     let stringAge = age.toString();
//     let newStringAge = +stringAge;
//     let isEqual2 = newAge === newStringAge;
//     console.log(isEqual2);

// David Sveta
//newAge 44 e . stringAge-i jamanak "45"
//newStringAge-darnum e 45 i shorhiv ++ eri
//@st aydm 44 havasar che 45 patasxany klini false

// Hrach
// let age = 44;
// let newAge = age++; /// 44
// let stringAge = age.toString(); //"45"
// let newStringAge = +stringAge; // 44
// let isEqual2 = newAge === newStringAge; /// newAge =45 vorovhetev verevum newage = age++ aysinqn urish tex age haytararelu depqum inqe arden 44 i poxaren 45 e
// console.log(isEqual2);

// Suren
// let age = 44;
// let newAge = age++;
// es toxum newAge klini 44 isk age arden 45
// let stringAge = age.toString();
// es toxum age-@ dardzela string
// let newStringAge = +stringAge;
// let isEqual2 = newAge === newStringAge;
// console.log(isEqual2);
// kta false vorovhetev tiv@ stringin havasr chi

// 17) WHAT WILL BE THE OUTPUT AND WHY
    // let randomNumber = Math.random();
    // let resultNum = Math.round(randomNumber);
    // console.log(resultNum);

// Anna
// answer random tver bayc amboxj

// 18) WHAT WILL BE THE OUTPUT AND WHY
// let x = '';
// if(x) {
//     x = 6;
//     console.log(x)
// } else {
//     x += true;
//     console.log(x)
// }

// Alex
/** x veragrvuma '' heto darnuma 'true' vorovhetev x != 0 */

// David Sveta
// let x false e dra hamar mtnum e else bloki mej ev
// false u truen talis en true

// Suren
// let x = '';
// if(x) {
// x = 6;
// console.log(x)
// } else {
// x += true;
// console.log(x)
// }
// kveradaracni true vorovhetev datark content@ true arjeqa isk
// isk mer datark contentin vergrvac tiv chka aysinqn inq@ kara havasar lini 1-i

// 19) WHAT WILL BE THE OUTPUT AND WHY
// let y = 10 <= '11' || null && 'string' > 5
// if (!y) {
//     console.log(true || false)
// } else {
//     console.log(!y)
// }

// Alex
/** y veragrvuma true vorovhetev 10 <= '11' heto y poxvuma false vorovhetev if chi ashxatum */

// Hrach
// let y = 10 <= '11' || null && 'string' > 5 /// (10 poqra '11'=Number 11) (true || null misht yntruma dzax koxmi chishty) (11 && "string" yntruma ach koxmi false) ("string" > 5 =  false)

// if (!y) /// y = ture !y= false  
// {
//     console.log(true || false) // yntruma true vory paymanin chi hamapatasxanum
// } else {
//     console.log(!y)
// }

// Suren: No answer

// 20) WHAT WILL BE THE OUTPUT AND WHY
// const x = (null || 'some text') && ('boolean' && 'null');
// x === 'null' ? console.log('result 1') : console.log('result 2');
// let y = ('boolean' || undefined) || ('' && x);
// console.log(y);

// Alex
/** x veragrvuma  null vorovhetev nully false a heto tpuma result 1 vorovhetev x === 'null' heto y veragrvuma 'boolean' vorovhetev 'boolean' true a*/

// Hrach, Suren: No answer


// 21) WHAT WILL BE THE OUTPUT AND WHY
// let num = 0;
// num++ ? console.log(num) : console.log('no-num');
// if (num) {
//     console.log(num && 5)
// }

// Hrach, Suren: No answer

// 22) WHAT WILL BE THE OUTPUT AND WHY
// let count = 0;
// if(count.toString()) {
//     count++;
//     if(count > 0) {
//         count++;
//         if(!count) {
//             console.log('no-count')
//         }else {
//             console.log(--count)
//         }
//     }
// }

// Hrach, Suren: No answer

// 23)* Aranc 3rd popoxakan haytararelu poxeq arjeqneri texer@ aynpes vor num1@ darna 67890, num2@ darna 12345;
//     Chi kareli ogtagorcel vochmi ayl tiv ev ayl popoxakan;
//     Script@ petq e chisht ashxati cankacac tveri depqum;
// let num1 = 12345;
// let num2 = 67890;

// Alex
// let num1 = 12345;
// let num2 = 67890;

// if(true){
//     num1 = num2 + num1;
//     num2 = num1 - num2
//     num1 = num1 - num2
// }
// console.log(num1, num2);

// David Sveta
// let num1 = 12345;
// let num2 = 652151;
// if(num1,num2 !== undefined){
//    num1 = num2;
//    console.log(num1);   
// }

// Suren
// let num1 = 12345;
// let num2 = 67890;
// if (num1 === 12345) {
//     console.log(num2);
// }
// if (num2 === 67890) {
//     console.log (num1)
// }


// ---------- ANSWER ----------
// let num1 = 12345;
// let num2 = 67890;
// num1 = num1 + num2;
// num2 = num1 - num2; // num2 = num1 + num2 - num2 => num2 = num1
// num1 = num1  - num2; // num1 = num1 - num2 = num1 + num2 - num1 = num2
// console.log(num1, num2)