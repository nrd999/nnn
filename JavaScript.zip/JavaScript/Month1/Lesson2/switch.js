// -------------------- switch case -------------------
// let lang = 'en';
// switch (lang) {
//     case 'en' :
//         console.log('en');
//         break;
//     case 'ru' :
//         console.log('ru');
//         break;
//     default :
//         console.log('No language')
// }

// // --------break is neccesary----------
// let lang = 'ru';
// if (lang === 'en') {
//     console.log('english')
// } else if (lang === 'am') {
//     console.log('armenian')
// } else if (lang === 'ru') {
//     console.log('russian')
// } else if (lang === 'fr') {
//     console.log('french')
// } else {
//     console.log('no equality')
// }

// ------- OR ------
// switch (lang) {
//     case 'en' :
//         console.log('english');
//         break;
//     case 'am' :
//         console.log('armenian');
//         break;
//     case 'ru' :
//         console.log('russian');
//         break;
//     case 'fr' :
//         console.log('french');
//         break;
//     default:
//         console.log('no equality')
// }


// Do same action in different cases.
// let age = 7;
// switch (age) {
//     case 1:
//     case 10:
//     case 17:
//         console.log('User isn't adult.');
//         break;
//     case 18:
//     case 19:
//     case 25:
//         console.log('User is adult.');
//         break;
//     default:
//         console.log('Something');
// }

// ---with blocks---
// switch ('en') {
//     case 'en' : {
//         console.log('english');
//         break;
//     }
//     case 'hy' : {
//         console.log('armenian');
//         break;
//     }
//     case 'ru' : {
//         console.log('russian');
//         break;
//     }
//     default:
//         console.log('no equality')
// }

// let x = 7;

// switch(x) {
//     case x > 7: {
//         console.log("Bigger");
//         break;
//     }
//     case x === 7 : {
//         console.log("equal");
//         break;
//     }
//     default: console.log("sth");
// }
