// ----------------------FUNCTION EXPRESSIONS-------------------
// makeSomething();

// function makeSomething() {
//     console.log('Log the text inside me')
// }
// makeSomething();
// var makeSomething = function () {
//     console.log('Log the text inside me') /*no need for name*/
// };
// //

// console.log(x);
// const x = 5;

// --------functions can be given to another variable;------

// let num = 5;
// let otherNum = num;

// let f = function () {
//     console.log('something')
// };
// //
// let otherF = f;
// f()
// otherF();

// function doSomething() {
//     console.log('something')
// }
// //
// let x = doSomething;
// x();

// ------typeof--------

// function sum(a, b) {
//     return a + b
// }

// console.log();
//
// let x = sum();
// console.log(x);
// let y = sum;
// console.log(y);
// console.log(typeof y);


// ----------FUNCTION CALLBACKS----------

// function successCb(num) {
//     console.log(num)
// }
// //
// function errorCb() {
//     console.log('Error')
// }
// //
// function getRandomNum() {
//     return Math.ceil(Math.random() * 10)
// }
// //
// function saySomething(getRandomNum, successCb, errorCb) {
//     const num = getRandomNum();
//     // if(num > 5) {
//     //     successCb(num);
//     // } else {
//     //     errorCb()
//     // }
//     num > 5 ? successCb(num) : errorCb();
// }
// //
// saySomething(getRandomNum, successCb, errorCb);


