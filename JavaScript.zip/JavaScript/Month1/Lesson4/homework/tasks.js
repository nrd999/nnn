// 1) WHAT WILL BE THE OUTPUT AND WHY
// let num = 5;
// function showNum() {
//     console.log(num)
// }

// showNum();
// num = 7;
// showNum();

// Alex
// Vochinch el chi katarvi

// 2) WHAT WILL BE THE OUTPUT AND WHY
// let a = 10;
// let b = 10;
// let showSum = (a, b) => {
//     return a + b
// };

// console.log(showSum(5, 7));

// Anna: no answer

// Alex
// console-y ignore kani skzbi a ev b-i arjeqnery u uxxaki (5+7) kani ev console-um ktpi 12 tivy

// David Sveta
// showSum-um a ev b kstanan 10 ev 10.
// sakayn clg-um poxvel en nranc arjeqner@ darnalov 5 ev 7.
// gumarman ardyunqum clg-um stacel enq 12

// 3) WHAT WILL BE THE OUTPUT AND WHY
// let age = 30;
// let getInfo = function (age, name = 'John', surname) {
//     console.log(surname);
//     function getOnlyName(name) {
//         if(!surname) {
//             console.log(name);
//         } else {
//             console.log(age)
//         }
//     }
//     getOnlyName('Jonathan');
// };
// age = 20;
// getInfo(age);

// Alex
// skzbum ktpi "Jonathan" anuny aynuhetev chkaranalov chisht haskanal surname-i i age-i masy ktpi undefined

// Suren
// 1-in toxum haytararvac e age popoxakan vorin veragrvel e 30 number@
// 2-rd toxum haytararvel e functia hetyevyal arjeqnerov (30, undefined vorovhetev stex chenq kara veragrum anenq, surname)
// 3-rd toxum console.log e arvel surname qani vor surname undefined-a es toxum kta undefined
// 4-rd toxum haytararvac e nor functia getOnlyName anvamb
// 5-rd toxum ka if payman vor vor false-@ jxtvel e darel e true uremn mtnum e if-i mej
// 6-rd toxum console.log e arvel name vor@ vor noric undefined-a
// 7-rd toxum else payman@ kashxati vor@ noric undefined-a
// 8-rd toxum el kashxati getOnlyName kanchvac funkcian vorin trvela Jonathan arjeq-@ aysinqn name

// Alex
/** 3 age darnuma 30 grum enq function u mejy grum enq age name u iran talis enq 'John' u grum enq surname inqy petqa tpi surname 
 *    heto mejy grum enq urish function u talis enq name heto grum enq if talov iran !surname inqy undefined-a = false bayc darnuma true u getOnlyName-i name-in talis enq 'Jonathan' arjeqy
 *    heto age darnuma 20 u kanchum enq getInfo function u inqy tpuma surname aysinqn undefined vorovhetev arjeq chenq tvel
 *    heto kanchum enq getOnlyName-y u ira meji if-y trust-a talis u tpuma name aysinqn 'Jonathan' */

// 4) Greq function vor@ stanum e number argument ev drakan linelu depqum hashvum minchev ayd tiv@ exac tveri gumar@;
//    orinak ete functionn stana 3 apa petq e veradarcni 6 (1 + 2 + 3)

// Alex: no answer

// David Sveta
// function x(a){
//     let num = 0;
//     let result = 0;
//     while(num < a) {
//         num++;
//         result += num  
//     }
//     console.log(result);
// }
// x(3);

// Hrach
// function numberCalc(num) {
//     let sum = 0;
//     while(num >= 1) {
//         sum += num--;
//     }
//     return sum
// }

// console.log(numberCalc(4));

// Anna
// function showSum(sum) {
//     let res = 0;
//     if (sum > 0){
//         for(let i = 0; i<=sum ; i++){
//             res += i;
//         }
//         return res;
//     }
//     else{
//         return "this number is not positive"
//     }
// }
// console.log(showSum(3));

// Alex, Suren
// function foo(number){
//       let result = 0;
//       for(let i = 0; i <= number; i++){
//           result += i;
//       }
//       return result
// }
// console.log(foo(3));

// --------- ANSWER ---------
// function showSum(num) {
//     let sum = 0;
//     if(num > 0){
//         for (let i = 1; i <= num; i++) {
//             sum += i
//         }
//     }
//     return sum
// }

// console.log(showSum(5));

// 5) js@ uni function Math.max(num1, num2, num3) vor@ veradarcnum e trvac cankacac qanaki tveric amenamec@, greq ayd functionn inqnuruyn 3 tvi hamar
// (patkeracreq math.max goyutyun chuni)

// Suren, Alex: no answer

// Hrach
// function mathMax(num1, num2, num3){
//     if(num1 > num2){
    
//         return num1 
//     }
//     else if(num2 > num3){
         
//             return num2 
//     }
//     else(num3 > num2) 
       
//         return num3 
//     }
// console.log(mathMax(9,5,8));

// David Sveta
// function max(num1,num2,num3){
//     if(num1 > num2 && num1 > num3){
//         console.log(num1)
//     }else if(num2 > num1 && num2 > num3) {
//         console.log(num2)
//     }else{
//         console.log(num3)
//     }
// }
// max(25,32,5);

// Anna
// function max(num1, num2, num3) {
//     if (num1 > num2 && num1 > num3){
//         return num1;
//     }
//     else if (num2 > num1 && num2 > num3){
//         return num2;
//     }
//     else if (num3 > num1 && num3 > num2){
//         return num3;
//     }
// }

// console.log(max(20, 45, 33));

// Alex
// 5 
// let result = 0;
// function foo(num1, num2, num3){
//    if(num1 > num2 && num1 > num3){
//        result += num1;
//    }
//    else if(num2 > num1 && num2 > num3){
//        result += num2;
//    }
//    else{
//        result += num3;
//    }
//    return result;
// }
// console.log(foo(50, 80, 2));


// --------- ANSWER ---------
// function showMax(a, b, c) {
//     let bigNum = a > b ? a : b;
//     bigNum = bigNum > c ? bigNum : c;
//     return bigNum;
// }

// console.log(showMax(-1, 5, 7));

// 6) Greq function vor@ stanum e number argument ev khashvi te ayd numberi mej qani 0 ka;

// Alexner, Anna, Suren: no answer

// David Sveta
// let result = 0
// let ziro = function(a){
//      a = a.toString() 
   
//     for (let i = 0; i < a.length; i++) {       
//         if(a[i] == 0){
//             result++;
//         }
//     } 
      
//      return console.log(result)
// }
// ziro(100003030040000);

// Hrach
// function numberHashvox(number){
//     let sum = number.toString();
//     let amount = 0;
//     for(let i = 0; i < sum.length; i++){
//         if(tiv[i] === '0'){
//             amount++
//         }
//       }
//       return amount
// }
//  console.log(numberHashvox(150060));

// --------- ANSWER ---------
// function countZeros(num){
//     let str = num.toString();
//     let count = 0;
//     for(let i = 0; i < str.length; i++){
//         +str[i] === 0 && count++;
//     }
//     return count;
// }

// console.log(countZeros(12045065700));