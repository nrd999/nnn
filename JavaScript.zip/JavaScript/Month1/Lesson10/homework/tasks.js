// 1) greq function vorn stanum e 2 argument 1@ object 2rd@ inchvor string ev stugum
//    ete ayd stringov key ka objectum, veradardznum e dra valuen hakarak depqum false;
//    orinak stanum e ({id: 5}, 'name') ---> kveradardzni false

// Alex: no answer
// Suren
// 1)

// let obj = {
//     name: 'Suren',
// }
//  function f(obj, someText) {
//     for (let key in obj) {
//         if(key === someText) {
//             return obj[key]
//         }
//     }
//     return false
// }
// console.log(f(obj, 'name'))

// 2)
    // let obj = {
    //     name: "Suren",
    // }
    // for (let key in obj) {
    //     console.log(obj[key])
    // }

// Alex
// function foo(value1, value2) {
//     value1[value2] ? console.log(value1[value2]) : console.log(false);;
// }
// (foo({name : 'Alex', age : 15}, 'name'));

// function foo(value1, value2) {
//      return value1[value2] || false;
// }
// console.log((foo({name : 'Alex', age : 15}, 'name')));

// David Sveta
// function x(obj,str){
//     const keys = Object.keys(obj);
//     keys.filter(val=>(val === str) ? console.log(obj[str]) : console.log(false))
// }
// x({id : 5},'id')

// Hrach
// let obj = {
//     id:  "John"
// }
// let id = "sadasdsad"

// function getValue(obj, id){
//     if(obj[id]){
//         return obj
//     }
//     else {
//         return false
//     }
// }
// console.log(getValue(obj, id));

// Anna
// let object = {
//     id: 5,
//     name: 'Anna',
// }
// let value = 'name';
// function foo(obj, str) {
//     if (obj[str] !== undefined){
//         return obj[str]
//     }
//     else{
//         return false
//     }
// }
// console.log(foo(object, value));

// ---------- Answer ----------
// const f = (obj, str) => typeof obj[str] !== "undefined" ? obj[str] : false;
// console.log(f({id: null}, 'id'));

// 2) greq function vory karox stanal cankacac type-i argument,
//    ev stugum e ete stacvac argument@ object e ev parunakum e id keyov arjeq
//    apa kveradardzni ayd arjeq@, hakarak depqum kveradardzni "Is not an object"

// Suren, Anna: no answer

// Alex
// function foo(value) {
//     if(value.id) return value.id;
//     return "Is not an object";
// }
// console.log(foo({name : 'Alex', age : 15, id : 5}));

// function foo(value) {
//     return value.id !== undefined ? value.id : "Is not an object"
// }
// console.log(foo({name : 'Alex', age : 15, id : false}));

// David Sveta
// function x(obj){
//     const keys = Object.keys(obj);
//     console.log(keys);
//     keys.filter((val)=>(Object.is(obj,obj) && val === "id")?console.log(obj.id):console.log("Is not an object"))
// }
// x({id : 5, name: 6})

// Hrach
// let obj = {
//     id: false,
// }

// function findKey(obj){
//     if(typeof obj === "object"  && obj["id"])  {
//         return obj
//     }
//     else{
//         return "Is not an object"
//     }
// }
// console.log(findKey(obj));

// ---------- Answer ----------
// function f(arg) {
//     if(typeof arg === 'object' && arg !== null && !Array.isArray(arg)) {
//         return arg.id
//     } else return "Is not an object"
// }
// console.log(f({id: 5})); 

// 1) WHAT WILL BE THE OUTPUT AND WHY
// const obj = {
//     name: 'John',
//     surname: 'Wick',
// }

// let fullName = `${obj["name"]} ${obj[surname]}`;

// console.log(fullName);

// Hrach: no answer

// Anna
// let fullName = `${obj["name"]} ${obj["surname"]}`; /*surname-y stringi mej em grel vorpisi ashxati */

// console.log(fullName); /*ktpi John Wick */

// 2) WHAT WILL BE THE OUTPUT AND WHY
// const obj = {
//     name: 'John',
//     surname: 'Wick',
// }

// obj['age'] = 30;
// obj.age += 10;
// delete obj.surname;

// console.log(obj);

// Alex: no answer

// 3) WHAT WILL BE THE OUTPUT AND WHY
// const obj1 = {
//     id: 1,
// }

// const obj2 = obj1;

// obj2.isTest = true;

// obj1.isTest = false;

// console.log(obj1.isTest);
// console.log(obj2.isTest);

// Anna: no answer

// 4) WHAT WILL BE THE OUTPUT AND WHY
// const obj = {
//     name: '',
//     checkIsTest: (isTest) => console.log(isTest),
//     isTest: false,
// }

// console.log(typeof obj.checkIsTest);
// obj.checkIsTest(obj.isTest);

// Anna: no answer

// 5) WHAT WILL BE THE OUTPUT AND WHY
// function hasName(name) {
//    return !!name
// }

// const obj = {
//     name: 'John',
//     hasName,
// }

// console.log(obj.hasName(obj.name));

// Hrach, Anna: no answer

// Suren
/* kta true vorovhetev skzbic grvela funcia vor@ uni boolean true arjeq
heto stugvuma objecti meji yexac key-er@ voronq erkusn el unen true arjeq */ 

// Alex
// ktpi true qani vor name chka mejy

// 6) WHAT WILL BE THE OUTPUT AND WHY
// const obj1 = {
//     id: 1,
//     skills: ['js', 'css']
// }

// const obj2 = {
//     id: 2,
//     skills: ['js', 'css', 'html']
// }
// obj1.skills.push(obj2['skills'][2]);
// for (let i = 0; i < obj1.skills.length; i++) {
//     console.log(obj1.skills[i])
// }
// console.log(obj2.length);

// Suren
/* 5-rd toxum ktpi undefined vorovhetev ira vra loop fracac chi. yete loop franq naev obj2-i vra
u henc fori mej console.log anenq iran eli ktpi js, css, html u yete drsi console.log-@ chanenq mi hat
el undefined ktpi vorovhetev et toxum der ira itemner@ stugvac chen lini */

// Hrach
/// obj2.length inqy man a galis tenc key u chi gtnum

// Anna
/*js css html */
/*2 */

// 7) WHAT WILL BE THE OUTPUT AND WHY
// function f(key) {
//     const obj = {
//         name: 'John',
//         id: 5,
//     }
//     if(obj[key] && obj[key] > 1) {
//         return obj['name']
//     }else {
//         obj[key] = null
//     }

//     return obj

// }
// console.log(f('id'));
// console.log(f('surname'));

// Suren, Hrach, Anna: no answer