// ---------------- for  ------------
// LOOPS ARE A WAY TO REPEAT THE SAME CODE MULTIPLE TIMES.

// execute numbers from 0 - 10;
// console.log(0);
// console.log(1);
// console.log(2);
// console.log(3);
// console.log(4);
// console.log(5);
// console.log(6);
// console.log(7);
// console.log(8);
// console.log(9);
// console.log(10);

// or

// for(let i = 1; i <= 10; i++) {
//     console.log(i)
// }

// for(; ;) {
//      console.log(i)
// }

// ----if in loop----
// let num = 5;
// for (let i = 0; i < 10; i++) {
//     console.log(`iteration ${i}`);
//     if (i === num) {
//         console.log(i);
//     }
// }

// -----break-----

// let num = 5;
// for (let i = 0; i < 10; i++) {
//     console.log(`iteration ${i}`);
//     if (i === num) break;
// }

// -----continue-----

// let num = 5;
// for (let i = 0; i < 10; i++) {
//     console.log(`iteration ${i}`);
//     if (i === num) continue;
//     console.log(i);
// }

// let str = 'someLongString';
// for(let i = 0; i < str.length;  i++) {
//     console.log(str[i] + ' is iteration ' + i)
// }

// let str = 'someLongString';
// for(let i = str.length - 1; i >= 0;  i--) {
//     console.log(str[i] + ' is iteration ' + i)
// }

// Examples

// Log even numbers from 0 to 100.
// let num = 100;
// for(let i = 1; i <= num; i++) {
//     if(i%2 === 0) {
//         console.log(i)
//     }
//     // or
//     if(i%2 === 0) console.log(i)

//     // or
//     i % 2 === 0 && console.log(i)
// }

//---with while
// let i = 0;
// while (i <= num) {
//         if(i%2 === 0) {
//         console.log(i)
//     }
//     i++
// }

// ----Sum of number's digits-----

// let num = 12548;
// let numStr = num.toString();
// let result = 0;
// for(let i = 0; i < numStr.length;  i++) {
//     result += +numStr[i];
// }

// console.log(result);

// TASK 3 is there 0
// let enteredNum = prompt('please enter a number');
// // its always string thats why we put +

// for (let i = 0; i < enteredNum.length; i++) {
//     if(+enteredNum[i] === 0) {
//         console.log(`yes there is ${enteredNum[i]}`);
//         break;
//     }
// }

//---with while
// let i = 0;
// while(i < enteredNum.length) {
//     if(+enteredNum[i] === 0) {
//         console.log(`yes there is ${enteredNum[i]}`);
//         break;
//     }
//     i++
// }

