// --------------- while do while----------------

// if(true) {
//     console.log('some')
// }


// while (true) {
// //  code
// }

// let x = 5;
// while (x === 5) {
//     console.log('Infinite loop')
// }


// let x = 5;
// while (x === 5) {
//     console.log('Something');
//     x = null;
// }

// execute numbers from 0 - 10;

// console.log(0);
// console.log(1);
// console.log(2);
// console.log(3);
// console.log(4);
// console.log(5);
// console.log(6);
// console.log(7);
// console.log(8);
// console.log(9);
// console.log(10);

// OR

// let x = 0;
// while (x <= 10) {
//     console.log(x);
//     x++;
// }

// execute numbers  0 2 4 8 10;
// let x = 0;
// while (x <= 10) {
//     console.log(x);
//     x += 2;
// }

// --------- DO WHILE ----------
// do {
// //code
// } while (true);

// let x = 5;
// do {
//     console.log(x);
//     x += 10;
// } while (x < 5);


//executes nums from 0 to 10 with do while

// let x = 0;
// do {
//     console.log(x);
//     x++
// } while (x <= 10);

