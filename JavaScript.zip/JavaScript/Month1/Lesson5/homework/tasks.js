// 1) Greq function vor@ vorpes argument kstana array ev ktpi tvyal arrayum exac bolor tver@;(arrayi mej karan tveric baci urish elementner el linen)

// Alex

// let arr = [0, 'str', -561, 'somestring', false, 5.7, undefined, 65141, 8645];

// console.log(arr.filter((item) => item === +item));

// Suren
// let array = [1, 2, 3, 4, "some text"];
// function createArray(array) {
//     console.log(array)
// }
  
// createArray([1, 2, 3, 4, "some text"]);

// David Sveta
// function arr(x){
//  let i = 0;
//  while(i < x.length){
//      console.log(x[i]);
//      i++
//  }
// }
// arr(["text",65,45,true,65]);

//  ------- ANSWER -------
// function logNumbers(arr) {
//     for(let i = 0; i< arr.length; i++) {
//         if(typeof arr[i] === 'number') {
//             console.log(arr[i])
//         }
//     }
// }
// logNumbers([7,'someText', null, 87])

// 2) Greq function vor@ kstana 2 array argument ev ktpi aveli erkar arrayi meji bolor string elementnery;

// Alex
// let arr = [1, 2, 3, 4, 5, 'html', 'javascript', 'css'];
// let arr1 = [1, 2, 3, 4, 'str', 'something', 'somestring'];

// let result = arr.length > arr1.length ? console.log(arr.filter((item) => item === item.toString())) : console.log(arr1.filter((item) => item === item.toString()));

// David Sveta
// let arr = function(a ,b){   
//  if(a.length > b.length){
//      for(let i = 0;i < a.length; i++) {
//             typeof a[i] === 'string' && console.log(a[i]);
//     }
//  }else if(a.length < b.length) {
//     for(let i = 0; i < b.length; i++){
//         console.log(b[i]);
//         }
// }
// }
// arr([12,6,5], ["text","text1","text2","text3"])

// Suren
// function array() {
//     let array1 = ["a", "b", "c"];
//     let array2 = ["d", "e", "f"];
//     let array3 = array1.concat(array2);
//     console.log(array3);
// }

// array()

// ------- ANSWER -------
// function logStrings(arr1, arr2) {
//     let arr = arr1.length > arr2.length ? arr1 : arr2;
//     for(let i = 0; i < arr.length; i++) {
//         if(typeof arr[i] === 'string') {
//             console.log(arr[i])
//         }
//     }
// }

// logStrings([7,'someText', null, 87], [5,9])

// 3) Greq function vor@ kstana erku array voric mek@ datark e, ev myus arrayi meji elementery klcni datark arrayi mej u kveradarcni ayd array@

// Alex
// let arr = [];
// let arr1 = [false, true, 20, 50];

// arr = arr1.splice(0);
// console.log(arr);
// console.log(arr1);

// David Sveta
// function arr(x,y){
//     y = [...x,...y]
//     return y

// }
// console.log(arr([5,265,656],[]))

// Suren
// function array() {
//     let firstArray = [1, 2, 3, 4];
//     let secondArray = [...firstArray];
//     console.log(secondArray);
// }

// array()

// ------- ANSWER -------
// function cloneArray(arr, emptyArr) {
//     for(let i = 0; i < arr.length; i++) {
//         emptyArr.push(arr[i])
//     }
//     return emptyArr
// }

// console.log(cloneArray([7, 'someText', null, 87], []));

// 4) Greq function vor@ stanum a 2 argument mek@ array myus@ number type-i; ev stugum a ete arrayum ka 2rd argumentov stacvac tiv@
// apa veradarcnum a ayd tiv@  hakarak depqum veradarcnum a false

// David Sveta: no answer

// Alex
// let arr = [20, 100, 10, 50, 80];
// let notArr = 50;

// let result = arr.find((item) => item === notArr) ? console.log(notArr) : console.log(false);

// Suren
// function firstArray() {
//     let x = 5;
//     let array = [1, 2, 3, 4, 5, 6];
//     for (let i = 0; i < array.length; i++) {
//         if (array[i] === x) {
//             return x
//         }
//     }
//     return false
// }
// console.log(firstArray())

// ------- ANSWER -------
// function showNum(arr, num) {
//     for (let i = 0; i < arr.length; i++) {
//         if (arr[i] === num) {
//             return num
//         }
//     }
//     return false
// }

// console.log(showNum([7, 'someText', null, 87], 5));

// 5) Greq function vor kstana 4 argument bolor@ number ev kveradarcni array vori mej klinen ayd 4 numberneri krknapatiknern

// Alex
// function foo(num1, num2, num3, num4){
//     let arr = [num1 * 2, num2 * 2, num3 * 2, num4 * 2];
//     return arr;
// }
// console.log(foo(2, 6, 3, 4));

// David Sveta
// function arr(x){
//     let z = [];
//     for(let i = 0; i < x.length;i++){
//         z = [...z ,x[i] * 2]
//     }
//     return z

// }
// console.log(arr([4,6,8,9]))

// Suren
// let numbers = [1, 2, 3];
// function doubleNumbers(numbers) {
//     return numbers.map(x => x * 2);
// }

// console.log(doubleNumbers(numbers));

// ------- ANSWER -------
// function convertToArr(a, b, c, d) {
//     // return [a*2, b*2, c*2, d*2];

//     let arr = [];
//     arr.push(a * 2);
//     arr.push(b * 2);
//     arr.push(c * 2);
//     arr.push(d * 2);
//     // return  arr
// }

// console.log(convertToArr(4, 8, 7, 9));

// 6) Greq function vor@ kstana array ev khashvi ayd arrayum exac tveric amenamec@ (arrayum karan tver chlinen);
// orinak ete poxancenq [5,12,'some', true] piti veradarcni 12
// ogtagorceq filter method;

// Alex: no answer

// David Sveta
// function arr(x) {
//     let res = x.filter(item => typeof item === 'number');
//     console.log(res);
//     return (Math.max(...res))
// }
// console.log(arr([5,12,'6454',564]));

// Suren
// function array() {
//     let array1 = [5, 12, "some", true];
//     let result = array1.filter(item => typeof item === 'number');
//     return Math.max(...result) 
// }

// console.log(array())

// ------- ANSWER -------
// function getMaxNum(arr) {
    // const newArrWithNumber = arr.filter(item => typeof item === 'number');
    // return Math.max(...newArrWithNumber);
    //
    // let biggestNum = newArrWithNumber[0];
    // for (let i = 1; i < newArrWithNumber.length; i++) {
    //     if(newArrWithNumber[i] > biggestNum) {
    //         biggestNum = newArrWithNumber[i]
    //     }
    // }
    // return biggestNum
// }

// console.log(getMaxNum([5, 12, false, 'some']));

// 7) Greq function vor@ kstana array ev kveradarcni ayd array@ meji bolor tver@ krknapatkac
// orinak ete stana [5, 'Doe', 0, 4, 'some'] ---> kveradarcni [10, 'Doe', 0, 8, 'some']
//  ogtagorceq map;

// Suren: no answer

// Alex
// let arr = [5, 'Doe', 0, 4, 'some'];

// let res = arr.filter((item) => item === +item);
// let result = res.map((item) => item * 2);
// console.log(result);

// David Sveta
// function arr(x){
//     let arr1 = x.map(function(val){
//         return typeof val === 'number' ?  val * 2 : val
//     })
// console.log(arr1);
// }
// arr([5, "Doe", 0, 4, "some"]);

// ------- ANSWER -------
// function getDoubleNums(arr) {
//     let result = arr.map(item => {
//         return typeof item === 'number' ? item * 2 : item
//     });
//     return result
// }
// //
// console.log(getDoubleNums([5, 7, 9, 'some']));

// 8) Greq function vor kstana array ev ktpi ayd arrayi bolor kent index unecox elementery
//    ogtagorceq foreach;

// Alex: no answer

// David Sveta
// let a = [5,12,7,9,17,23,35,40,80,99]
// function y(a){
//     let o = [];
//     a.forEach((number, index) => {
//         if (index % 2 !== 0) {
//             o.push(number);
//         }
//     });
//     return o
// }
// console.log(y(a));

// Suren
// function array() {
//     let array1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
//     for (let i = 0; i < array1.length; i++) {
//         if (i%2 !== 0) {
//             console.log(array1[i]);
//         }
//     }
// }
// array()

// ------- ANSWER -------
// function f(arr) {
//     arr.forEach((item, i) => {
//         i % 2 !== 0 ? console.log(item) : null
//     })
// }

// f(['some', 55, 10, false, '123Js']);