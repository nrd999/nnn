// ------------------- DEFINE PROPERTY -------------------
// enumerable(show in loop) , writable(can change), configurable(can delete)

// let obj = {
//     name: 'John',
//     surname: 'Shelby',
//     age: 30,
// }

// console.log(obj);
// const descriptors = Object.getOwnPropertyDescriptor(obj, 'surname');

// console.log(descriptors);
// console.log(obj);

// -------- we can set descriptors --------
// let obj = {
//     name: 'John',
//     surname: 'Wick',
//     age: 30,
//     id: 4
// }

// Object.defineProperties(obj, {
//     name: {
//         writable: false
//     },
//     id: {
//         configurable: false
//     }
// })

// delete obj.id
// console.log(obj);
// obj.length = Object.keys(obj).length;
// Object.defineProperty(obj, 'length', {
//     enumerable: false
// })

// Object.defineProperty(obj, 'age', {
//     writable: false,
//     configurable: false
// })
// // obj.id = 10

// delete obj.age

// console.log(obj);

// for(let key in obj) {
//     console.log(key);
// }


// -------- we can't redefine property --------
// Object.defineProperty(obj, 'age', {
//     writable: true,
//     configurable: true
// });

// delete obj.age

// console.log(obj);
// // --------------------------------------------
// Examples

// ---------- empty objects ---------
// let obj = {
//     id: 4
// }
// Object.defineProperty(obj, 'name', {
//     // value: 'John',
//     writable: true,
// });

// Object.defineProperties(obj, {
//     name: {
//         value: 'John',
//         configurable: true
//     },
//     age: {
//         value: 16
//     }
// })

// delete obj.name
// console.log(obj);
// console.log(Object.getOwnPropertyDescriptor(obj, 'id'));

// let obj = {
//     id: 16,
//     name: 'John'
// }

// Object.defineProperty(obj, 'id', {
//     writable: false,
//     enumerable: false
// })

// for(let key in obj) {
//     Object.defineProperty(obj, key, {
//         writable: false,
//         enumerable: false
//     })
// }

// console.log(Object.getOwnPropertyDescriptor(obj, 'id'))