// ------------ DESTRUCTURING ------------
// let obj = {
//     id: 5,
//     isTest: true,
//     name: 'John'
// }

// const id = obj.id;
// const isTest = obj.isTest;
// const name = obj.name;

// const {isTest, id, name} = obj;

// console.log(id)
// console.log(isTest)
// console.log(name)

// const {name, isTest, id} = obj;

// console.log(id)
// console.log(isTest);
// console.log(name)

// ------------ with arrays ------------

// let arr = [5, 'name', true];
// const [a, b, c] = arr;
// console.log(a)