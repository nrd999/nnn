// let obj = {
//     name: 'John',
//     surname: 'Wick',
//     get getName() {
//         return obj.name + " " + obj.surname
//     },

//     set setName(value) {
//         obj.name = value
//     }
// }   

// obj.setName = "Ann"

// console.log(obj);