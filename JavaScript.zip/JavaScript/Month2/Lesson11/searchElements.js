// --------- get tags ---------
// PUT IN HTML
{/* <div id="main">
    <div>
        <span>text</span>
        <div>
            <span class="text">other-text</span>
        </div>
    </div>
    <div id='my-element'>
        <span>text</span>
        <span class="text">text1</span>
        <div>
            <span>text2</span>
        </div>
        <div class="text">
            <span>text4</span>
            <span class="other-text">text3</span>
        </div>
    </div>
</div>  */}
// --------- getElementById function ---------
// let elem = document.getElementById('my-element');
// console.log(elem);

// id-n petq elini unique, hakarak depqum kara sxal ashxati

// --------- queryselectorall ---------
// let x = document.querySelectorAll('.text .other-text');
// console.log(x);
// veradarcnuma bolor et classn unecox elementneri collection@ vochte array

// for (let i = 0; i < x.length; i++) {
//     console.log(x[i])
// }

// doesn't work
// x.push(5)

// --------- queryselector ---------
// let x = document.querySelector('.text');
// console.log(x);

// veradarcnuma amenarajin handipac tvyal classy

// --------- getElementsByClassName ---------
// let x = document.getElementsByClassName('text');
// console.log(typeof x);

// veradarcnuma bolor text classov teger@

// --------- getElementsByTagName ---------
// let x = document.getElementsByTagName('div');
// console.log(x);

// veradarcnuma volor diver@

// -----------------------------------
// getElementById - n karanq menak documenti vra kanchenq
// vortev search@ anuma amboxj htmlov

// isk mnacac@...
//
// let elem = document.getElementById('my-element');
// console.log(elem);
//

// console.log(document.getElementById('my-element').querySelector('.text'));
// let textElem = elem.querySelector('.text');
// console.log(textElem);

// chenq karox ogtagorcel getElementById

// --------- innerhtml innertext ---------
// let main = document.getElementById('main');
// console.log(main.innerHTML);
// console.log(main.innerText);

// main.innerText = '<div><span>changed html</span></div>';
// console.log(main);

// main.innerHTML = '<div><span>changed html</span></div>';
// console.log(main);

// --------- create element ---------
// stexcenq html js-i mijocov
// let button = document.createElement('button');
// console.log(button);

// button.className = 'button';
// console.log(button);

// console.log(button.style);
// button.style.width = '100px'
// console.log(button);

// button.innerHTML = 'Login'
// console.log(button);

// let main = document.getElementById('main');
// console.log(main);
// main.append(button);

// console.log(typeof document.all);
