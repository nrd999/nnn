// ------------------------ FUNCTION CONSTRUCTORS ------------------------
// let student1 = {
//     name: 'Alex',
//     gender: false,
// };

// let student2 = {
//     name: 'Sveta',
//     gender: true
// };

// -----------------------------------------------------------------------
// patkeracnenq senc mi function
// function Student(name, gender) {
//     this.name = name;
//     this.gender = gender;
// }

// let Student = function (name, gender) {
//     this.name = name;
//     this.gender = gender;
// }

// let student1 = new Student('Alex', false);
// let student2 = new Student('Sveta', true);
// console.log(student1);
// console.log(student2);

// -----------------------------------------------------------------------
// we can create objects with function constructors
// function Calc(num1, num2) {
//     this.add = function () {
//         return num1 + num2
//     };
// }

// let result = new Calc(5, 5);
// console.log(result.add());

// 1. erb new-ov kanchum enq datark objecta stexcvum veragrvuma this-in
//   arjeqnery vergarvum en ev veradarcvuma object@

// ------------------------ return ------------------------
// return with other object
// function Student(name, gender) {
//     this.name = name;
//     this.gender = gender;
// }

// //
// let student1 = new Student('Alex', false);
// console.log(student1);

// return with primitive
// function Student(name, gender) {
//     this.name = name;
//     this.gender = gender;

//     return {
//         name,
//         gender
//     }
// }

// console.log(Student());
// let student1 = new Student('Sveta', true);
// console.log(student1.name);

// ------------------------ methods in constructor ------------------------
// function Student(name, gender) {
//     this.name = name;
//     this.gender = gender;
//     this.sayHi = () => `Hi ${this.name}`
// }
//

// let obj = {
//     sayHi: () => `Hi ${this.name}`
// }
// let student1 = new Student('Sveta', true);
// let student2 = new Student('Alex', false);
// console.log(student1.sayHi());
// console.log(student2.sayHi());

// ------------------------ example ------------------------
// function Cart() {
//     this.products = [];
    // this.sumOfPrice = 0;

    // this.addProduct = (product) => {
    //     this.products.push(product);
    //     this.sumOfPrice += product.price;
    // };

//     this.getProductsCount = () => {
//       return this.products.length;
//     }
// }
// const cart = new Cart();

// console.log(cart);
// cart.addProduct({name: 'wine', price: 200});
// // console.log(cart);
// cart.addProduct({name: 'apple', price: 300});
// // console.log(cart.products);
// console.log(cart.getProductsCount());
// console.log(cart.sumOfPrice);

// -----------------------------------------------------------------------
// we can change price and products
// same example with private property

// function Cart() {
//     let products = [];
//     let sumOfPrice = 0;

//     this.addProduct = (product) => {
//         products.push(product);
//         sumOfPrice += product.price;
//     };

    // this.getProducts = () => {
    //     return products
    // };

    // this.getSumOfPrice = () => {
    //     return sumOfPrice
    // };

//     this.getProductsCount = () => {
//         return products.length;
//     }
// }

// const cart = new Cart();
// console.log(cart);

// cart.addProduct({name: 'wine', price: 200});
// cart.addProduct({name: 'apple', price: 300});
// console.log(cart.getProductsCount());
// console.log(cart.getProducts());
// console.log(cart.getSumOfPrice());

// ------------------------ js constructors ------------------------
// let arr = new Array(1,2,3);
// let obj = new Object({'name': 5});
// let x = 5;
// let num = new Number(5);
// let bool = new Boolean(true);
// let str = new String("4");

// console.log(num);
// Date();
// new Date();
// let date = new Date();
// console.log(date);

// function foo() {
//     return 5
// }
// foo()
// foo.call(this)


