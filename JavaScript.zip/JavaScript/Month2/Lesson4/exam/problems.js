// Mko
// function foo(str){
//     let strCopy = "";
//     for(let i=0;i<str.length;i++){
//       strCopy+= str[str.length-(i+1)]
//     }
//     return str === strCopy
//   }
  
//   console.log(foo("anna"));

// -------------------------------------------
// function foo(arg1,arg2){
//     let result = arg1.concat(arg2);
//     result.sort((a,b)=>a-b);
//     console.log(result);
//     if(result.length % 2 == 0)
//       result = (result[(result.length/2) - 1] + result[result.length/2])/2;
//     else
//       result = result[(result.length + 1)/2];
//     return result;
//   }
  
//   console.log(foo([1,3],[4,5]))

// Anna
// function f(name) {
//     let arr = [name]
//     if (arr === arr.reverse()){
//         return true
//     }
// }
// console.log(f("annak"))

// -------------------------------------------
// let arr1 = [1, 3] 
// let arr2 = [2,5]
// function f(arg1, arg2) {
//     let arr3 = [...arg1, ...arg2];
//     arr3.sort((a,b) => a-b);
//     if (arr3.length % 2 !== 0){
//         let mid = arr3[(arr3.length - 1) /2]
//         return  mid
//     }
//     else {
//         let x = arr3[(arr3.length)/2 - 1]
//         let y = arr3[(arr3.length)/2]
//         return ((x + y)/2);
//     }
// }

// console.log(f(arr1, arr2))

// Hrach
// let name = "aslcsa"; 
// function foo (name){ 
//     for(let i = 0; i < name.length; i++){ 
//         if(name[i] == name[name.length - i - 1]){ 
//             return true 
//         } 
//         else{ 
//             return false 
//         } 
//     } 
// } 
// console.log(foo(name));

// -------------------------------------------
// let arr2 = [1, 3,] 
// function foo(arr){ 
//     let newArr = arr2.concat(arr); 
//     let sortArr = newArr.sort((a, b) => a - b); 
//     let index = sortArr.length 
//     if(sortArr.length % 2 === 0){ 
//             let index1 = sortArr.length / 2  
//             let index2 = sortArr.length / 2 - 1 
//             return (sortArr[index1] + sortArr[index2]) / 2 
//     } 
//      else{ 
//         let index = sortArr.length / 2; 
//        index = Math.floor(index); 
//        return sortArr[index]  
//     } 
// } 
// console.log(foo([2, 5]));

// Davit
// function foo(str){ 
//     let y = str.length; 
//     for(let i = 0; i < y / 2;i++){ 
//         if(str[i] !== str[y - 1 - i]){ 
//             return false 
//         } 
//     } 
//     return true 
// } 
// console.log(foo('anna'))
// -------------------------------------------
// function foo(arr1,arr2){
//     let arr3 =arr1.concat(arr2);
//     arr3.sort((a,b)=> a - b);
//     if(arr3.length % 2 === 0){
//       let z = arr3[arr3.length / 2 - 1];
//       let h = arr3[arr3.length / 2];
//       return (z + h) / 2
    
//     }else return arr3[arr3.length / 2 - 0.5]
// }
// console.log(foo([1,3,4],[2,5]))

// Sveta
// function foo(x) {
//     return x === x.split("").reverse().join("");
// }
// console.log(foo("anna"));

// -------------------------------------------
// function foo(x,y){
//     let f = x.concat(y);
//     f.sort((a,b)=> a - b);
//     if(f.length % 2 === 0){
//       let p = f[f.length / 2 - 1];
//       let k = f[f.length / 2];
//       return (p + k) / 2
//     }else return f[f.length / 2 - 0.5]
// }
// console.log(foo([1,3],[2,5]))

// Alex
// function foo(value) {
//     for(let i = 0; i < value.length; i++){
//        return value = value[i] === value[value.length - i - 1] ? true : false
//     }
// }
// console.log(foo('ANNA'));
// -------------------------------------------

// function foo(arr, arr2){
//     let res = 0
//     let arr3 = arr.concat(arr2)
//     arr3.sort((a, b) => a - b);
//     return arr3.length % 2 === 0 ? (arr3[arr.length / 2 + 1] + arr3[arr.length / 2]) / 2 : arr3[arr.length / 2]
// }
// console.log(foo([1, 7],[5, 2]));

// Suren
// function mirror(str) {
//     let str1 = "";
//     for (let i = 0; i < str.length; i++) {
//         str1 += str[str.length - (i+1)]
//     }
//     // if (str === str1) {
//     //     return true
//     // } else {
//     //     return false
//     // }
//     return str === str1
// }
// console.log(mirror("HaaaaaaaH"));

// -------------------------------------------

// function foo(arr1, arr2) {
//     let result = arr1.concat(arr2)
//     result.sort((a,b) => a-b)
//     if (result.length % 2 === 0) {
//         let middle1 = result.length / 2
//         let middle2 = result.length / 2 + 1
//         return (middle1 + middle2) / 2
//     } else return Math.floor(result.length / 2)
//   }
// console.log(foo([1,3], [2,5]));
