// Unenq user object vorn uni inch vor propertyner. Unenq user1 object vorn uni ir propertynery ev jarangum e useriny.
// Greq function vory kveradardzni array, vori mej klinen konkret user1 objecti keyery.Orinak ete usern uni canLike: true
// key, isk user1y voch, jarangeluc user1i ptoyoyum kavelana ayd keyy, bayc da chi hamarvum henc user1i key, da jarangvac 
// key a, aysinqn dzer veradardzvox arrayi mej chi linelu. Chaseq chhaskaca.

// Hrach
// let user = {
//     id: 1,
//     name: 'user1',
//     number: '215644435',
//     allPhotosArePublic: true,
//     country: 'America',
//     canLike: true,
//     canPostVideos: true,
// }
// let user2 = {
//     postCode: 2,
//     code: 'user2',
//     surname: 'User2',
//     gender: false,
//     country: 'Armenia',
// }

// user2.__proto__ = user;
// let userKey = Object.keys(user);
// function foo(){
//      let arr = [];
//      for(let i = 0; i < userKey.length; i++){
//         Object.defineProperty(user, userKey[i], {
//             enumerable: false
//         });
//      }
//     for(let key in user2){
//         arr.push(key)   
//     }
//    return arr
// }
// console.log(foo());
// console.log(user2);

// Alex
// let user = {
//     id : 746,
//     age : 30
// }

// let user1 = {
//     name : 'Alex',
//     surname : 'Hovsepyan'
// }

// user1.__proto__ = user;

// let foo = value => Object.keys(value)
// Object.prototype.foo = foo(this);

// console.log(foo(user1));
// console.log(user1);




// function foo() {
//     return Object.keys(user1)
// }

// console.log(foo());
// console.log(user1);

// David Sveta
// let user = {
//     color : 'red',
//     canLike : true
// }
// let user1 = {
//     name : 'Tom',
//     surname : 'Jeckson'
// }
// user1.__proto__ = user

// function foo(){
//     let arr = Object.keys(user1);
//     arr.__proto__ = user;
//     return arr
    //OR
    // return Object.keys(user1);
// };
// console.log(foo(user1))

// -------- Answer --------
// let user3 = {
//     id: 'sth'
// }

// let user = {
//     id: 1,
//     name: 'user1',
//     number: '215644435',
//     allPhotosArePublic: true,
//     country: 'America',
//     canLike: true,
//     canPostVideos: true,
//     followers: ['facebookBot'],
//     showNumber: function () {
//         return `${this.name} number is ${this.number}`;
//     },
// }

// let user1 = {
//     id: 2,
//     name: 'user2',
//     number: '123456789',
// }

// user1.__proto__ = user;

// function foo(obj) {
//     let result = [];
//     for(let key in obj) {
//         obj.hasOwnProperty(key) && result.push(key)
//     }
//     return result
// }

// console.log(foo(user1));
// console.log(user1);

// user.__proto__ = user3;
// user1.__proto__.canLike = false

// user1.__proto__.__proto__.id = 6