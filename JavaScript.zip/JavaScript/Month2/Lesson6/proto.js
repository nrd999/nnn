// let user = {
//     id: 1,
//     name: 'user1',
//     number: '215644435',
//     allPhotosArePublic: true,
//     country: 'America',
//     canLike: true,
//     canPostVideos: true,
//     followers: ['facebookBot'],
//     showNumber: function () {
//         return `${this.name} number is ${this.number}`;
//     },
// }
// console.log(user);

// let user1 = {
//     id: 2,
//     name: 'user2',
//     number: '215644435',
//     allPhotosIsPublic: true,
//     othersCanWriteMessage: true,
//     country: 'America',
//     canLike: true,
//     canPostVideos: true,
//     followers: ['facebookBot'],
//     showNumber: function () {
//         return `${this.name} number is ${this.number}`;
//     },
// }

// ....

// let user1 = {}
// console.log(user1);
// user1.__proto__ = user;
// console.log(user1);
// console.log(user1.allPhotosArePublic)

// SA KOCHVUM E PROTOTYPE INHERITENCE

// let arr = []
// console.log(arr);

//----------------------------------
// let user1 = {
//     id: 2,
//     name: 'user2',
//     number: '1111111',
// }

// user1.__proto__ = user;

// console.log(user1);

// console.log(user1.id)
// console.log(user1.name)
// console.log(user1.number)
// console.log(user1.allPhotosArePublic)
// console.log(user1.showNumber())

// ----------------------------------------------------
// menq karox enq tal mer uzac nkaragrutyun@ objectin
// arajin@ kashxati tvyal object keyer@
// ete chlinen nor kvercni prototypeic
// aysinqn ayn objectic voric zharangel a

// let user3 = {
//     id: 3,
//     name: 'user3',
//     number: '33333',
//     showNumber: function () {
//         return 'number is hidden'
//     }
// }
// //
// user3.__proto__ = user;
// console.log(user3.showNumber())

// ----------------------------------------------------
// let user2 = {};
// user2.__proto__ = 5
// console.log(user2);
// antesvum e
// kam petq e lini object kam null
// ----------------------------------------------------
// let person = {
//     canWalk: true,
//     canWrite: true
// }
// let adult = {
//     age: 14,
// }
// let baby = {
//     age: 3,
//     canWrite: false,
// }

// baby.__proto__ = adult;
// adult.__proto__ = person;
// console.log(baby)
// console.log(adult)

// // ---------for in loop------------
// let user1 = {
//     id: 2,
//     name: 'user1',
//     number: '1111111',
//     country: 'Armenia',
// }
// //
// user1.__proto__ = user;

// console.log(user1.hasOwnProperty('allPhotosArePublic'));
//
// Object.defineProperty(user1, 'number', {
//     enumerable: false,
// });
//
// for (let key in user1) {
//     console.log(`${key}-----${user1[key]}`)
// }

// hasOwnProperty

// for(let key in user1) {
//     if(user1.hasOwnProperty(key)) {
//         console.log(`${key}-----${user1[key]}`)
//     }
// }

// let arr = [1, 2, 3];
// // let map = () => arr[0] * arr[1] * arr[2];
// function map() {
//     return arr[0] * arr[1] * arr[2]
// }
// arr.__proto__ = new Array()
// Array.prototype.map = map;
// console.log(arr.map());
// console.log(arr);
// arr.filter(item => item < 5)
// arr.map(item => console.log(item))

// function length(obj) {
//     // Object.defineProperty(this, 'length', {
//     //     value: Object.keys(this).length,
//     //     writable: true,
//     //     enumerable: false,
//     //     configurable: false
//     // })
//     return Object.keys(obj).length
// }

// let obj = {name: 'John'};
// let sth = new Length({name: 'John'});

// Object.prototype.length = length(this);
// console.log(obj);
// console.log(length(obj));

// let obj = {
//     id: 5
// }

// delete obj.__proto__
// obj.__proto__ = null
// console.log(obj);

// delete obj.__proto__.hasOwnProperty
// console.log(obj);

// obj.__proto__.hasOwnProperty = 5

// console.log(obj.hasOwnProperty);