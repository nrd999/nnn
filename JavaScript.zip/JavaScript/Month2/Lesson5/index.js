
// let obj1 = {}

// console.log(length(obj1));