// function foo () {
//     let x = 5;
//     var y = 6;
//     const z = 10;
// }

// if(true) {
//     let x = 5;
//     // var y = 6;
//     const z = 10;
// }

// let arr = new Array(1,2,3)
// let arr = [1, 2, 3];

// console.log(z);
// let x = 5;
// var y = 6;
// const z = 10;

// function foo(){}
// console.log(f());
// let f = function () {

// }
// console.log(y);
