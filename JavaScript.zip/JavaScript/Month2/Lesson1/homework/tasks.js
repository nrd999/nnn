// Web APIs - https://developer.mozilla.org/en-US/docs/Web/API

// 1) greq function vorn stanum e 2 number argument from ev to, orinak 4, 8 ev tpum e vayrkyan@ mek from-ic to tvery; orinak stanum e 4,8  tpum e 4,5,6,7,8

// David Sveta
// function foo(from, to) {
//     setTimeout(function start() {
//       console.log(from);
//       if (from < to) {
//         setTimeout(start, 1000);
//       }
//       from++;
//     }, 1000);
// }

// foo(4, 8);

// Suren
// let count = 4;
// let timerId = setInterval(() => {
//     if(count === 8) {
//         clearInterval(timerId)
//     }
//     console.log(count++)
// }, 1000)

// Anna
// function f(from,to) {
//     setInterval(() => from <= to && console.log(from++), 1000)
// } 
// f(4,8);  

// Alex
// let from = 4, to = 8;

// let foo = setInterval(() => from <= to && console.log(from++), 1000, from, to)
// let foo = setInterval(() => {
//     from <= to ? console.log(from++) : clearInterval(foo);
// }, 1000)

// ------ Answer ------
// function f(from, to) {
    // let num = from;
//     let timerId = setInterval(() => {
//         console.log(from);
//         from++;
//         if(from > to) {
//             clearInterval(timerId)
//         }
//     }, 1000)
// }
// f(3,6);

// 2) greq function vorn stanum e PATAHAKAN GENERACVAC tiv 0,10 mijakayqum ev ete stacvac tivy mec e 5-ic  ayd tvin hamapatasxan vayrkyan heto tpum eayd tiv@
//   orinak stanum e 7 uremn 7 vayrkyan heto ktpi 7.

// Suren: no answer

// David Sveta
// function foo(){
//     let randomNumber = Math.floor(Math.random() * 10);
//     setTimeout(() => {
//         if(randomNumber > 5){
//             console.log(randomNumber)
//         } else {
//             console.log(randomNumber);
//         }
//     },randomNumber * 1000)
// }
// foo()

// Anna
// let random = Math.floor(Math.random() * 10)
// function f(number) {
//     if (number > 5){
//         setTimeout(() => {
//             console.log(number);
//         }, 1000 * number)
//     }
//     else{
//         return console.log("less then 5")
//     };
// }
// (f(random));

// Alex
// let x = Math.floor(Math.random() * 10);

// setTimeout(value => value > 5 && console.log(value), x * 1000, x)

// ------ Answer ------
// function f(num) {
//     num > 5 && setTimeout(() => console.log(num), num * 1000)
// }

// f(Math.round(Math.random() * 10));

// 1) WHAT WILL BE THE OUTPUT AND WHY
// let x = 5;
// setTimeout(() => console.log(x), 1000);
// x += 1;

// David Sveta
// x - kdarna 6 setTimeout-i mej mtnelov clg kunenanq 6 (1 varkyan heto)

// Suren
// qani vor timer@ draca mek varkyani vra yev x= 1-a arvac eji load lineluc mek varkyan heto ktpi 6

// Anna
// 6

// Alex
// skzbum x-y 5-a heto darnuma 6 nor ashxatuma setTimeout-y u tpuma 6

// 2) WHAT WILL BE THE OUTPUT AND WHY
// let x = 0;
// setTimeout(() => console.log(x), 0);
// x++;

// David Sveta
// x @ arden kdarna 1 (++-ov) setTimeout@ mtnelov miangamic  ktpi 1 qani vor nshel enq 0

// Suren
// aranc delayi ktpi 1 vorovhetev console.logi pahin tiv@ der zroya isk hajord qaylum darnuma 1

// Anna
// 1, kap chuni vor 0 vayrkyan enq nshel ete grel enq setTimeout inqy verjum a stackic durs galu

// Alex
// skzbum x-y 0-a u kap chuni vor setTimeout-in 0-a trvac inqy skzbic x-in gumaruma 1 heto nor ashxatuma setTimeout-y u tpuma 1

// 3) WHAT WILL BE THE OUTPUT AND WHY
// function f(num) {
//     console.log(num);
//     clearInterval(timerId)
// }

// let x = 2;

// let timerId = setInterval(() => f(x), x * 1000);

// Anna: no answer

// David Sveta
// kkanchvi f function@ 2-ov ev arden 2 varkyanov,functioni mej mtnelov ktpi 2
// ev kdatari clearInterval hramani mijocov

// Suren
// 2 varkyan heto ktpi 2 vorovhetev 2-@ vor@ veragrvac er x-in bazmapatkvela 1000 milivarkyanov 

// Alex
// x-y 2-a heto ashxatuma setIntervaly u f-in talisa x-i arjeqy u 2000 vayrkyan heto tpuma 2 u kangnuma

// 4) WHAT WILL BE THE OUTPUT AND WHY
// function setTimer(canSet) {
//     console.log(1)
//     if(canSet) {
//         console.log(2)
//         setTimeout(() => setTimer(false), 1000)
//     }else {
//         console.log('this is recursion')
//     }
// }
// setTimer(true)

// Anna: no answer

// David Sveta
// canSet-@ true e mtnum enq function-i mej katarvum e
// arajin clg 1-ov ,mtnum enq if-i mej vortex el
// clg klini 2. heto setTimer darnum e false katarvum e verevi clg vor@ 1 e (1 varkyan heto)
// chi mtnum if mej katarvum e else @ u clg ktp this is recursion

// Suren
// arajin toxum mi hat aranc delay ktpi mek
// 2rd toxum aranc delay ktpi 2 qani vor if-i payman@ true-a u console.log-a arvel 2
// heto chgitem

// Alex
// kanchvuma setTimer function-y true arjeqov u tpuma 1 heto if-i paymany true-a linum u tpuma 2 
// heto ashxatuma setTimeout-y u 1vayrkyan heto setTimer-i canSet-y darnuma false u kanchvuma 
// heto tpuma 1 u mtnuma if-i mej u stanalov false gnuma else-i mej u tpuma 'this is recursion'

// David Sveta
//5)ktpi done waiting random varkayn heto

// setTimeout(() => {
//     console.log("Done waiting");
// }, Math.floor(Math.random() * 1000));



//***************************************************** 
//6)ete time < 5 ic kta ayd tiv@ ev ayd tvin hamapatasxan varkyan heto ayd nuyn tiv@ 
//ete > 5 ic ktpi 2x nuyn tiv@ 
// function foo(){
//     let time = Math.floor(Math.random() * 10);
//     let res = 0;
//     if(time < 5){
//         res = time * 1000
//     }
//     let z = setTimeout(function(){
//         console.log(time)
//     },res)
//     return time
// }
// console.log(foo())
