// 1) greq function vorn stanum e array cankacac elementnerov (nayev krknvox)
//    ev veradarcnum e object, vortex key valueov nshvac e te tvyal elmentic qani hat ka arrayum
//    orinak f(['a', 'b', 'c', 'b', 'a', 'a']) ---> {a: 3, b: 2, c: 1} petqa asxhati voch menak stringneri arrayov ayl cankacac

// function foo(arr){
//     return arr.reduce((obj,val)=>{
//         return obj[val] ? ++obj[val] : obj[val] = 1, obj
//     },{})
// }
// console.log(foo([3,'hello',3,10,3,3,'hello',true,10,true]))

// ---------- ANSWER ----------
// function f(arr) {
//     let resultObj = {};
//     arr.forEach(item => {
//         if(!resultObj[item]) {
//             resultObj[item] = 1
//         }else {
//             resultObj[item]++
//         }
//     })
//     return resultObj
// }
// console.log(f(['a', 'b', 'c', 'b', 'a', 'a']));

// 2) greq function vor@ stanum e objectneri array vortex nshvac en inchvor apranqner, apranqneri qanak, goyutyun uni te voch
// ev arjeq (arjeq@ verabervum e 1 apranqin), function@ piti veradarcni @ndhanur goyutyun unecox apranqneri gumar@
// (nman funkcianer en ashxatum cankacac online arevtri kayqerum erb add enq anum apranqy karzina u nshuma qanak verjum cuyca talis inchqan piti vcharenq)
// orinak f(
    // [
    // {name: 'snikers', quantity: 2, price: 200, doesExist: false},
    // {name: 'coca-cola', quantity: 5, price: 100, doesExist: true},
    // {name: 'lays', quantity: 1, price: 100, doesExist: true},
    // ]
// ) kveradarcni 600, vorovhetev goyutyun uni 5 hat coca-cola amen meky 100 u 1 hat lays 100

// function transform(arr) {
//     let existedItems = arr.filter(item => item.doesExist);
//     let sum = 0;
//     for(let i = 0; i < existedItems.length; i++) {
//         sum += existedItems[i].quantity * existedItems[i].price;
//     }

//     return sum
//   }

// console.log(transform([
//     {name: 'snikers', quantity: 2, price: 200, doesExist: false},{name: 'coca-cola', quantity: 5, price: 100, doesExist: true},
//     {name: 'lays', quantity: 1, price: 200, doesExist: true},
//     {name: 'pepsi', quantity: 1, price: 400, doesExist: true},
// ]));

// ---------- ANSWER ----------
// function f(arr) {
//     let sum = 0;
//     for (let obj of arr) {
//         if(obj.doesExist) {
//             sum += obj.quantity * obj.price
//         }
//     }
    
//     return sum
// }

// console.log(f([
//     {name: 'snikers', quantity: 2, price: 200, doesExist: false},
//     {name: 'coca-cola', quantity: 5, price: 100, doesExist: true},
//     {name: 'lays', quantity: 1, price: 100, doesExist: true},
//     ]));

// 3) greq function vory kstana nshvac array@ arajin argumentov
//    ev kstana 2 rd argument objecti keyeric mek@, ev kveradarcni object vortex
//    xmbavorvac klinen studentnern @st poxancvac keyi
//    orinak f(students, 'gender') kveradarcni
// {
//     true: [{}, {}]--> bolor ayn studnetnnery voronc gender@ true e
//     false: [{}, {}] ---> bolor ayn studentnnery voronc gender@ false e
// }

// const students = [
//     {
//         name: 'Mko',
//         gender: false,
//         age: 20
//     },
//     {
//         name: 'Anna',
//         gender: true,
//         age: 21
//     },
//     {
//         name: 'Hrach',
//         gender: false,
//         age: 22
//     },
//     {
//         name: 'Suren',
//         gender: false,
//         age: 23
//     },
//     {
//         name: 'Alex',
//         gender: false,
//         age: 20
//     },
//     {
//         name: 'David',
//         gender: false,
//         age: 21
//     },
//     {
//         name: 'Sveta',
//         gender: true,
//         age: 22
//     },
//     {
//         name: 'Alex',
//         gender: false,
//         age: 16
//     }
// ];

// function foo(students, filter) {
//     const fil = Object.keys(filter);
//     return students.filter(student => student[fil] === filter[fil])
// }

// const filter = {gender : true};
// console.log(foo(students, filter));

// ---------- ANSWER ----------
// function f(students, groupByKey) {
//     let obj = {};
//     students.forEach(item => {
//         const groupByValue = item[groupByKey];
//         if(!obj[groupByValue]) {
//             obj[groupByValue] = [];
//         }
//         obj[groupByValue].push(item)
//     })
//     return obj
// }


// console.log(f(students, 'age'));

// 1) WHAT WILL BE THE OUTPUT AND WHY
//1-in clg ktpi undefined qani vor uxxaki foo() enq kanchel isk
//2rd-um  ktpi 5 qani vor obj-i this.a 5 e 

// function foo () { console.log(this.a) }
// let obj = {
//     foo: foo,
//     a: 5
// };
// // foo();
// obj.foo();
// foo()

// 2) WHAT WILL BE THE OUTPUT AND WHY
//erku clg el kta undefined skzbum qani vor uxxaki function enq kanchel 
//erkrordum arrow function e 

// function foo () {
//     let f = () => {
//         console.log(this.a)
//     }
//     f()
// }
// let obj = {
//     foo: foo,
//     a: 5
// };
// foo();
// obj.foo();

// 3) WHAT WILL BE THE OUTPUT AND WHY
//1in clg klini bar qani vor kanchum enq this.foo vor@ bar e 
//2rd-um eli bar qani vor self el a havasar nran
//3rd u 4rd um nuynpes bar qani vor inqnakanchvox function e

// let obj = {
//     foo: 'bar',
//     func: function () {
//         var self = this;
//         console.log(this.foo);
//         console.log(self.foo);
//         (() => {
//             console.log(this.foo);
//             console.log(self.foo);
//         })()
//     }
// }
// obj.func();

// 4) WHAT WILL BE THE OUTPUT AND WHY
// clg kunenaq Wick qani vor getName() functian kancheluc name veraberum e methods name-in

// let student = {
//     name: 'John',
//     methods: {
//         name: 'Wick',
//         getName: function () {
//             console.log(this.name)
//         }
//     }
// }

// let obj = student.methods.getName();

// 5) WHAT WILL BE THE OUTPUT AND WHY
// function kanchum enq mtnum e (obj.getId = function) mej  5ov sakayn console um tpum e 1 vorovhetev ir this @ obj e 
// 2-rd console um tpum e 2 vorovhetev id++ ov mecacrel enq ayd tiv@


// let obj = {
//     id: 1,
//     getId: (id) => console.log(this.id++)
// }

// obj.getId = function (id) {console.log(this.id++, id)}
// obj.getId(5);
// obj.getId(5);
// console.log(obj.id);

// 6) WHAT WILL BE THE OUTPUT AND WHY
// obj u obj1 darnum en 2 vorovhetev obj assign enq anum id:2

// let obj = {
//     id: 1,
//     getId: function () {
//         console.log(this.id)
//     }
// }

// let obj1 = Object.assign(obj, {id: 2});
// obj.getId()
// obj1.getId()