// function Student(name) {
//     this.name = name;
// }

// Student.prototype.sayHi = function () {};
// 
// let student1 = new Student('Alex');
// console.log(student1);

// Class declaration
// class Student {
    // constructor(name) {
    //     this.name = name;
    // }

    // sayHi() {
    //     console.log(`hi`)
    // }
// }

// let student1 = new Student('Alex');
// console.log(student1);
// student1.sayHi();

// Class expression
// let Student = class {
//     constructor(name) {
//         this.name = name;
//     }
//     sayHi() {
//         console.log(`hi`)
//     }
// }
// //
// let student1 = new Student('Alex');
// console.log(student1);

// 1. class@ kancheluc kanchvuma constructor function@ stexcvuma object this@ seta arvum et objecti vra
//    u veradarcvuma object@
// 2. bolor methodner(voch arrow function grvum en prototypeum)
// classy nuyn functionna mi qani avel hnaravorutyunov

// console.log(typeof Student)

// Arrow functions
// class Student {
//     constructor(name) {
//         this.name = name;
//     };

    // sayGoodbye = () => {
    //     console.log(`goodbye ${this.name}`)
    // };

    // sayHi() {
    //     console.log(`hi ${this.name}`)
    // };
// }

// let student1 = new Student('Alex');
// console.log(student1);
// student1.sayHi()
// student1.sayGoodbye()

// chka constructor nshanakuma stacvac objecty datark e
// class Student {
//     sayHi() {
//         console.log(`no constructor`)
//     };
// }

// let student1 = new Student();
// console.log(student1.sayHi());

// ------------ Differences ------------
// class Student {
//     constructor(name) {
//         this.name = name;
//     }

    // sayHi() {
    //     console.log(`hi ${this.name}`)
    // }

//     share = () => {
//         console.log('share');
//     }
// }

// let student1 = new Student('Alex');

// 1. chenq karox kanchel aranc new
// Student()
// 2. methodnern enumareble en (functioni depqum loopum erevum en nayev zharangvac methodnery)
//    classum avtomat enumarble false en stanum
// for(let key in student1) {
//     console.log(key)
// }

// karanq tanq anun bayc kereva menak classi nersum
// let Student = class SomeName {
//     constructor(name) {
//         this.name = name;
//     }
//     sayHi() {
//         console.log(`hi ${this.name}`)
//     }
// }
// let student1 = new Student('Alex');
// console.log(student1);

// ----- nor hnaravorutyuun aranc constructor --------
// karanq propertynery set anenq aranc constructor
// bayc ete argument petqa poxancenq constructory partadira

// class Student {
//     name = 5;
//     sayHi() {
//         console.log(`hi ${this.name}`)
//     };
// }

// let student1 = new Student('Alex');

// console.log(student1);
// student1.sayHi()

// ------------------------------------------
// 1. classi - construcotrum cankacac ban vor set anenq lineluya nayev objectum
// 2. constructoric durs bolor methodnery grvum en prototypeum baci arrow function methodnernic
// 3. nor hnaravorutyan depqum contsructoric durs grvac popoxakannery grvum en objectum vorpes keyer,
//    arrow functionn henc dra hamae grvum objectum vortev hamarvuma uxxaki popoxakanin veragrvac function


// let arr = [4,5];
// console.log(arr);
// // arr.length = 0;
// arr.push(6);
