// ---------- instanceof ----------
//
// stuguma patkanuma ayd contructorin
// ashxatuma zharangman skzbunq@
//
// object instanceof constructor
//
// function F() {

// }

// function F1() {

// }

// let obj = new F();

// console.log(obj instanceof F);
// console.log(obj instanceof F1);

// console.log(obj instanceof Object);

//  erb chkar isArray method@
// let arr = [];

// console.log(arr instanceof Array)
// object@ chenq karox senc stugel
//
// let obj = null;
// let obj1 = new null();

// let y = Symbol();
// let x = Symbol('foo');
// console.log(Symbol.for('y'));

// console.log(obj1);
// console.log(obj instanceof Object);
// console.log(y);
