// let user = {
//     allPhotosIsPublic: true,
//     othersCanWriteMessage: true,
//     country: 'America',
//     canLike: true,
//     canPostVideos: true,
//     followers: ['facebookBot'],
//     showNumber: function () {
//         return `${this.name} number is ${this.number}`;
//     },
// }

// ----------------------------------------------------
// let user1 = {}
// user1.__proto__ = user;
// console.log(user1);

// ----------------- Object create -----------------
// stexcuma nor object ev vorpes prototype seta anum poxnacvvac object@

// let user1 = Object.create(user);
// user1.id = 8
// console.log(user1);

// partadir petq alini object kam null

// let user1 = Object.create(null);
// console.log(user1);
// //
// console.log(user1.toString());

// ----------------- GETPROTOTYPEOF -----------------
// let obj = Object.create(user);
// console.log(Object.getPrototypeOf(obj))

// ----------------------------------------------------
// let user2 = Object.create(user);
// let protoType = Object.getPrototypeOf(user2);
// console.log(protoType)



