// -------- rest --------
// function showArgs(...args) {
//     console.log(args);
// }
//
// showArgs(1,'name',3,'surname',5);

// function showArgs(a, b, ...args) {
//     console.log(args);
// }

// showArgs(1, 2, 3, 4, 5);

// rest must be  last parameter
// function showArgs(a, ...args, b) {
//     console.log(args);
// }
//
// showArgs(1, 2, 3, 4, 5);

// -------- arguments --------
// function showArgs() {
//     console.log(arguments);
// }   

// showArgs(1,'name',3,'surname',5);