// 1) WHAT WILL BE THE OUTPUT AND WHY
// let x = 12;
// function test(x) {
//     console.log(x);
//     let x = 7;
// }
//
// test(9)

// 2) WHAT WILL BE THE OUTPUT AND WHY
// let x = 12;
// function test(x) {
//     x = 14;
//     console.log(x);
//     console.log(y);
//     const y = 9;
// }
//
// test(9)

// 3) WHAT WILL BE THE OUTPUT AND WHY
// let x = 2;
// function test(y) {
//     console.log(y);
//     y = 3;
//     console.log(x)
//     function test1 (a) {
//         let z = 4;
//         console.log(x);
//         function test2 (z) {
//             console.log(a);
//             console.log(z)
//             z = 5;
//         }
//         test2(6)
//     }
//     test1(7)
// }
// test(1)

// 4) WHAT WILL BE THE OUTPUT AND WHY
// let x = 1;
// f(2);
// function f(x) {
//     console.log(x)
// }
// x = 3;
// f();

// 5) WHAT WILL BE THE OUTPUT AND WHY
// f(1);
// let f = function (a, y) {
//     console.log(a)
//     console.log(y)
//     y = 3;
// };

// 6) WHAT WILL BE THE OUTPUT AND WHY
// f();
// let x = 2;
// let f = x => {
//     console.log(x)
// }

// 7) WHAT WILL BE THE OUTPUT AND WHY
// let f = (x,y) => {
//     console.log(z, x, y);
//     y = 5;
// }
// var z = 4;
// f(3);
// f(1,2);

// 8) WHAT WILL BE THE OUTPUT AND WHY
// var x = 21;
// let foo = function() {
//     console.log(x);
//     var x = 20;
// };
// foo();
// foo(5);
// console.log(x);

// 9) WHAT WILL BE THE OUTPUT AND WHY
// function f1(callback) {
//     let x = 7;
//     return callback(x);
// }
// function f2(param) {
//     let x = 'Jhon';
//     return param
// }
//
// let res = f1(f2);
// console.log(typeof res);

// 10) WHAT WILL BE THE OUTPUT AND WHY
// let a = 999;
// function foo() {
//     let b = a;
//     function myFunction (){
//         b = 66;
//     }
//     console.log(b);
//     console.log(a);
//     myFunction();
// }
// a = 555;
// foo();

// 11) WHAT WILL BE THE OUTPUT AND WHY
// var x = 12;
// function f1(z) {
//     console.log(x);
//     var x = 7;
//     let y = 9;
//     f3(z);
//     function f2(x) {
//         console.log(x);
//         console.log(y);
//     }
//     function f3(z) {
//         console.log(z);
//         f2(y);
//     }
//     console.log(x + y)
// }
//
// f1();

// 12) WHAT WILL BE THE OUTPUT AND WHY
// var name = 'Jhon';
// (function () {
//     console.log(name)
// })();

// 13) WHAT WILL BE THE OUTPUT AND WHY
// var name = 'Jhon';
// (function () {
//     console.log(name)
// })();


// 14) WHAT WILL BE THE OUTPUT AND WHY
// var surname = 'Doe';
// (function (name, surname) {
//     console.log(name, surname)
// })('Jhon', 'Wick');


// 15) WHAT WILL BE THE OUTPUT AND WHY
// (function(x) {
//     console.log(x)
//     return (function(y) {
//         console.log(x + y);
//     })(2)
// })(1);

// 16) WHAT WILL BE THE OUTPUT AND WHY
// const test = function f(){ return 5 };
// console.log(test());
// console.log(f());

// 17) WHAT WILL BE THE OUTPUT AND WHY
// function test1(test2) {
//     let name = 'name1';
//     return test2();
// }
// function test2() {
//     let name = 'name2';
//     console.log(5);
//     return name
// }
// let result = test1(test2);
// console.log(result);

// 18) WHAT WILL BE THE OUTPUT AND WHY
// function test() {
//     return function () {
//         return function () {
//             return null
//         }
//     }
// }
//
// console.log(typeof test());
// console.log(typeof test()());
// console.log(typeof test()()());

// 19) WHAT WILL BE THE OUTPUT AND WHY
// function test() {
//     let arr = [];
//     let a = 2;
//     return function () {
//         arr.push(a);
//         return arr;
//     }
// }
// console.log(test());
// console.log(test()());

// 20) WHAT WILL BE THE OUTPUT AND WHY
// let a = 1;
// function test() {
//     let b = a;
//     return function () {
//         return b++;
//     }
// }
// let result = test()();
// console.log(++result);

// 21) Inchpes kanchenq funkcian, vor stananq namey kam surnamey
// function getName(isWithSurname) {
//     const name = 'John';
//     const surname = 'Shelby';
//     if(isWithSurname) {
//         return function () {
//             return name
//         }
//     }else {
//         return function () {
//             return `${name} ${surname}`
//         }
//     }
// }

// 22) Inchpes kanchenq funkcian, vor stananq namey kam surnamey
// function getName(isWithSurname) {
//     let name = 'John';
//     let surname = 'Shelby';
//     if(isWithSurname) {
//         name = 'Johnny';
//         return (function () {
//             return name
//         }())
//     }else {
//         let surname = 'Depp';
//         return (function () {
//             return `${name} ${surname}`
//         })()
//     }
// }