
// >, <, <=, >=, !==, +=
// console.log(4 < 6);
// console.log(8 <= 6);
// console.log(4 >= 3);
// console.log("4" !== 4);

// let a = 5;
// a = a + 5;
// a += 5; 
// console.log(a);

// Math
// let a = 4.4;
// let random = Math.random();
// console.log(Math.floor(a));
// console.log(Math.ceil(a));
// console.log(Math.round(a));
// console.log(Math.max(10, 5, 16));
// console.log(Math.min(10, 5, a));
// console.log(Math.round(random * 10));

// toFixed()
// let a = Math.random();
// console.log(a);
// console.log(a.toFixed(4));

// parseInt, parseFloat
// let width = "15.5x";
// console.log(parseInt(width));
// console.log(parseFloat(width))

// toString
// let a = 11;
// console.log(a.toString());

// String lenght
// let a = "some string";
// console.log(a.length);
// console.log(a[a.length - 1]);
// console.log(a.indexOf('s', 2));

// toLowercase, toUppercase
// let a = "soMe string";
// console.log(a.toLowerCase());

// if
// if(4 >= 5){
//     console.log("True");
// } else {
//     console.log("Hajox");
// }

// let a = "5h";
// if(a.length > 2) {
//     console.log("Greater than 2");
// } else if (a.length === 2) {
//     console.log("Lenght is 2");
// } else {
//     console.log("Smaller than 2");
// }

// let a = "h1";
// a.length > 2 ? console.log("Greater than 2") : console.log("Smaller than 2");

// a.length > 2 ? console.log("Greater than 2") : a.length === 2 ? console.log("Lenght is 2") : console.log("Smaller than 2"); 

// &&, ||

// let a = true && true;
// let b = false || "5" && '4' || true ;

// console.log(b);

// While

// let a = 6;
// while(a < 15){
//     a++;
//     console.log(a);
// };









